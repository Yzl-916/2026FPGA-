﻿param([string]$TdRoot='D:\Anlogic\TD_6.2.1_Engineer_6.2.168.116',[switch]$ReuseSynthesis)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
# This script builds only the final work candidate; it never programs a device.
function Get-Text([string]$Path) { return [IO.File]::ReadAllText($Path) }
function Get-Digest([string]$Path) { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
$scriptBefore=Get-Digest $PSCommandPath
$tool=Join-Path $TdRoot 'bin/td_commands_prompt.exe'
if(-not (Test-Path -LiteralPath $tool)){throw "TD tool missing: $tool"}
$version=(& $tool -version 2>&1 | Out-String)
if($LASTEXITCODE -ne 0 -or $version -notmatch '6\.2\.1\b' -or $version -notmatch '168116'){throw "Competition build requires TD 6.2.1. Found: $version"}
$started=Get-Date
$before=@{}
Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'user_source') -Recurse -File | ForEach-Object { $before[$_.FullName]=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash }
$configurationBefore=@{}
Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'td_project') -Recurse -File | Where-Object { $_.Extension.ToLowerInvariant() -in @('.al','.prj','.adc','.sdc','.cfg','.tcl') -and $_.Name -ne 'resume_route.tcl' } | ForEach-Object { $configurationBefore[$_.FullName]=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash }
$synthesisRecord=Join-Path $PSScriptRoot 'reference/filter_synthesis_provenance.json'
if($ReuseSynthesis) {
 if(-not (Test-Path -LiteralPath $synthesisRecord)){throw 'No checked synthesis provenance; run a full build first'}
 $reuse=Get-Content -LiteralPath $synthesisRecord -Raw | ConvertFrom-Json
 if(@($reuse.source_sha256.psobject.Properties).Count -ne $before.Count){throw 'Synthesis source membership changed'}
 foreach($entry in $reuse.source_sha256.psobject.Properties) {
  $path=Join-Path $PSScriptRoot $entry.Name
  if(-not $before.ContainsKey($path) -or (Get-Digest $path) -cne $entry.Value){throw "Synthesis source changed: $($entry.Name)"}
 }
 foreach($entry in $reuse.artifact_sha256.psobject.Properties) {
  if((Get-Digest (Join-Path $PSScriptRoot $entry.Name)) -cne $entry.Value){throw "Synthesis artifact changed: $($entry.Name)"}
 }
 Write-Output 'Reusing source-verified synthesized netlist; rerunning physical implementation.'
}
$stages=if($ReuseSynthesis){@('phy_1')}else{@('syn_1','phy_1')}
foreach($stage in $stages) {
 $runDir=Join-Path $PSScriptRoot "td_project/camera_to_dsi_display_Runs/$stage"
 Push-Location -LiteralPath $runDir
 try {
  '' | & $tool camera_to_dsi_display.tcl *> filter_final_work_console.log
  if($LASTEXITCODE -ne 0 -or (Get-Text (Join-Path $runDir 'filter_final_work_console.log')) -match '(?im)\b(?:ERROR|FATAL)\s*:'){throw "TD failed in $stage"}
  if($stage -eq 'phy_1') {
   '' | & $tool report_final.tcl *> filter_final_work_report.log
   if($LASTEXITCODE -ne 0 -or (Get-Text (Join-Path $runDir 'filter_final_work_report.log')) -match '(?im)\b(?:ERROR|FATAL)\s*:'){throw 'Final report failed'}
  }
 } finally {Pop-Location}
 Write-Output "$stage complete"
 if($stage -eq 'syn_1') {
  $provenance=[ordered]@{origin='Completed synthesis in this checked build';source_sha256=@{};artifact_sha256=@{}}
  foreach($path in $before.Keys){$relative=$path.Substring($PSScriptRoot.Length+1).Replace('\','/');$provenance.source_sha256[$relative]=$before[$path].ToLowerInvariant()}
  foreach($name in @('camera_to_dsi_display_gate.db','filter_final_work_console.log','.opt_gate.end.f')) {
   $relative='td_project/camera_to_dsi_display_Runs/syn_1/'+$name
   $provenance.artifact_sha256[$relative]=Get-Digest (Join-Path $PSScriptRoot $relative)
  }
  foreach($path in $configurationBefore.Keys) {
   if($path -notmatch '[\\/]phy_1[\\/]'){$relative=$path.Substring($PSScriptRoot.Length+1).Replace('\','/');$provenance.artifact_sha256[$relative]=$configurationBefore[$path].ToLowerInvariant()}
  }
  $provenance | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $synthesisRecord -Encoding UTF8
 }
}
foreach($path in $before.Keys){if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $before[$path]){throw "Source changed during build: $path"}}
$sourcesAfter=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'user_source') -Recurse -File)
if($sourcesAfter.Count -ne $before.Count -or @($sourcesAfter | Where-Object { -not $before.ContainsKey($_.FullName) }).Count -ne 0){throw 'Production source membership changed during build'}
foreach($path in $configurationBefore.Keys){if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $configurationBefore[$path]){throw "Configuration changed during build: $path"}}
$configurationAfter=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'td_project') -Recurse -File | Where-Object { $_.Extension.ToLowerInvariant() -in @('.al','.prj','.adc','.sdc','.cfg','.tcl') -and $_.Name -ne 'resume_route.tcl' })
if($configurationAfter.Count -ne $configurationBefore.Count -or @($configurationAfter | Where-Object { -not $configurationBefore.ContainsKey($_.FullName) }).Count -ne 0){throw 'Configuration membership changed during build'}
if((Get-Digest $PSCommandPath) -cne $scriptBefore){throw 'Build script changed during execution'}
$phy=Join-Path $PSScriptRoot 'td_project/camera_to_dsi_display_Runs/phy_1'
foreach($name in @('camera_to_dsi_display.bit','camera_to_dsi_display_pr.timing','camera_to_dsi_display_phy.area','route.qor')) {
 $output=Join-Path $phy $name
 if(-not (Test-Path -LiteralPath $output -PathType Leaf) -or (Get-Item -LiteralPath $output).Length -eq 0 -or (Get-Item -LiteralPath $output).LastWriteTime -lt $started){throw "Fresh nonempty build output missing: $name"}
}
$timing=Get-Text (Join-Path $phy 'camera_to_dsi_display_pr.timing')
$area=Get-Text (Join-Path $phy 'camera_to_dsi_display_phy.area')
if($area -notmatch 'Device:\s*PH1P35MDG324\b'){throw 'Routed resource report has the wrong device'}
$result=[ordered]@{tool=$version.Trim();started=$started.ToString('o');finished=(Get-Date).ToString('o')}
foreach($kind in @('SWNS','HWNS','STNS','HTNS')) {
 $m=[regex]::Match($timing,($kind+':\s*([-+0-9.]+)ns'))
 if(-not $m.Success){throw "Missing $kind"}
 $result[$kind]=[double]::Parse($m.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture)
 if([double]::IsNaN($result[$kind]) -or [double]::IsInfinity($result[$kind]) -or $result[$kind] -lt 0){throw "$kind timing failed; release is not updated"}
}
$capacities=@{slice=21216;eram=108;dsp=40;reg=42432}
foreach($kind in @('slice','eram','dsp','reg')) {
 $m=[regex]::Match($area,('(?m)^#'+$kind+'\s+(\d+)'))
 if(-not $m.Success){throw "Missing $kind resource count"}
 $result[$kind]=[int]$m.Groups[1].Value
 if($result[$kind] -lt 0 -or $result[$kind] -gt $capacities[$kind]){throw "Routed $kind count exceeds device capacity"}
}
if($result.eram -gt 108 -or $result.dsp -gt 40){throw 'RAM/DSP budget exceeded baseline'}
$release=Join-Path $PSScriptRoot 'release'
New-Item -ItemType Directory -Path $release -Force | Out-Null
$bit=Join-Path $phy 'camera_to_dsi_display.bit'
if(-not (Test-Path -LiteralPath $bit) -or (Get-Item -LiteralPath $bit).LastWriteTime -lt $started){throw 'Fresh BitGen output missing'}
Copy-Item -LiteralPath $bit -Destination (Join-Path $release 'final_work.bit') -Force
foreach($name in @('camera_to_dsi_display_pr.timing','camera_to_dsi_display_phy.area','route.qor')) {Copy-Item -LiteralPath (Join-Path $phy $name) -Destination $release -Force}
$result.device='PH1P35MDG324'
$result.placement_seed=3
$result.version='final work fruit and magic'
$result.status='passed'
$result.build_script_sha256=$scriptBefore
$result.reused_synthesis=[bool]$ReuseSynthesis
$result.synthesis_provenance_sha256=Get-Digest $synthesisRecord
$result.resource_capacity=$capacities
$result.board_validated=$false
$result.power_measured=$false
$result.source_sha256=@{}
foreach($path in $before.Keys){$relative=$path.Substring($PSScriptRoot.Length+1).Replace('\','/');$result.source_sha256[$relative]=$before[$path].ToLowerInvariant()}
$result.configuration_sha256=@{}
foreach($path in $configurationBefore.Keys){$relative=$path.Substring($PSScriptRoot.Length+1).Replace('\','/');$result.configuration_sha256[$relative]=$configurationBefore[$path].ToLowerInvariant()}
$result.bit_sha256=Get-Digest (Join-Path $release 'final_work.bit')
if($result.bit_sha256 -cne (Get-Digest $bit)){throw 'Released BIT differs from the fresh build output'}
$result.report_sha256=@{}
foreach($name in @('camera_to_dsi_display_pr.timing','camera_to_dsi_display_phy.area','route.qor')) {
 $result.report_sha256[('release/'+$name)]=Get-Digest (Join-Path $release $name)
 if($result.report_sha256[('release/'+$name)] -cne (Get-Digest (Join-Path $phy $name))){throw "Released report differs: $name"}
}
$result.log_sha256=@{}
foreach($name in @('syn_1/filter_final_work_console.log','phy_1/filter_final_work_console.log','phy_1/filter_final_work_report.log')) {
 $relative='td_project/camera_to_dsi_display_Runs/'+$name
 $result.log_sha256[$relative]=Get-Digest (Join-Path $PSScriptRoot $relative)
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $release 'build_result.json') -Encoding UTF8
"$($result.bit_sha256)  final_work.bit" | Set-Content -LiteralPath (Join-Path $release 'SHA256.txt') -Encoding ascii
Write-Output ([pscustomobject]$result | Select-Object version,SWNS,HWNS,slice,reg,eram,dsp,bit_sha256 | ConvertTo-Json)
Write-Output 'Build passed. Verify the filter regression records before board testing.'
