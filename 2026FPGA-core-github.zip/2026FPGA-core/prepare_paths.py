"""Prepare local TD/ROM paths; --relative restores portable package paths."""
from pathlib import Path
import argparse
import re

R = Path(__file__).resolve().parent
H = R / "user_source/hdl_source"
ASSETS = {
    "fruit_assets.v": {"SPRITE_FILE": "fruit_sprites.hex", "FONT_FILE": "fruit_font.hex"},
    "magic_assets.v": {"ASSET_FILE": "magic_assets.hex"},
    "night_live_tone.v": {"GAIN_FILE": "night_live_gain.hex", "CAP_FILE": "night_live_cap.hex"},
}

def prepare(relative=False):
    for p in (R / "td_project").rglob("*"):
        if p.suffix not in [".al", ".prj"]:
            continue
        path = ("." if p.suffix == ".al" else "../..") if relative else (R / "td_project").as_posix()
        s = p.read_text("utf-8-sig")
        s, count = re.subn(r'(<Project[^>]*\bPath=")[^"]+(")', lambda m: m[1] + path + m[2], s, count=1)
        if count != 1:
            raise ValueError(f"Project path not found in {p}")
        p.write_text(s, encoding="utf-8", newline="\n")
    for name, params in ASSETS.items():
        p = H / name
        s = p.read_text("utf-8")
        for param, asset in params.items():
            path = asset if relative else (H / asset).as_posix()
            if not (H / asset).is_file():
                raise FileNotFoundError(H / asset)
            s, count = re.subn(r'(' + param + r'\s*=\s*")[^"]+(")', lambda m: m[1] + path + m[2], s)
            if count != 1:
                raise ValueError(f"{param} not found in {p}")
        p.write_text(s, encoding="utf-8", newline="\n")
    print("Restored portable paths." if relative else "Prepared local TD project and ROM paths.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--relative", action="store_true")
    args = parser.parse_args()
    prepare(args.relative)
