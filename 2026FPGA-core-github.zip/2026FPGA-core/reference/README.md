# 构建记录

此目录用于完整构建时生成 filter_synthesis_provenance.json。
旧版对照源码和旧版验收记录未收入核心代码包。请首次执行完整构建，不使用 -ReuseSynthesis。
