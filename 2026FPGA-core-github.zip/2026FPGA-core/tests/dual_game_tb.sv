module dual_game_tb;
reg clk=0;always #5 clk=~clk;
reg rst_n=0,vs=0,de=0,color=1,night=0;
reg [1:0] keys=2'b10;
reg [23:0] rgb=0;
wire temp;wire [1:0] stable,sync;
wire allowed=color&&!night&&!temp;
color_temperature_display #(.DEBOUNCE_CYCLES(2),.HOLD_CYCLES(40),.STEP_CYCLES(20)) temperature(
 .clk(clk),.rst_n(rst_n),.keys_n(keys),.vs(vs),.hs(1'b0),.de(de),.rgb(rgb),
 .enabled(temp),.debounced_keys(stable),.synchronized_keys(sync));
reg ou=0,ov=1;reg [10:0] ox=400;reg [9:0] oy=320;reg [7:0] oid=1;
wire requested,selected,ovs,ode;wire [23:0] orgb;
dual_game #(.SHORT_CYCLES(30),.SECOND_CYCLES(10000000),.CHARGE_SAMPLES(3)) dut(
 .clk(clk),.rst_n(rst_n),.allowed(allowed),.vs(vs),.de(de),.rgb(rgb),.timer_tick(1'b1),
 .keys_n(keys),.debounced_keys(stable),.synchronized_keys(sync),
 .observation_update(ou),.observation_valid(ov),.observation_x(ox),.observation_y(oy),.observation_id(oid),
 .requested(requested),.selected_magic(selected),.out_vs(ovs),.out_de(ode),.out_rgb(orgb));
wire ref_f_vs,ref_f_de,ref_m_vs,ref_m_de;wire [23:0] ref_f_rgb,ref_m_rgb;
fruit_game_display reference_f(
        .clk(clk),.rst_n(rst_n),.vs(vs),.de(de),.rgb(rgb),
        .state(dut.S_game_state),.score10_bcd(dut.S_game_score),.time_bcd(dut.S_game_time),.combo(dut.S_game_combo),.flash(dut.S_game_flash),
        .cursor_valid(dut.S_game_cursor_valid),.cursor_x(dut.S_game_cursor_x),.cursor_y(dut.S_game_cursor_y),
        .previous_x(dut.S_game_previous_x),.previous_y(dut.S_game_previous_y),
        .fruit_state(dut.S_fruit_state),.fruit_kind(dut.S_fruit_kind),.fruit_x(dut.S_fruit_x),.fruit_y(dut.S_fruit_y),.fruit_age(dut.S_fruit_age),
        .out_vs(ref_f_vs),.out_de(ref_f_de),.out_rgb(ref_f_rgb));
magic_display reference_m(
        .clk(clk),.rst_n(rst_n),.vs(vs),.de(de),.rgb(rgb),
        .requested(dut.magic_requested),.cursor_valid(dut.S_magic_cursor_valid),.cursor_x(dut.S_magic_x),.cursor_y(dut.S_magic_y),
        .phase(dut.S_magic_phase),.charge(dut.S_magic_charge),.armed(dut.S_magic_armed),.wave_active(dut.S_magic_wave_active),
        .wave_x(dut.S_magic_wave_x),.wave_y(dut.S_magic_wave_y),.wave_age(dut.S_magic_wave_age),
        .out_vs(ref_m_vs),.out_de(ref_m_de),.out_rgb(ref_m_rgb));

reg [2:0] vp=0,dp=0,sp=0;reg [23:0] rp0=0,rp1=0,rp2=0;
integer checks=0,pixels=0;reg compare_pixels=0;
always @(posedge clk)if(rst_n)begin
 vp={vp[1:0],vs};dp={dp[1:0],de};sp={sp[1:0],selected};rp2=rp1;rp1=rp0;rp0=rgb;
 #1;
 if(ovs!==vp[2]||ode!==dp[2])$fatal(1,"combined video transport");
 if(ref_f_vs!==ref_m_vs||ref_f_de!==ref_m_de)$fatal(1,"renderer latency disagreement");
 if(dut.fruit_requested && dut.magic_requested)$fatal(1,"both activities enabled");
 if(compare_pixels && ode)begin
  if(orgb!==(sp[2]?ref_m_rgb:ref_f_rgb))$fatal(1,"combined versus standalone renderer mismatch");
  if(^orgb===1'bx)$fatal(1,"unknown combined pixel");
  pixels++;
 end
end
task wc(input integer n);repeat(n)@(negedge clk);endtask
task ck(input bit ok,input string why);begin
 if(!ok)$fatal(1,"%s requested=%b selected=%b fruit=%d magic=%b",why,requested,selected,dut.S_game_state,dut.magic_requested);
 checks++;
end endtask
task frame;begin vs=1;wc(5);vs=0;wc(8);end endtask
task press(input [1:0] value);begin keys=value;wc(12);keys=3;wc(12);end endtask
task obs(input integer x,input integer y,input bit valid);begin
 ox=x;oy=y;ov=valid;ou=1;wc(1);ou=0;wc(2);frame();
end endtask
task picture;begin
 compare_pixels=1;frame();
 for(integer y=0;y<720;y++)begin
  for(integer x=0;x<1280;x++)begin de=1;rgb={8'(x),8'(y),8'(x^y)};wc(1);end
  de=0;wc(370);
 end
 wc(8);compare_pixels=0;
end endtask
initial begin
 wc(3);rst_n=1;wc(15);keys=3;wc(15);frame();ck(!requested,"held-at-reset release ignored");
 press(1);frame();ck(!requested&&!selected,"inactive K2 ignored");
 press(2);ck(!requested,"K1 commits only on VS");frame();ck(requested&&!selected&&dut.S_game_state==1,"K1 starts fruit");
 frame();ck(requested,"VS-coincident routed K1 is consumed exactly once");
 obs(400,320,1);ck(dut.S_game_state==2&&dut.S_game_cursor_valid,"fruit accepts target");picture();
 press(1);ck(!selected,"K2 waits for VS");frame();ck(selected&&requested&&!dut.fruit_requested,"K2 enters magic and clears fruit");
 frame();ck(requested&&selected,"switch does not toggle again next frame");
 obs(400,320,1);repeat(3)obs(400,320,1);ck(dut.S_magic_armed,"magic still charges");picture();
 obs(456,320,1);ck(dut.S_magic_wave_active,"magic wave still casts");
 press(1);frame();ck(requested&&!selected&&!dut.S_magic_wave_active&&dut.S_game_state==1,"switch resets wave and fruit round");
 press(2);frame();ck(!requested,"K1 exits fruit");
 // Long single keys and both release orders of the temperature chord.
 keys=2;wc(55);keys=3;wc(12);frame();ck(!requested,"long K1 does not start");
 press(2);frame();ck(requested,"start before temperature chord");
 keys=0;wc(55);frame();ck(temp&&!requested,"temperature chord exits activity");
 keys=1;wc(12);keys=3;wc(12);frame();ck(!requested,"partial chord release cannot switch/start");
 press(2);frame();ck(temperature.level==1&&!requested,"K1 warms when temperature enabled");
 press(1);frame();ck(temperature.level==0&&!requested,"K2 cools when temperature enabled");
 keys=0;wc(55);keys=2;wc(12);keys=3;wc(12);frame();ck(!temp&&!requested,"reverse chord release cannot start");
 press(2);frame();press(1);frame();ck(selected&&requested,"magic selected before eligibility exit");
 color=0;frame();ck(!requested,"leave colour exits");color=1;frame();ck(!requested,"colour return stays inactive");
 press(2);frame();ck(selected&&requested,"K1 remembers magic selection");
 night=1;frame();ck(!requested,"night exits");night=0;frame();ck(!requested,"night off does not restart");
 // A partial gesture must be discarded when eligibility changes.
 keys=2;wc(10);color=0;wc(3);keys=3;wc(12);color=1;wc(5);frame();ck(!requested,"mode change cancels held gesture");
 ck(pixels==1843200,"two complete 720P streams compared");
 $display("PASS dual_game: %0d checks; %0d pixels; real temperature keys, frame switching, state reset and exact standalone renderer equivalence",checks,pixels);
 $finish;
end
endmodule
