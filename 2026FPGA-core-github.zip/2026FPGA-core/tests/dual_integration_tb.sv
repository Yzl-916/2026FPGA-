// Real CCL + tracker feeds magic controller, using actual raster video.
module dual_integration_tb;
reg clk=0;always #5 clk=~clk;
reg rst_n=0,vs=0,de=0,vs_d=0,key=0,allowed=1;reg [48:0] tag=0;reg [23:0] rgb=0;
wire req,cv,armed,wa,gu,gv;wire [8:0] cx,wx;wire [7:0] cy,wy,gid;wire [10:0] gx;wire [9:0] gy;
wire [6:0] phase;wire [5:0] charge,age;
always @(posedge clk)vs_d<=vs;
wire bvs,bde,dvs,dde,mvs,mde;wire [23:0] brgb,bscene,drgb,mrgb;
motion_overlay #(.ENABLE_MOTION(0),.SHARED_FONT(1)) bypass(
 .clk(clk),.rst_n(rst_n),.frame_mode_async(2'd0),.frame_tag_async(tag),
 .vs(vs),.hs(1'b0),.de(de),.scene_rgb(rgb),.rgb(rgb),.shared_font_data(16'd0),
 .out_vs(bvs),.out_de(bde),.out_rgb(brgb),.out_scene(bscene));
object_detection #(.IMG_WIDTH(320),.IMG_HEIGHT(192),.GAME_TAP_ENABLE(1)) detector(
 .clk(clk),.rst_n(rst_n),.teach_key_n(1'b1),.game_enable(req),.game_update(gu),.game_valid(gv),.game_x(gx),.game_y(gy),.game_id(gid),
 .frame_mode_async(2'd0),.frame_tag_async(tag),.vs(bvs),.hs(1'b0),.de(bde),.scene_rgb(bscene),.display_rgb(brgb),
 .out_vs(dvs),.out_de(dde),.out_rgb(drgb));
edge_morphology_display #(.IMG_WIDTH(320),.IMG_HEIGHT(192),.LINE_TOTAL(340)) morphology(
 .clk(clk),.rst_n(rst_n),.key_n(1'b1),.frame_mode_async(2'd0),.night_requested(1'b0),
 .vs(dvs),.de(dde),.rgb(drgb),.out_vs(mvs),.out_de(mde),.out_rgb(mrgb));
reg [1:0] keys=3;wire selected;
dual_game #(.SHORT_CYCLES(50),.SECOND_CYCLES(10000000),.CHARGE_SAMPLES(3)) core(
 .clk(clk),.rst_n(rst_n),.allowed(allowed),.vs(mvs),.de(mde),.rgb(mrgb),.timer_tick(1'b1),
 .keys_n(keys),.debounced_keys(keys),.synchronized_keys(keys),
 .observation_update(gu),.observation_valid(gv),.observation_x(gx),.observation_y(gy),.observation_id(gid),
 .requested(req),.selected_magic(selected));
assign cv=core.S_magic_cursor_valid;assign armed=core.S_magic_armed;assign wa=core.S_magic_wave_active;
assign charge=core.S_magic_charge;assign cx=core.S_magic_x;
task press(input [1:0] value);begin keys=value;repeat(10)@(negedge clk);keys=3;repeat(10)@(negedge clk);end endtask

integer frame=0,checks=0;reg saw_wave=0;
always @(posedge clk)if(wa)saw_wave<=1;
task ck(input bit ok,input string why);begin if(!ok)$fatal(1,"%s req=%b cv=%b charge=%d x=%d",why,req,cv,charge,cx);checks++;end endtask
task cycle(input bit v,input bit d,input [23:0] p);begin @(negedge clk);vs=v;de=d;rgb=p;end endtask
task image(input integer left,input bit second);begin
 frame++;tag={1'b1,32'd1,16'(frame)};
 repeat(20)cycle(1,0,0);repeat(20)cycle(0,0,0);
 for(integer y=0;y<192;y++)begin
  for(integer x=0;x<320;x++)begin
   if((x>=left&&x<left+72&&y>=64&&y<136)||(second&&x>=8&&x<80&&y>=64&&y<136))cycle(0,1,24'h30c050);
   else cycle(0,1,24'h202830);
  end
  repeat(20)cycle(0,0,0);
 end
 repeat(12000)cycle(0,0,0);
end endtask
initial begin
 repeat(3)@(negedge clk);rst_n=1;repeat(5)cycle(0,0,0);
 press(2);repeat(9)image(88,0);
 ck(req&&!selected&&core.S_game_state==2&&core.S_game_cursor_valid,"real CCL starts fruit play");
 press(1);repeat(9)image(88,0);
 ck(req&&cv&&armed,"real green raster charges magic");ck(cx>=29&&cx<=33,"CCL centre used by magic");
 repeat(4)image(144,0);ck(saw_wave,"real same-ID fast motion releases wave");
 repeat(6)image(144,1);ck(!cv&&charge==0,"two green markers clear charge through real detector");
 press(1);repeat(5)image(88,0);
 ck(req&&!selected&&core.S_game_state==2&&!wa,"real CCL continues into fresh fruit round after switching");
 allowed=0;image(144,0);ck(!req&&!wa&&!cv,"mode exit closes real detector session");
 $display("PASS dual_integration: %0d checks, real raster -> motion bypass -> CCL -> morphology transport -> fruit -> magic charge/cast -> ambiguity -> fruit -> exit",checks);$finish;
end
endmodule
