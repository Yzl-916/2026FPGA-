module fruit_core_tb;
reg clk=0;always #5 clk=~clk;
reg rst_n=0,ft=0,allowed=1,key=0,ou=0,ov=0;
reg[10:0] ox=0;reg[9:0] oy=0;reg[7:0] oid=1;
wire requested,cv;wire[1:0] state;wire[7:0] score,seconds;wire[3:0] combo,flash;
wire[8:0] cx,px;wire[7:0] cy,py;wire[5:0] fs,fk;wire[26:0] fx;wire[29:0] fy;wire[11:0] fa;
integer checks=0;
reg timer_tick=0;always @(negedge clk)timer_tick<=!timer_tick;
fruit_game_core #(.EXTERNAL_TICK(1),.SECOND_CYCLES(50000),.ROUND_SECONDS(3),.SPAWN_FRAMES(40),.STALE_FRAMES(4)) dut(
 .clk(clk),.rst_n(rst_n),.frame_tick(ft),.allowed(allowed),.key_press(key),.timer_tick(timer_tick),
 .observation_update(ou),.observation_valid(ov),.observation_x(ox),.observation_y(oy),.observation_id(oid),
 .requested(requested),.state(state),.score10_bcd(score),.time_bcd(seconds),.combo(combo),.flash(flash),
 .cursor_valid(cv),.cursor_x(cx),.cursor_y(cy),.previous_x(px),.previous_y(py),
 .fruit_state(fs),.fruit_kind(fk),.fruit_x(fx),.fruit_y(fy),.fruit_age(fa));
task waitc(input integer n);repeat(n)@(negedge clk);endtask
task tick;begin ft=1;waitc(1);ft=0;waitc(400);end endtask
task press;begin key=1;waitc(1);key=0;tick();end endtask
task obs(input integer x,input integer y,input bit valid,input[7:0] id);begin
 ox=x*4;oy=y*4;ov=valid;oid=id;ou=1;waitc(1);ou=0;waitc(2);tick();end endtask
task ck(input bit ok,input[511:0] m);begin if(!ok)$fatal(1,"%s state=%d score=%h",m,state,score);checks++;end endtask
// Seed geometry for directed collision-unit cases; all observation/worker/score
// transitions remain the real RTL. Natural spawning and timeout are also checked.
task target(input integer n,input integer x,input integer y,input integer kind);begin
 dut.fs[n]=1;dut.fx[n]=x;dut.fy[n]=y;dut.kind[n]=kind;dut.vx[n]=0;dut.vy[n]=0;dut.age[n]=0;
 dut.physics_phase=0;dut.gravity_phase=0;dut.spawn_count=63;
end endtask
task clean;begin for(integer i=0;i<3;i++)dut.fs[i]=0;dut.pending_hits=0;dut.score10_bcd=0;dut.combo=0;dut.combo_count=0;end endtask
initial begin
 waitc(3);rst_n=1;waitc(5);ck(state==0&&!requested,"reset off");press();ck(state==1&&requested,"one key enters ready");
 tick();ck(state==1&&seconds==8'h03,"wait for green target before timing");
 obs(60,80,1,1);ck(state==2&&cv,"first valid observation starts round");tick();ck(fs!=0,"natural fruit spawn");
 clean();target(0,100,80,0);obs(140,80,1,1);tick();ck(score==8'h01&&dut.fs[0]==2,"swept horizontal cut through target");
 tick();ck(score==8'h01,"same fruit scores once");
 clean();obs(100,80,1,1);target(0,100,80,0);obs(100,80,1,1);tick();ck(score==0&&dut.fs[0]==1,"stationary cursor cannot farm fruit");
 clean();obs(60,80,1,1);target(0,100,80,0);obs(140,80,1,2);tick();ck(score==0,"track ID change cannot cut across scene");
 clean();obs(60,80,1,1);obs(60,80,0,1);target(0,100,80,0);obs(140,80,1,1);tick();ck(score==0,"lost then reacquired target cannot cut");
 clean();obs(60,80,1,1);target(0,100,80,0);obs(250,80,1,1);tick();ck(score==0,"implausible large jump discarded");
 clean();obs(60,80,1,1);target(0,100,80,0);target(1,120,80,1);obs(140,80,1,1);tick();ck(score==8'h02&&combo==2,"one stroke can cut two fruit");
 clean();obs(60,80,1,1);target(0,100,80,3);dut.score10_bcd=8'h05;obs(140,80,1,1);tick();ck(score==8'h03&&flash!=0&&combo==0,"bomb deducts twenty and breaks combo");
 clean();obs(60,80,1,1);target(0,100,80,3);obs(140,80,1,1);tick();ck(score==0,"bomb score clamps at zero");
 clean();obs(70,50,1,1);target(0,100,80,2);obs(130,110,1,1);tick();ck(score==1,"diagonal swept cut");
 clean();obs(140,80,1,1);target(0,100,80,0);obs(60,80,1,1);tick();ck(score==1,"reverse direction swept cut");
 clean();obs(100,40,1,1);target(0,100,80,0);obs(100,120,1,1);tick();ck(score==1,"vertical swept cut");
 repeat(5)tick();ck(!cv,"stale observations hide cursor");
 press();ck(state==0,"K1 exits game");press();ck(state==1&&score==0,"K1 new round resets score");
 obs(100,80,1,1);repeat(1400)tick();ck(state==3&&seconds==0,"real second counter expires into result screen");
 press();ck(state==1&&score==0&&seconds==8'h03,"K1 restarts after result screen");
 allowed=0;tick();ck(state==0&&!requested,"mode/night/temperature exclusion exits game");
 allowed=1;tick();ck(state==0,"returning colour never auto-restarts");
 $display("PASS fruit_core: %0d checks, swept collision, gameplay and session lifecycle",checks);$finish;
end
endmodule
