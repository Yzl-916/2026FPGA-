module fruit_keys_tb;
reg clk=0;always #5 clk=~clk;
reg rst_n=0,colour=1,night=0;reg[1:0] keys=3;
wire enabled;wire signed[5:0] level;wire press;
wire [1:0] stable_keys,sync_keys;
reg timer_tick=0;always @(negedge clk)timer_tick<=!timer_tick;
integer pulses=0,checks=0;
fruit_key_control #(.EXTERNAL_KEYS(1),.EXTERNAL_TICK(1),.SHORT_CYCLES(12)) key(
 .clk(clk),.rst_n(rst_n),.enable(colour&&!night&&!enabled),.keys_n(keys),.press(press),
 .debounced_keys(stable_keys),.synchronized_keys(sync_keys),.timer_tick(timer_tick));
color_temperature_display #(.DEBOUNCE_CYCLES(3),.HOLD_CYCLES(40),.STEP_CYCLES(25)) temperature(
 .clk(clk),.rst_n(rst_n),.keys_n(keys),.vs(1'b0),.hs(1'b0),.de(1'b0),.rgb(24'd0),.enabled(enabled),.level(level),
 .debounced_keys(stable_keys),.synchronized_keys(sync_keys));
always @(posedge clk)if(press)pulses<=pulses+1;
task waitc(input integer n);repeat(n)@(negedge clk);endtask
task tap;begin keys=2;waitc(12);keys=3;waitc(12);end endtask
task ck(input bit ok,input[511:0] message);begin if(!ok)$fatal(1,"%s",message);checks++;end endtask
initial begin
 waitc(3);rst_n=1;waitc(15);tap();ck(pulses==1,"K1 short press starts game when temperature disabled");
 keys=2;waitc(50);keys=3;waitc(15);ck(pulses==1,"long hold must not enter or repeat");
 keys=0;waitc(50);ck(enabled&&level==0,"original colour-temperature chord enables neutral");
 keys=2;waitc(10);keys=3;waitc(15);ck(pulses==1,"chord partial release must not start game");
 tap();ck(pulses==1&&level==1,"temperature enabled K1 warms only");
 keys=1;waitc(12);keys=3;waitc(12);ck(level==0&&pulses==1,"K2 original cool step preserved");
 keys=0;waitc(50);keys=1;waitc(12);keys=3;waitc(15);ck(!enabled&&pulses==1,"disable chord must not start game");
 tap();ck(pulses==2,"K1 available after colour-temperature disable");
 colour=0;tap();ck(pulses==2,"other modes ignore game key");
 keys=2;waitc(10);colour=1;waitc(10);keys=3;waitc(15);ck(pulses==2,"held key through mode transition ignored");
 night=1;tap();night=0;waitc(15);ck(pulses==2,"night excludes game");
 keys=2;waitc(1);keys=3;waitc(1);keys=2;waitc(1);keys=3;waitc(12);ck(pulses==2,"bounce rejected");
 rst_n=0;keys=2;waitc(3);rst_n=1;waitc(15);keys=3;waitc(15);ck(pulses==2,"held at reset ignored");
 tap();ck(pulses==3,"stable release rearms after reset");
 $display("PASS fruit_keys: %0d checks, real temperature controller preserved",checks);$finish;
end
endmodule
