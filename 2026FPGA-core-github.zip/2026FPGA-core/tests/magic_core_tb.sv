module magic_core_tb;
reg clk=0;always #5 clk=~clk;
reg rst_n=0,frame=0,allowed=1,key=0,update=0,valid=0;
reg [10:0] x=640;reg [9:0] y=360;reg [7:0] id=1;
wire req,cv,armed,wa;wire [8:0] cx,wx;wire [7:0] cy,wy;wire [6:0] phase;wire [5:0] charge,age;
magic_core #(.CHARGE_SAMPLES(4),.STALE_FRAMES(3)) dut(clk,rst_n,frame,allowed,key,update,valid,x,y,id,req,cv,cx,wx,cy,wy,phase,charge,armed,wa,age);
integer checks=0;reg [5:0] saved;reg [8:0] origin;
task cycles(input integer n);repeat(n)@(negedge clk);endtask
task ck(input bit b,input string why);begin if(!b)$fatal(1,"%s",why);checks++;end endtask
task tick;begin frame=1;cycles(1);frame=0;cycles(2);end endtask
task press;begin key=1;cycles(1);key=0;cycles(1);tick();end endtask
task sample(input bit v,input integer xx,input integer yy,input integer ii);begin
 valid=v;x=xx;y=yy;id=ii;update=1;cycles(1);update=0;cycles(1);tick();end endtask
task charge_up;begin repeat(4)sample(1,x,y,id);end endtask
initial begin
 cycles(3);rst_n=1;cycles(3);ck(!req&&!cv&&!wa,"reset off");
 press();ck(req&&!cv,"K1 opens waiting state");
 sample(1,640,360,1);ck(cv&&cx==160&&cy==90&&charge==0,"first acquisition follows without charge");
 charge_up();ck(armed&&charge==4,"fresh stationary samples charge to full");
 sample(1,660,360,1);ck(armed&&!wa,"small movement keeps armed without casting");
 sample(1,724,360,1);ck(wa&&!armed&&wx==181&&wy==90&&age==0,"fast movement casts at current marker");
 origin=wx;sample(1,800,400,1);ck(wx==origin&&charge==0,"wave origin fixed during movement");
 repeat(32)tick();ck(!wa,"wave finishes in bounded time");ck(!cv&&!armed,"stale cursor disappears and clears charge");
 sample(1,800,400,1);ck(cv&&charge==0,"reacquisition cannot charge or cast immediately");
 sample(1,808,400,1);ck(charge==1,"small hover noise accepted");
 sample(1,832,400,1);ck(charge==0,"cumulative drift outside anchor resets charge");
 charge_up();sample(1,900,400,2);ck(!armed&&!wa&&charge==0,"new ID never casts");
 charge_up();sample(1,100,400,2);ck(!armed&&!wa,"large teleport never casts");
 charge_up();sample(0,100,400,2);ck(!cv&&!armed,"invalid observation immediately clears target");
 sample(1,100,400,2);charge_up();sample(1,1280,720,2);ck(!cv&&!armed,"out of range observation rejected");
 sample(1,120,200,3);sample(1,120,200,3);saved=charge;
 tick();tick();ck(charge==saved,"no new observation does not add charge");
 tick();ck(!cv&&charge==0,"exact stale bound enforced");
 // Snapshot does not change between frame boundaries.
 sample(1,600,300,4);x=700;update=1;cycles(1);update=0;cycles(12);ck(cx==150,"frame atomic target coordinates");tick();ck(cx==175,"mailbox commits next VS");
 press();ck(!req&&!cv&&!wa,"K1 closes overlay");
 // Key pulse exactly at VS is consumed once, never replayed next VS.
 key=1;frame=1;cycles(1);key=0;frame=0;cycles(2);tick();ck(req,"VS coincident key does not double toggle");
 allowed=0;tick();ck(!req&&!cv&&!wa,"mode temperature or night exit clears session");
 key=1;cycles(1);key=0;allowed=1;tick();ck(!req,"ineligible key not retained");
 press();sample(1,0,0,8);ck(cv&&cx==0&&cy==0,"top left boundary valid");
 sample(1,1279,719,8);ck(cv&&cx==319&&cy==179&&!wa,"bottom right boundary valid without teleport cast");
 $display("PASS magic_core: %0d checks, frame atomic input, charge, cast, ID/loss/teleport guards, wave lifetime, K1",checks);$finish;
end
endmodule
