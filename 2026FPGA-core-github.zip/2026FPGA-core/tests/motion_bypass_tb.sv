module motion_bypass_tb;
reg clk=0;always #5 clk=~clk;
reg rst_n=0,vs=0,hs=0,de=0;
reg [23:0] rgb=0,scene=0;
reg [1:0] mode=0;reg [48:0] tag=0;
wire ov,oh,od,en;wire [23:0] orgb,oscene;wire [8:0] addr;
motion_overlay #(.ENABLE_MOTION(0),.SHARED_FONT(1)) dut(
 .clk(clk),.rst_n(rst_n),.frame_mode_async(mode),.frame_tag_async(tag),
 .vs(vs),.hs(hs),.de(de),.scene_rgb(scene),.rgb(rgb),
 .out_vs(ov),.out_hs(oh),.out_de(od),.out_scene(oscene),.out_rgb(orgb),
 .shared_font_addr(addr),.shared_font_en(en),.shared_font_data(16'hffff));
reg [50:0] previous=0,expected=0;
integer checks=0;
always @(posedge clk or negedge rst_n) begin
 if(!rst_n) begin previous=0;expected=0;end
 else begin expected=previous;previous={vs,hs,de,scene,rgb};end
 #1;
 if({ov,oh,od,oscene,orgb}!==expected)$fatal(1,"motion bypass altered pixel/sync/latency at %0d",checks);
 if({en,addr}!==10'd0)$fatal(1,"disabled motion still reads shared font");
 checks++;
end
initial begin
 repeat(4)@(negedge clk);rst_n=1;
 for(integer n=0;n<30000;n++)begin
  @(negedge clk);
  rst_n=(n%4096)!=4095;
  vs=(n%1650)<5;hs=(n%370)<8;de=(n%1650)>=370;
  rgb=$random;scene=$random;mode=n%4;tag={$random,$random};
 end
 @(negedge clk);de=0;repeat(4)@(negedge clk);
 $display("PASS motion_bypass: %0d cycles, exact RGB/scene/VS/HS/DE two-clock transport, midstream reset, all modes, no font reads",checks);$finish;
end
endmodule
