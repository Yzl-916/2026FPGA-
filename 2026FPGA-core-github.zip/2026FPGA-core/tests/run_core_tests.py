"""Run six existing core regressions with an installed Icarus Verilog."""
from pathlib import Path
import argparse
import os
import shutil
import subprocess
import tempfile

R = Path(__file__).resolve().parents[1]
H = R / "user_source/hdl_source"
COMMON = ["dual_game", "dual_game_control", "fruit_key_control", "fruit_game_core", "fruit_game_display", "fruit_assets", "magic_core", "magic_display", "magic_assets"]
CASES = {
    "motion_bypass": ["motion_overlay"],
    "fruit_keys": ["fruit_key_control", "color_temperature_display"],
    "fruit_core": ["fruit_game_core"],
    "magic_core": ["magic_core"],
    "dual_game": COMMON + ["color_temperature_display"],
    "dual_integration": COMMON + ["motion_overlay", "edge_morphology_display", "morphology_binary_3x3_raster", "morphology_key_control", "object_detection", "object_ccl", "object_tracker", "object_overlay", "inspection_key_control", "visual_inspection", "inspection_overlay"],
}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--iverilog-dir", type=Path, help="Icarus installation root containing bin/ and lib/ivl/")
    parser.add_argument("cases", nargs="*", help="Optional case names; default: all six")
    args = parser.parse_args()
    cases = args.cases or list(CASES)
    for name in cases:
        if name not in CASES:
            parser.error("Unknown case: " + name)
    suffix = ".exe" if os.name == "nt" else ""
    if args.iverilog_dir:
        compiler = args.iverilog_dir.resolve() / ("bin/iverilog" + suffix)
        simulator = args.iverilog_dir.resolve() / ("bin/vvp" + suffix)
        ivl = args.iverilog_dir.resolve() / "lib/ivl"
    else:
        compiler = shutil.which("iverilog")
        simulator = shutil.which("vvp")
        ivl = None
    if not compiler or not simulator or not Path(compiler).is_file() or not Path(simulator).is_file():
        parser.error("Install Icarus Verilog and add bin to PATH, or pass --iverilog-dir.")
    output = R / "build/core_tests"
    output.mkdir(parents=True, exist_ok=True)
    for name in cases:
        files = [R / "tests" / (name + "_tb.sv")] + [H / (m + ".v") for m in CASES[name]]
        target = output / (name + ".vvp")
        command = [str(compiler)]
        if ivl:
            # Relative paths avoid legacy Windows compiler issues with non-ASCII parents.
            command += ["-B", os.path.relpath(ivl, H)]
        command += ["-g2012", "-s", name + "_tb", "-o", os.path.relpath(target, H)]
        command += [os.path.relpath(p, H) for p in files]
        stages = [("compile", command, H), ("sim", [str(simulator), os.path.relpath(target, H)], H)]
        for stage, command, cwd in stages:
            with tempfile.TemporaryDirectory(prefix="fpga-ivl-", dir=output) as scratch:
                env = dict(os.environ)
                env["PATH"] = str(Path(compiler).parent) + os.pathsep + env.get("PATH", "")
                env["TMPDIR"] = env["TMP"] = env["TEMP"] = os.path.relpath(scratch, cwd)
                result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, timeout=900)
            text = (result.stdout + result.stderr).decode("utf-8", errors="replace")
            (output / (name + "_" + stage + ".log")).write_text(text, encoding="utf-8")
            if result.returncode != 0 or (stage == "sim" and ("PASS " + name not in text or "FATAL" in text or "ERROR:" in text)):
                raise SystemExit(name + " " + stage + " failed:\n" + text)
            if stage == "sim":
                print(text.strip(), flush=True)
    print("PASS: all selected core regressions")

if __name__ == "__main__":
    main()
