// V21.37 lossless page/run indexed-colour LOGO; no added latency.
// Each 256-address page encodes repeated colours as disjoint inclusive runs.
module anlogic_logo_rom(input wire[14:0] I_addr,output reg[24:0] O_pixel);
reg[9:0]idx;
always @* begin
idx=0;case(I_addr[14:8])
7'd21:begin
case(I_addr[7:0])
8'd118:idx=10'd166;
8'd123:idx=10'd167;
8'd124:idx=10'd168;
8'd215:idx=10'd169;
8'd216:idx=10'd170;
default:idx=0;endcase
if(I_addr[7:0]>=8'd125 && I_addr[7:0]<=8'd214)idx=10'd6;
end
7'd22:begin
case(I_addr[7:0])
8'd21:idx=10'd69;
8'd22:idx=10'd70;
8'd23:idx=10'd171;
8'd28:idx=10'd172;
8'd29:idx=10'd71;
8'd118:idx=10'd173;
8'd119:idx=10'd72;
8'd120:idx=10'd174;
8'd181:idx=10'd73;
8'd182:idx=10'd74;
8'd183:idx=10'd75;
8'd188:idx=10'd175;
8'd189:idx=10'd176;
default:idx=0;endcase
if(I_addr[7:0]>=8'd30 && I_addr[7:0]<=8'd117)idx=10'd3;
if(I_addr[7:0]>=8'd190 && I_addr[7:0]<=8'd255)idx=10'd2;
end
7'd23:begin
case(I_addr[7:0])
8'd22:idx=10'd11;
8'd23:idx=10'd177;
8'd84:idx=10'd178;
8'd85:idx=10'd76;
8'd86:idx=10'd1;
8'd87:idx=10'd179;
8'd88:idx=10'd180;
8'd93:idx=10'd181;
8'd94:idx=10'd77;
8'd182:idx=10'd182;
8'd183:idx=10'd183;
8'd244:idx=10'd184;
8'd245:idx=10'd78;
8'd246:idx=10'd1;
8'd247:idx=10'd54;
8'd248:idx=10'd185;
8'd253:idx=10'd186;
8'd254:idx=10'd187;
8'd255:idx=10'd4;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd21)idx=10'd2;
if(I_addr[7:0]>=8'd95 && I_addr[7:0]<=8'd181)idx=10'd2;
end
7'd24:begin
case(I_addr[7:0])
8'd85:idx=10'd22;
8'd86:idx=10'd188;
8'd147:idx=10'd55;
8'd148:idx=10'd39;
8'd152:idx=10'd189;
8'd153:idx=10'd190;
8'd158:idx=10'd191;
8'd245:idx=10'd192;
8'd246:idx=10'd193;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd84)idx=10'd4;
if(I_addr[7:0]>=8'd149 && I_addr[7:0]<=8'd151)idx=10'd1;
if(I_addr[7:0]>=8'd159 && I_addr[7:0]<=8'd244)idx=10'd7;
end
7'd25:begin
case(I_addr[7:0])
8'd51:idx=10'd79;
8'd52:idx=10'd40;
8'd56:idx=10'd80;
8'd57:idx=10'd194;
8'd210:idx=10'd195;
8'd211:idx=10'd39;
8'd217:idx=10'd196;
8'd218:idx=10'd197;
default:idx=0;endcase
if(I_addr[7:0]>=8'd53 && I_addr[7:0]<=8'd55)idx=10'd1;
if(I_addr[7:0]>=8'd212 && I_addr[7:0]<=8'd216)idx=10'd1;
end
7'd26:begin
case(I_addr[7:0])
8'd114:idx=10'd198;
8'd115:idx=10'd37;
8'd121:idx=10'd56;
8'd122:idx=10'd81;
default:idx=0;endcase
if(I_addr[7:0]>=8'd116 && I_addr[7:0]<=8'd120)idx=10'd1;
end
7'd27:begin
case(I_addr[7:0])
8'd17:idx=10'd69;
8'd18:idx=10'd39;
8'd26:idx=10'd199;
8'd27:idx=10'd200;
8'd177:idx=10'd201;
8'd178:idx=10'd34;
8'd186:idx=10'd40;
8'd187:idx=10'd202;
default:idx=0;endcase
if(I_addr[7:0]>=8'd19 && I_addr[7:0]<=8'd25)idx=10'd1;
if(I_addr[7:0]>=8'd179 && I_addr[7:0]<=8'd185)idx=10'd1;
end
7'd28:begin
case(I_addr[7:0])
8'd80:idx=10'd203;
8'd81:idx=10'd39;
8'd91:idx=10'd39;
8'd92:idx=10'd57;
8'd97:idx=10'd204;
8'd98:idx=10'd205;
8'd178:idx=10'd206;
8'd179:idx=10'd82;
8'd240:idx=10'd79;
8'd241:idx=10'd41;
8'd251:idx=10'd41;
8'd252:idx=10'd83;
default:idx=0;endcase
if(I_addr[7:0]>=8'd82 && I_addr[7:0]<=8'd90)idx=10'd1;
if(I_addr[7:0]>=8'd99 && I_addr[7:0]<=8'd177)idx=10'd10;
if(I_addr[7:0]>=8'd242 && I_addr[7:0]<=8'd250)idx=10'd1;
end
7'd29:begin
case(I_addr[7:0])
8'd1:idx=10'd207;
8'd2:idx=10'd208;
8'd81:idx=10'd47;
8'd82:idx=10'd209;
8'd143:idx=10'd210;
8'd144:idx=10'd39;
8'd156:idx=10'd84;
8'd157:idx=10'd211;
8'd161:idx=10'd212;
8'd162:idx=10'd213;
8'd163:idx=10'd77;
8'd241:idx=10'd214;
8'd242:idx=10'd85;
default:idx=0;endcase
if(I_addr[7:0]>=8'd3 && I_addr[7:0]<=8'd80)idx=10'd8;
if(I_addr[7:0]>=8'd145 && I_addr[7:0]<=8'd155)idx=10'd1;
if(I_addr[7:0]>=8'd164 && I_addr[7:0]<=8'd240)idx=10'd2;
end
7'd30:begin
case(I_addr[7:0])
8'd47:idx=10'd86;
8'd48:idx=10'd41;
8'd60:idx=10'd34;
8'd61:idx=10'd87;
8'd66:idx=10'd215;
8'd67:idx=10'd88;
8'd144:idx=10'd24;
8'd145:idx=10'd216;
8'd206:idx=10'd89;
8'd207:idx=10'd58;
8'd221:idx=10'd217;
8'd222:idx=10'd218;
8'd226:idx=10'd90;
8'd227:idx=10'd91;
8'd228:idx=10'd24;
default:idx=0;endcase
if(I_addr[7:0]>=8'd49 && I_addr[7:0]<=8'd59)idx=10'd1;
if(I_addr[7:0]>=8'd68 && I_addr[7:0]<=8'd143)idx=10'd2;
if(I_addr[7:0]>=8'd208 && I_addr[7:0]<=8'd220)idx=10'd1;
if(I_addr[7:0]>=8'd229 && I_addr[7:0]<=8'd255)idx=10'd5;
end
7'd31:begin
case(I_addr[7:0])
8'd48:idx=10'd219;
8'd49:idx=10'd220;
8'd110:idx=10'd83;
8'd111:idx=10'd40;
8'd125:idx=10'd28;
8'd126:idx=10'd221;
8'd131:idx=10'd92;
8'd132:idx=10'd222;
8'd207:idx=10'd223;
8'd208:idx=10'd224;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd47)idx=10'd5;
if(I_addr[7:0]>=8'd112 && I_addr[7:0]<=8'd124)idx=10'd1;
if(I_addr[7:0]>=8'd133 && I_addr[7:0]<=8'd206)idx=10'd13;
end
7'd32:begin
case(I_addr[7:0])
8'd13:idx=10'd89;
8'd14:idx=10'd58;
8'd30:idx=10'd93;
8'd31:idx=10'd94;
8'd173:idx=10'd48;
8'd174:idx=10'd40;
8'd190:idx=10'd28;
8'd191:idx=10'd225;
default:idx=0;endcase
if(I_addr[7:0]>=8'd15 && I_addr[7:0]<=8'd29)idx=10'd1;
if(I_addr[7:0]>=8'd175 && I_addr[7:0]<=8'd189)idx=10'd1;
end
7'd33:begin
case(I_addr[7:0])
8'd76:idx=10'd57;
8'd77:idx=10'd58;
8'd95:idx=10'd95;
8'd96:idx=10'd226;
8'd236:idx=10'd48;
8'd237:idx=10'd40;
8'd255:idx=10'd28;
default:idx=0;endcase
if(I_addr[7:0]>=8'd78 && I_addr[7:0]<=8'd94)idx=10'd1;
if(I_addr[7:0]>=8'd238 && I_addr[7:0]<=8'd254)idx=10'd1;
end
7'd34:begin
case(I_addr[7:0])
8'd0:idx=10'd227;
8'd139:idx=10'd96;
8'd140:idx=10'd45;
8'd160:idx=10'd228;
8'd161:idx=10'd229;
default:idx=0;endcase
if(I_addr[7:0]>=8'd141 && I_addr[7:0]<=8'd159)idx=10'd1;
end
7'd35:begin
case(I_addr[7:0])
8'd43:idx=10'd230;
8'd44:idx=10'd41;
8'd64:idx=10'd28;
8'd65:idx=10'd231;
8'd70:idx=10'd232;
8'd71:idx=10'd233;
8'd140:idx=10'd234;
8'd141:idx=10'd235;
8'd202:idx=10'd236;
8'd203:idx=10'd45;
8'd225:idx=10'd97;
8'd226:idx=10'd237;
8'd230:idx=10'd238;
8'd231:idx=10'd239;
8'd232:idx=10'd240;
default:idx=0;endcase
if(I_addr[7:0]>=8'd45 && I_addr[7:0]<=8'd63)idx=10'd1;
if(I_addr[7:0]>=8'd72 && I_addr[7:0]<=8'd139)idx=10'd14;
if(I_addr[7:0]>=8'd204 && I_addr[7:0]<=8'd224)idx=10'd1;
if(I_addr[7:0]>=8'd233 && I_addr[7:0]<=8'd255)idx=10'd4;
end
7'd36:begin
case(I_addr[7:0])
8'd44:idx=10'd241;
8'd45:idx=10'd98;
8'd106:idx=10'd86;
8'd107:idx=10'd42;
8'd129:idx=10'd28;
8'd130:idx=10'd242;
8'd135:idx=10'd243;
8'd136:idx=10'd59;
8'd203:idx=10'd8;
8'd204:idx=10'd244;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd43)idx=10'd4;
if(I_addr[7:0]>=8'd108 && I_addr[7:0]<=8'd128)idx=10'd1;
if(I_addr[7:0]>=8'd137 && I_addr[7:0]<=8'd202)idx=10'd2;
end
7'd37:begin
case(I_addr[7:0])
8'd9:idx=10'd96;
8'd10:idx=10'd245;
8'd34:idx=10'd246;
8'd35:idx=10'd99;
8'd39:idx=10'd247;
8'd40:idx=10'd248;
8'd41:idx=10'd5;
8'd107:idx=10'd249;
8'd108:idx=10'd250;
8'd169:idx=10'd48;
8'd170:idx=10'd42;
8'd194:idx=10'd28;
8'd195:idx=10'd251;
8'd200:idx=10'd252;
8'd201:idx=10'd27;
default:idx=0;endcase
if(I_addr[7:0]>=8'd11 && I_addr[7:0]<=8'd33)idx=10'd1;
if(I_addr[7:0]>=8'd42 && I_addr[7:0]<=8'd106)idx=10'd2;
if(I_addr[7:0]>=8'd171 && I_addr[7:0]<=8'd193)idx=10'd1;
if(I_addr[7:0]>=8'd202 && I_addr[7:0]<=8'd255)idx=10'd3;
end
7'd38:begin
case(I_addr[7:0])
8'd10:idx=10'd47;
8'd11:idx=10'd253;
8'd72:idx=10'd254;
8'd73:idx=10'd45;
8'd99:idx=10'd100;
8'd100:idx=10'd255;
8'd104:idx=10'd256;
8'd105:idx=10'd257;
8'd170:idx=10'd258;
8'd171:idx=10'd259;
8'd232:idx=10'd48;
8'd233:idx=10'd34;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd9)idx=10'd3;
if(I_addr[7:0]>=8'd74 && I_addr[7:0]<=8'd98)idx=10'd1;
if(I_addr[7:0]>=8'd106 && I_addr[7:0]<=8'd169)idx=10'd15;
if(I_addr[7:0]>=8'd234 && I_addr[7:0]<=8'd255)idx=10'd1;
end
7'd39:begin
case(I_addr[7:0])
8'd3:idx=10'd26;
8'd4:idx=10'd260;
8'd135:idx=10'd101;
8'd136:idx=10'd45;
8'd164:idx=10'd102;
8'd165:idx=10'd261;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd2)idx=10'd1;
if(I_addr[7:0]>=8'd137 && I_addr[7:0]<=8'd163)idx=10'd1;
end
7'd40:begin
case(I_addr[7:0])
8'd39:idx=10'd262;
8'd40:idx=10'd34;
8'd68:idx=10'd26;
8'd69:idx=10'd263;
8'd198:idx=10'd49;
8'd199:idx=10'd45;
8'd229:idx=10'd264;
8'd230:idx=10'd265;
default:idx=0;endcase
if(I_addr[7:0]>=8'd41 && I_addr[7:0]<=8'd67)idx=10'd1;
if(I_addr[7:0]>=8'd200 && I_addr[7:0]<=8'd228)idx=10'd1;
end
7'd41:begin
case(I_addr[7:0])
8'd102:idx=10'd60;
8'd103:idx=10'd37;
8'd133:idx=10'd26;
8'd134:idx=10'd266;
8'd135:idx=10'd103;
default:idx=0;endcase
if(I_addr[7:0]>=8'd104 && I_addr[7:0]<=8'd132)idx=10'd1;
end
7'd42:begin
case(I_addr[7:0])
8'd5:idx=10'd49;
8'd6:idx=10'd104;
8'd38:idx=10'd61;
8'd39:idx=10'd267;
8'd44:idx=10'd268;
8'd45:idx=10'd269;
8'd103:idx=10'd270;
8'd165:idx=10'd62;
8'd166:idx=10'd41;
8'd198:idx=10'd105;
8'd199:idx=10'd70;
8'd200:idx=10'd106;
8'd204:idx=10'd271;
8'd205:idx=10'd272;
default:idx=0;endcase
if(I_addr[7:0]>=8'd7 && I_addr[7:0]<=8'd37)idx=10'd1;
if(I_addr[7:0]>=8'd46 && I_addr[7:0]<=8'd102)idx=10'd16;
if(I_addr[7:0]>=8'd167 && I_addr[7:0]<=8'd197)idx=10'd1;
if(I_addr[7:0]>=8'd206 && I_addr[7:0]<=8'd255)idx=10'd17;
end
7'd43:begin
case(I_addr[7:0])
8'd6:idx=10'd273;
8'd7:idx=10'd107;
8'd68:idx=10'd49;
8'd69:idx=10'd274;
8'd103:idx=10'd275;
8'd104:idx=10'd108;
8'd108:idx=10'd276;
8'd109:idx=10'd277;
8'd110:idx=10'd5;
8'd166:idx=10'd109;
8'd167:idx=10'd110;
8'd228:idx=10'd278;
8'd229:idx=10'd37;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd5)idx=10'd17;
if(I_addr[7:0]>=8'd70 && I_addr[7:0]<=8'd102)idx=10'd1;
if(I_addr[7:0]>=8'd111 && I_addr[7:0]<=8'd165)idx=10'd2;
if(I_addr[7:0]>=8'd230 && I_addr[7:0]<=8'd255)idx=10'd1;
end
7'd44:begin
case(I_addr[7:0])
8'd7:idx=10'd26;
8'd8:idx=10'd279;
8'd9:idx=10'd280;
8'd13:idx=10'd281;
8'd14:idx=10'd282;
8'd69:idx=10'd8;
8'd70:idx=10'd283;
8'd131:idx=10'd111;
8'd132:idx=10'd284;
8'd168:idx=10'd50;
8'd169:idx=10'd285;
8'd173:idx=10'd286;
8'd174:idx=10'd287;
8'd175:idx=10'd288;
8'd229:idx=10'd289;
8'd230:idx=10'd290;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd6)idx=10'd1;
if(I_addr[7:0]>=8'd15 && I_addr[7:0]<=8'd68)idx=10'd2;
if(I_addr[7:0]>=8'd133 && I_addr[7:0]<=8'd167)idx=10'd1;
if(I_addr[7:0]>=8'd176 && I_addr[7:0]<=8'd228)idx=10'd11;
end
7'd45:begin
case(I_addr[7:0])
8'd35:idx=10'd60;
8'd36:idx=10'd42;
8'd72:idx=10'd26;
8'd73:idx=10'd291;
8'd74:idx=10'd292;
8'd78:idx=10'd293;
8'd79:idx=10'd294;
8'd132:idx=10'd295;
8'd133:idx=10'd296;
8'd194:idx=10'd101;
8'd195:idx=10'd112;
8'd233:idx=10'd297;
8'd234:idx=10'd298;
default:idx=0;endcase
if(I_addr[7:0]>=8'd37 && I_addr[7:0]<=8'd71)idx=10'd1;
if(I_addr[7:0]>=8'd80 && I_addr[7:0]<=8'd131)idx=10'd18;
if(I_addr[7:0]>=8'd196 && I_addr[7:0]<=8'd232)idx=10'd1;
end
7'd46:begin
case(I_addr[7:0])
8'd98:idx=10'd299;
8'd99:idx=10'd300;
8'd137:idx=10'd26;
8'd138:idx=10'd301;
8'd139:idx=10'd302;
default:idx=0;endcase
if(I_addr[7:0]>=8'd100 && I_addr[7:0]<=8'd136)idx=10'd1;
end
7'd47:begin
case(I_addr[7:0])
8'd1:idx=10'd111;
8'd2:idx=10'd112;
8'd21:idx=10'd26;
8'd22:idx=10'd26;
8'd42:idx=10'd303;
8'd43:idx=10'd304;
8'd161:idx=10'd60;
8'd162:idx=10'd28;
8'd180:idx=10'd26;
8'd181:idx=10'd305;
8'd182:idx=10'd306;
8'd202:idx=10'd26;
8'd203:idx=10'd307;
8'd204:idx=10'd113;
default:idx=0;endcase
if(I_addr[7:0]>=8'd3 && I_addr[7:0]<=8'd20)idx=10'd1;
if(I_addr[7:0]>=8'd23 && I_addr[7:0]<=8'd41)idx=10'd1;
if(I_addr[7:0]>=8'd163 && I_addr[7:0]<=8'd179)idx=10'd1;
if(I_addr[7:0]>=8'd183 && I_addr[7:0]<=8'd201)idx=10'd1;
end
7'd48:begin
case(I_addr[7:0])
8'd64:idx=10'd51;
8'd65:idx=10'd308;
8'd84:idx=10'd43;
8'd85:idx=10'd309;
8'd86:idx=10'd310;
8'd87:idx=10'd52;
8'd107:idx=10'd52;
8'd108:idx=10'd114;
8'd224:idx=10'd62;
8'd225:idx=10'd28;
8'd243:idx=10'd26;
8'd244:idx=10'd311;
8'd245:idx=10'd113;
8'd246:idx=10'd115;
8'd247:idx=10'd312;
8'd248:idx=10'd313;
default:idx=0;endcase
if(I_addr[7:0]>=8'd66 && I_addr[7:0]<=8'd83)idx=10'd1;
if(I_addr[7:0]>=8'd88 && I_addr[7:0]<=8'd106)idx=10'd1;
if(I_addr[7:0]>=8'd226 && I_addr[7:0]<=8'd242)idx=10'd1;
if(I_addr[7:0]>=8'd249 && I_addr[7:0]<=8'd255)idx=10'd1;
end
7'd49:begin
case(I_addr[7:0])
8'd11:idx=10'd26;
8'd12:idx=10'd116;
8'd13:idx=10'd314;
8'd17:idx=10'd315;
8'd18:idx=10'd316;
8'd65:idx=10'd317;
8'd66:idx=10'd318;
8'd127:idx=10'd63;
8'd128:idx=10'd117;
8'd147:idx=10'd43;
8'd148:idx=10'd114;
8'd151:idx=10'd319;
8'd152:idx=10'd320;
8'd172:idx=10'd43;
8'd173:idx=10'd321;
8'd177:idx=10'd322;
8'd178:idx=10'd323;
8'd225:idx=10'd324;
8'd226:idx=10'd325;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd10)idx=10'd1;
if(I_addr[7:0]>=8'd19 && I_addr[7:0]<=8'd64)idx=10'd20;
if(I_addr[7:0]>=8'd129 && I_addr[7:0]<=8'd146)idx=10'd1;
if(I_addr[7:0]>=8'd153 && I_addr[7:0]<=8'd171)idx=10'd1;
if(I_addr[7:0]>=8'd179 && I_addr[7:0]<=8'd224)idx=10'd19;
end
7'd50:begin
case(I_addr[7:0])
8'd31:idx=10'd326;
8'd32:idx=10'd34;
8'd50:idx=10'd118;
8'd51:idx=10'd327;
8'd52:idx=10'd119;
8'd55:idx=10'd328;
8'd56:idx=10'd120;
8'd57:idx=10'd26;
8'd76:idx=10'd26;
8'd77:idx=10'd329;
8'd78:idx=10'd330;
8'd82:idx=10'd331;
8'd83:idx=10'd332;
8'd128:idx=10'd19;
8'd129:idx=10'd333;
8'd190:idx=10'd51;
8'd191:idx=10'd117;
8'd210:idx=10'd43;
8'd211:idx=10'd334;
8'd216:idx=10'd335;
8'd217:idx=10'd121;
8'd237:idx=10'd336;
8'd238:idx=10'd122;
8'd242:idx=10'd337;
8'd243:idx=10'd338;
default:idx=0;endcase
if(I_addr[7:0]>=8'd33 && I_addr[7:0]<=8'd49)idx=10'd1;
if(I_addr[7:0]>=8'd58 && I_addr[7:0]<=8'd75)idx=10'd1;
if(I_addr[7:0]>=8'd84 && I_addr[7:0]<=8'd127)idx=10'd2;
if(I_addr[7:0]>=8'd192 && I_addr[7:0]<=8'd209)idx=10'd1;
if(I_addr[7:0]>=8'd218 && I_addr[7:0]<=8'd236)idx=10'd1;
if(I_addr[7:0]>=8'd244 && I_addr[7:0]<=8'd255)idx=10'd2;
end
7'd51:begin
case(I_addr[7:0])
8'd32:idx=10'd339;
8'd33:idx=10'd340;
8'd94:idx=10'd64;
8'd95:idx=10'd34;
8'd114:idx=10'd341;
8'd115:idx=10'd342;
8'd121:idx=10'd343;
8'd122:idx=10'd28;
8'd142:idx=10'd344;
8'd143:idx=10'd123;
8'd147:idx=10'd345;
8'd148:idx=10'd47;
8'd191:idx=10'd346;
8'd192:idx=10'd347;
8'd253:idx=10'd63;
8'd254:idx=10'd46;
8'd255:idx=10'd1;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd31)idx=10'd2;
if(I_addr[7:0]>=8'd96 && I_addr[7:0]<=8'd113)idx=10'd1;
if(I_addr[7:0]>=8'd123 && I_addr[7:0]<=8'd141)idx=10'd1;
if(I_addr[7:0]>=8'd149 && I_addr[7:0]<=8'd190)idx=10'd5;
end
7'd52:begin
case(I_addr[7:0])
8'd17:idx=10'd348;
8'd18:idx=10'd124;
8'd25:idx=10'd349;
8'd26:idx=10'd350;
8'd46:idx=10'd351;
8'd47:idx=10'd125;
8'd51:idx=10'd352;
8'd52:idx=10'd126;
8'd95:idx=10'd126;
8'd96:idx=10'd353;
8'd157:idx=10'd354;
8'd158:idx=10'd34;
8'd177:idx=10'd355;
8'd178:idx=10'd356;
8'd186:idx=10'd357;
8'd187:idx=10'd28;
8'd207:idx=10'd127;
8'd208:idx=10'd358;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd16)idx=10'd1;
if(I_addr[7:0]>=8'd27 && I_addr[7:0]<=8'd45)idx=10'd1;
if(I_addr[7:0]>=8'd53 && I_addr[7:0]<=8'd94)idx=10'd21;
if(I_addr[7:0]>=8'd159 && I_addr[7:0]<=8'd176)idx=10'd1;
if(I_addr[7:0]>=8'd188 && I_addr[7:0]<=8'd206)idx=10'd1;
end
7'd53:begin
case(I_addr[7:0])
8'd60:idx=10'd51;
8'd61:idx=10'd46;
8'd80:idx=10'd43;
8'd81:idx=10'd359;
8'd90:idx=10'd360;
8'd91:idx=10'd361;
8'd111:idx=10'd128;
8'd112:idx=10'd362;
8'd220:idx=10'd64;
8'd221:idx=10'd34;
8'd239:idx=10'd9;
8'd240:idx=10'd363;
8'd241:idx=10'd129;
8'd251:idx=10'd364;
8'd252:idx=10'd37;
default:idx=0;endcase
if(I_addr[7:0]>=8'd62 && I_addr[7:0]<=8'd79)idx=10'd1;
if(I_addr[7:0]>=8'd92 && I_addr[7:0]<=8'd110)idx=10'd1;
if(I_addr[7:0]>=8'd222 && I_addr[7:0]<=8'd238)idx=10'd1;
if(I_addr[7:0]>=8'd253 && I_addr[7:0]<=8'd255)idx=10'd1;
end
7'd54:begin
case(I_addr[7:0])
8'd16:idx=10'd365;
8'd17:idx=10'd65;
8'd123:idx=10'd366;
8'd124:idx=10'd46;
8'd143:idx=10'd43;
8'd144:idx=10'd122;
8'd155:idx=10'd367;
8'd156:idx=10'd368;
8'd176:idx=10'd128;
8'd177:idx=10'd75;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd15)idx=10'd1;
if(I_addr[7:0]>=8'd125 && I_addr[7:0]<=8'd142)idx=10'd1;
if(I_addr[7:0]>=8'd157 && I_addr[7:0]<=8'd175)idx=10'd1;
end
7'd55:begin
case(I_addr[7:0])
8'd27:idx=10'd64;
8'd28:idx=10'd28;
8'd47:idx=10'd369;
8'd48:idx=10'd370;
8'd60:idx=10'd371;
8'd61:idx=10'd54;
8'd80:idx=10'd9;
8'd81:idx=10'd372;
8'd82:idx=10'd130;
8'd186:idx=10'd63;
8'd187:idx=10'd46;
8'd206:idx=10'd373;
8'd207:idx=10'd374;
8'd220:idx=10'd375;
8'd221:idx=10'd131;
8'd241:idx=10'd54;
8'd242:idx=10'd376;
8'd247:idx=10'd377;
default:idx=0;endcase
if(I_addr[7:0]>=8'd29 && I_addr[7:0]<=8'd46)idx=10'd1;
if(I_addr[7:0]>=8'd62 && I_addr[7:0]<=8'd79)idx=10'd1;
if(I_addr[7:0]>=8'd188 && I_addr[7:0]<=8'd205)idx=10'd1;
if(I_addr[7:0]>=8'd222 && I_addr[7:0]<=8'd240)idx=10'd1;
if(I_addr[7:0]>=8'd248 && I_addr[7:0]<=8'd255)idx=10'd23;
end
7'd56:begin
case(I_addr[7:0])
8'd27:idx=10'd378;
8'd28:idx=10'd379;
8'd90:idx=10'd132;
8'd91:idx=10'd28;
8'd110:idx=10'd380;
8'd111:idx=10'd381;
8'd125:idx=10'd133;
8'd126:idx=10'd134;
8'd146:idx=10'd135;
8'd147:idx=10'd382;
8'd151:idx=10'd383;
8'd152:idx=10'd384;
8'd187:idx=10'd385;
8'd188:idx=10'd386;
8'd249:idx=10'd136;
8'd250:idx=10'd93;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd26)idx=10'd23;
if(I_addr[7:0]>=8'd92 && I_addr[7:0]<=8'd109)idx=10'd1;
if(I_addr[7:0]>=8'd127 && I_addr[7:0]<=8'd145)idx=10'd1;
if(I_addr[7:0]>=8'd153 && I_addr[7:0]<=8'd186)idx=10'd22;
if(I_addr[7:0]>=8'd251 && I_addr[7:0]<=8'd255)idx=10'd1;
end
7'd57:begin
case(I_addr[7:0])
8'd13:idx=10'd38;
8'd14:idx=10'd387;
8'd29:idx=10'd129;
8'd30:idx=10'd116;
8'd50:idx=10'd80;
8'd51:idx=10'd388;
8'd55:idx=10'd389;
8'd56:idx=10'd390;
8'd90:idx=10'd5;
8'd91:idx=10'd391;
8'd92:idx=10'd392;
8'd153:idx=10'd393;
8'd154:idx=10'd28;
8'd172:idx=10'd26;
8'd173:idx=10'd394;
8'd174:idx=10'd395;
8'd190:idx=10'd396;
8'd191:idx=10'd74;
8'd211:idx=10'd137;
8'd212:idx=10'd397;
8'd216:idx=10'd398;
8'd217:idx=10'd8;
8'd250:idx=10'd47;
8'd251:idx=10'd399;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd12)idx=10'd1;
if(I_addr[7:0]>=8'd31 && I_addr[7:0]<=8'd49)idx=10'd1;
if(I_addr[7:0]>=8'd57 && I_addr[7:0]<=8'd89)idx=10'd2;
if(I_addr[7:0]>=8'd155 && I_addr[7:0]<=8'd171)idx=10'd1;
if(I_addr[7:0]>=8'd192 && I_addr[7:0]<=8'd210)idx=10'd1;
if(I_addr[7:0]>=8'd218 && I_addr[7:0]<=8'd249)idx=10'd2;
end
7'd58:begin
case(I_addr[7:0])
8'd56:idx=10'd400;
8'd57:idx=10'd401;
8'd76:idx=10'd38;
8'd77:idx=10'd402;
8'd94:idx=10'd138;
8'd95:idx=10'd403;
8'd96:idx=10'd9;
8'd115:idx=10'd56;
8'd116:idx=10'd404;
8'd120:idx=10'd110;
8'd121:idx=10'd109;
8'd153:idx=10'd405;
8'd154:idx=10'd406;
8'd155:idx=10'd407;
8'd216:idx=10'd408;
8'd217:idx=10'd28;
8'd236:idx=10'd409;
8'd237:idx=10'd410;
8'd255:idx=10'd411;
default:idx=0;endcase
if(I_addr[7:0]>=8'd58 && I_addr[7:0]<=8'd75)idx=10'd1;
if(I_addr[7:0]>=8'd97 && I_addr[7:0]<=8'd114)idx=10'd1;
if(I_addr[7:0]>=8'd122 && I_addr[7:0]<=8'd152)idx=10'd24;
if(I_addr[7:0]>=8'd218 && I_addr[7:0]<=8'd235)idx=10'd1;
end
7'd59:begin
case(I_addr[7:0])
8'd0:idx=10'd50;
8'd20:idx=10'd412;
8'd21:idx=10'd413;
8'd25:idx=10'd414;
8'd26:idx=10'd415;
8'd57:idx=10'd416;
8'd58:idx=10'd417;
8'd119:idx=10'd94;
8'd120:idx=10'd418;
8'd139:idx=10'd38;
8'd140:idx=10'd125;
8'd159:idx=10'd106;
8'd160:idx=10'd419;
8'd161:idx=10'd26;
8'd180:idx=10'd40;
8'd181:idx=10'd420;
default:idx=0;endcase
if(I_addr[7:0]>=8'd1 && I_addr[7:0]<=8'd19)idx=10'd1;
if(I_addr[7:0]>=8'd27 && I_addr[7:0]<=8'd56)idx=10'd25;
if(I_addr[7:0]>=8'd121 && I_addr[7:0]<=8'd138)idx=10'd1;
if(I_addr[7:0]>=8'd162 && I_addr[7:0]<=8'd179)idx=10'd1;
end
7'd60:begin
case(I_addr[7:0])
8'd23:idx=10'd421;
8'd24:idx=10'd28;
8'd43:idx=10'd127;
8'd44:idx=10'd422;
8'd64:idx=10'd139;
8'd65:idx=10'd97;
8'd85:idx=10'd423;
8'd86:idx=10'd424;
8'd182:idx=10'd140;
8'd183:idx=10'd425;
8'd202:idx=10'd38;
8'd203:idx=10'd426;
8'd225:idx=10'd427;
8'd226:idx=10'd28;
8'd245:idx=10'd37;
8'd246:idx=10'd428;
default:idx=0;endcase
if(I_addr[7:0]>=8'd25 && I_addr[7:0]<=8'd42)idx=10'd1;
if(I_addr[7:0]>=8'd66 && I_addr[7:0]<=8'd84)idx=10'd1;
if(I_addr[7:0]>=8'd184 && I_addr[7:0]<=8'd201)idx=10'd1;
if(I_addr[7:0]>=8'd227 && I_addr[7:0]<=8'd244)idx=10'd1;
end
7'd61:begin
case(I_addr[7:0])
8'd86:idx=10'd429;
8'd87:idx=10'd430;
8'd106:idx=10'd131;
8'd107:idx=10'd141;
8'd129:idx=10'd431;
8'd130:idx=10'd95;
8'd150:idx=10'd76;
8'd151:idx=10'd55;
8'd245:idx=10'd53;
8'd246:idx=10'd142;
default:idx=0;endcase
if(I_addr[7:0]>=8'd88 && I_addr[7:0]<=8'd105)idx=10'd1;
if(I_addr[7:0]>=8'd131 && I_addr[7:0]<=8'd149)idx=10'd1;
if(I_addr[7:0]>=8'd247 && I_addr[7:0]<=8'd255)idx=10'd1;
end
7'd62:begin
case(I_addr[7:0])
8'd9:idx=10'd38;
8'd10:idx=10'd432;
8'd34:idx=10'd433;
8'd35:idx=10'd434;
8'd54:idx=10'd34;
8'd55:idx=10'd73;
8'd149:idx=10'd435;
8'd150:idx=10'd34;
8'd169:idx=10'd436;
8'd170:idx=10'd437;
8'd194:idx=10'd438;
8'd195:idx=10'd104;
8'd215:idx=10'd39;
8'd216:idx=10'd49;
8'd220:idx=10'd439;
8'd221:idx=10'd440;
8'd246:idx=10'd441;
8'd247:idx=10'd442;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd8)idx=10'd1;
if(I_addr[7:0]>=8'd36 && I_addr[7:0]<=8'd53)idx=10'd1;
if(I_addr[7:0]>=8'd151 && I_addr[7:0]<=8'd168)idx=10'd1;
if(I_addr[7:0]>=8'd196 && I_addr[7:0]<=8'd214)idx=10'd1;
if(I_addr[7:0]>=8'd222 && I_addr[7:0]<=8'd245)idx=10'd29;
end
7'd63:begin
case(I_addr[7:0])
8'd52:idx=10'd53;
8'd53:idx=10'd142;
8'd72:idx=10'd38;
8'd73:idx=10'd443;
8'd99:idx=10'd444;
8'd100:idx=10'd37;
8'd119:idx=10'd37;
8'd120:idx=10'd87;
8'd124:idx=10'd445;
8'd125:idx=10'd446;
8'd150:idx=10'd447;
8'd151:idx=10'd448;
8'd212:idx=10'd66;
8'd213:idx=10'd34;
8'd232:idx=10'd143;
8'd233:idx=10'd65;
default:idx=0;endcase
if(I_addr[7:0]>=8'd54 && I_addr[7:0]<=8'd71)idx=10'd1;
if(I_addr[7:0]>=8'd101 && I_addr[7:0]<=8'd118)idx=10'd1;
if(I_addr[7:0]>=8'd126 && I_addr[7:0]<=8'd149)idx=10'd27;
if(I_addr[7:0]>=8'd214 && I_addr[7:0]<=8'd231)idx=10'd1;
end
7'd64:begin
case(I_addr[7:0])
8'd3:idx=10'd449;
8'd4:idx=10'd137;
8'd24:idx=10'd84;
8'd25:idx=10'd51;
8'd29:idx=10'd450;
8'd30:idx=10'd8;
8'd53:idx=10'd451;
8'd54:idx=10'd452;
8'd115:idx=10'd453;
8'd116:idx=10'd454;
8'd135:idx=10'd67;
8'd136:idx=10'd144;
8'd164:idx=10'd455;
8'd165:idx=10'd67;
8'd184:idx=10'd41;
8'd185:idx=10'd132;
8'd189:idx=10'd98;
8'd190:idx=10'd456;
8'd212:idx=10'd5;
8'd213:idx=10'd457;
8'd214:idx=10'd458;
default:idx=0;endcase
if(I_addr[7:0]>=8'd5 && I_addr[7:0]<=8'd23)idx=10'd1;
if(I_addr[7:0]>=8'd31 && I_addr[7:0]<=8'd52)idx=10'd2;
if(I_addr[7:0]>=8'd117 && I_addr[7:0]<=8'd134)idx=10'd1;
if(I_addr[7:0]>=8'd166 && I_addr[7:0]<=8'd183)idx=10'd1;
if(I_addr[7:0]>=8'd191 && I_addr[7:0]<=8'd211)idx=10'd2;
end
7'd65:begin
case(I_addr[7:0])
8'd19:idx=10'd66;
8'd20:idx=10'd28;
8'd39:idx=10'd143;
8'd40:idx=10'd130;
8'd68:idx=10'd141;
8'd69:idx=10'd459;
8'd89:idx=10'd460;
8'd90:idx=10'd140;
8'd94:idx=10'd461;
8'd95:idx=10'd3;
8'd116:idx=10'd462;
8'd117:idx=10'd463;
8'd178:idx=10'd53;
8'd179:idx=10'd44;
8'd198:idx=10'd145;
8'd199:idx=10'd144;
8'd229:idx=10'd464;
8'd230:idx=10'd465;
8'd249:idx=10'd42;
8'd250:idx=10'd466;
8'd254:idx=10'd467;
8'd255:idx=10'd468;
default:idx=0;endcase
if(I_addr[7:0]>=8'd21 && I_addr[7:0]<=8'd38)idx=10'd1;
if(I_addr[7:0]>=8'd70 && I_addr[7:0]<=8'd88)idx=10'd1;
if(I_addr[7:0]>=8'd96 && I_addr[7:0]<=8'd115)idx=10'd11;
if(I_addr[7:0]>=8'd180 && I_addr[7:0]<=8'd197)idx=10'd1;
if(I_addr[7:0]>=8'd231 && I_addr[7:0]<=8'd248)idx=10'd1;
end
7'd66:begin
case(I_addr[7:0])
8'd20:idx=10'd107;
8'd21:idx=10'd469;
8'd82:idx=10'd146;
8'd83:idx=10'd28;
8'd102:idx=10'd470;
8'd103:idx=10'd471;
8'd133:idx=10'd472;
8'd134:idx=10'd473;
8'd135:idx=10'd9;
8'd154:idx=10'd474;
8'd155:idx=10'd475;
8'd241:idx=10'd53;
8'd242:idx=10'd44;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd19)idx=10'd31;
if(I_addr[7:0]>=8'd84 && I_addr[7:0]<=8'd101)idx=10'd1;
if(I_addr[7:0]>=8'd136 && I_addr[7:0]<=8'd153)idx=10'd1;
if(I_addr[7:0]>=8'd243 && I_addr[7:0]<=8'd255)idx=10'd1;
end
7'd67:begin
case(I_addr[7:0])
8'd5:idx=10'd56;
8'd6:idx=10'd147;
8'd38:idx=10'd148;
8'd39:idx=10'd149;
8'd58:idx=10'd42;
8'd59:idx=10'd476;
8'd145:idx=10'd146;
8'd146:idx=10'd150;
8'd165:idx=10'd477;
8'd166:idx=10'd478;
8'd198:idx=10'd151;
8'd199:idx=10'd479;
8'd200:idx=10'd9;
8'd219:idx=10'd480;
8'd220:idx=10'd481;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd4)idx=10'd1;
if(I_addr[7:0]>=8'd40 && I_addr[7:0]<=8'd57)idx=10'd1;
if(I_addr[7:0]>=8'd147 && I_addr[7:0]<=8'd164)idx=10'd1;
if(I_addr[7:0]>=8'd201 && I_addr[7:0]<=8'd218)idx=10'd1;
end
7'd68:begin
case(I_addr[7:0])
8'd48:idx=10'd152;
8'd49:idx=10'd44;
8'd68:idx=10'd78;
8'd69:idx=10'd482;
8'd103:idx=10'd483;
8'd104:idx=10'd61;
8'd123:idx=10'd28;
8'd124:idx=10'd484;
8'd208:idx=10'd66;
8'd209:idx=10'd153;
8'd228:idx=10'd485;
8'd229:idx=10'd486;
8'd250:idx=10'd487;
8'd251:idx=10'd136;
default:idx=0;endcase
if(I_addr[7:0]>=8'd50 && I_addr[7:0]<=8'd67)idx=10'd1;
if(I_addr[7:0]>=8'd105 && I_addr[7:0]<=8'd122)idx=10'd1;
if(I_addr[7:0]>=8'd210 && I_addr[7:0]<=8'd227)idx=10'd1;
if(I_addr[7:0]>=8'd230 && I_addr[7:0]<=8'd249)idx=10'd32;
end
7'd69:begin
case(I_addr[7:0])
8'd8:idx=10'd488;
8'd9:idx=10'd26;
8'd28:idx=10'd489;
8'd29:idx=10'd490;
8'd111:idx=10'd154;
8'd112:idx=10'd44;
8'd132:idx=10'd491;
8'd154:idx=10'd492;
8'd155:idx=10'd120;
8'd156:idx=10'd493;
8'd168:idx=10'd494;
8'd169:idx=10'd495;
8'd188:idx=10'd28;
8'd189:idx=10'd496;
8'd194:idx=10'd497;
8'd209:idx=10'd92;
default:idx=0;endcase
if(I_addr[7:0]>=8'd10 && I_addr[7:0]<=8'd27)idx=10'd1;
if(I_addr[7:0]>=8'd113 && I_addr[7:0]<=8'd131)idx=10'd1;
if(I_addr[7:0]>=8'd133 && I_addr[7:0]<=8'd153)idx=10'd30;
if(I_addr[7:0]>=8'd170 && I_addr[7:0]<=8'd187)idx=10'd1;
if(I_addr[7:0]>=8'd195 && I_addr[7:0]<=8'd208)idx=10'd33;
end
7'd70:begin
case(I_addr[7:0])
8'd15:idx=10'd155;
8'd16:idx=10'd28;
8'd59:idx=10'd50;
8'd60:idx=10'd108;
8'd73:idx=10'd498;
8'd74:idx=10'd28;
8'd93:idx=10'd121;
8'd94:idx=10'd99;
8'd98:idx=10'd499;
8'd99:idx=10'd59;
8'd112:idx=10'd500;
8'd113:idx=10'd501;
8'd174:idx=10'd152;
8'd175:idx=10'd44;
8'd219:idx=10'd26;
8'd220:idx=10'd502;
8'd221:idx=10'd138;
8'd233:idx=10'd503;
8'd234:idx=10'd504;
8'd253:idx=10'd26;
8'd254:idx=10'd156;
default:idx=0;endcase
if(I_addr[7:0]>=8'd17 && I_addr[7:0]<=8'd58)idx=10'd1;
if(I_addr[7:0]>=8'd75 && I_addr[7:0]<=8'd92)idx=10'd1;
if(I_addr[7:0]>=8'd100 && I_addr[7:0]<=8'd111)idx=10'd35;
if(I_addr[7:0]>=8'd176 && I_addr[7:0]<=8'd218)idx=10'd1;
if(I_addr[7:0]>=8'd235 && I_addr[7:0]<=8'd252)idx=10'd1;
end
7'd71:begin
case(I_addr[7:0])
8'd2:idx=10'd85;
8'd3:idx=10'd157;
8'd15:idx=10'd5;
8'd16:idx=10'd505;
8'd17:idx=10'd506;
8'd78:idx=10'd507;
8'd79:idx=10'd158;
8'd124:idx=10'd52;
8'd125:idx=10'd148;
8'd138:idx=10'd508;
8'd139:idx=10'd34;
8'd158:idx=10'd100;
8'd159:idx=10'd139;
8'd163:idx=10'd509;
8'd164:idx=10'd24;
8'd175:idx=10'd59;
8'd176:idx=10'd510;
8'd237:idx=10'd511;
8'd238:idx=10'd512;
default:idx=0;endcase
if(I_addr[7:0]>=8'd4 && I_addr[7:0]<=8'd14)idx=10'd2;
if(I_addr[7:0]>=8'd80 && I_addr[7:0]<=8'd123)idx=10'd1;
if(I_addr[7:0]>=8'd140 && I_addr[7:0]<=8'd157)idx=10'd1;
if(I_addr[7:0]>=8'd165 && I_addr[7:0]<=8'd174)idx=10'd2;
if(I_addr[7:0]>=8'd239 && I_addr[7:0]<=8'd255)idx=10'd1;
end
7'd72:begin
case(I_addr[7:0])
8'd28:idx=10'd26;
8'd29:idx=10'd513;
8'd30:idx=10'd119;
8'd42:idx=10'd55;
8'd43:idx=10'd514;
8'd62:idx=10'd105;
8'd63:idx=10'd515;
8'd67:idx=10'd516;
8'd68:idx=10'd157;
8'd79:idx=10'd517;
8'd80:idx=10'd82;
8'd141:idx=10'd518;
8'd142:idx=10'd158;
8'd189:idx=10'd134;
8'd190:idx=10'd124;
8'd203:idx=10'd519;
8'd204:idx=10'd40;
8'd223:idx=10'd520;
8'd224:idx=10'd521;
8'd228:idx=10'd522;
8'd238:idx=10'd523;
8'd239:idx=10'd524;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd27)idx=10'd1;
if(I_addr[7:0]>=8'd44 && I_addr[7:0]<=8'd61)idx=10'd1;
if(I_addr[7:0]>=8'd69 && I_addr[7:0]<=8'd78)idx=10'd5;
if(I_addr[7:0]>=8'd143 && I_addr[7:0]<=8'd188)idx=10'd1;
if(I_addr[7:0]>=8'd205 && I_addr[7:0]<=8'd222)idx=10'd1;
if(I_addr[7:0]>=8'd229 && I_addr[7:0]<=8'd237)idx=10'd36;
end
7'd73:begin
case(I_addr[7:0])
8'd44:idx=10'd159;
8'd45:idx=10'd160;
8'd94:idx=10'd525;
8'd95:idx=10'd123;
8'd107:idx=10'd526;
8'd108:idx=10'd527;
8'd127:idx=10'd26;
8'd128:idx=10'd528;
8'd204:idx=10'd161;
8'd205:idx=10'd42;
8'd254:idx=10'd38;
8'd255:idx=10'd133;
default:idx=0;endcase
if(I_addr[7:0]>=8'd46 && I_addr[7:0]<=8'd93)idx=10'd1;
if(I_addr[7:0]>=8'd109 && I_addr[7:0]<=8'd126)idx=10'd1;
if(I_addr[7:0]>=8'd206 && I_addr[7:0]<=8'd253)idx=10'd1;
end
7'd74:begin
case(I_addr[7:0])
8'd12:idx=10'd529;
8'd13:idx=10'd38;
8'd32:idx=10'd530;
8'd33:idx=10'd531;
8'd107:idx=10'd532;
8'd108:idx=10'd44;
8'd159:idx=10'd533;
8'd160:idx=10'd65;
8'd172:idx=10'd534;
8'd173:idx=10'd535;
8'd174:idx=10'd118;
8'd192:idx=10'd26;
8'd193:idx=10'd536;
8'd194:idx=10'd103;
default:idx=0;endcase
if(I_addr[7:0]>=8'd14 && I_addr[7:0]<=8'd31)idx=10'd1;
if(I_addr[7:0]>=8'd109 && I_addr[7:0]<=8'd158)idx=10'd1;
if(I_addr[7:0]>=8'd175 && I_addr[7:0]<=8'd191)idx=10'd1;
end
7'd75:begin
case(I_addr[7:0])
8'd11:idx=10'd537;
8'd12:idx=10'd28;
8'd63:idx=10'd67;
8'd64:idx=10'd147;
8'd77:idx=10'd538;
8'd78:idx=10'd52;
8'd97:idx=10'd61;
8'd98:idx=10'd539;
8'd170:idx=10'd159;
8'd171:idx=10'd160;
8'd224:idx=10'd135;
8'd225:idx=10'd540;
8'd237:idx=10'd115;
8'd238:idx=10'd541;
8'd239:idx=10'd26;
default:idx=0;endcase
if(I_addr[7:0]>=8'd13 && I_addr[7:0]<=8'd62)idx=10'd1;
if(I_addr[7:0]>=8'd79 && I_addr[7:0]<=8'd96)idx=10'd1;
if(I_addr[7:0]>=8'd172 && I_addr[7:0]<=8'd223)idx=10'd1;
if(I_addr[7:0]>=8'd240 && I_addr[7:0]<=8'd255)idx=10'd1;
end
7'd76:begin
case(I_addr[7:0])
8'd0:idx=10'd1;
8'd1:idx=10'd26;
8'd2:idx=10'd542;
8'd3:idx=10'd543;
8'd74:idx=10'd544;
8'd75:idx=10'd28;
8'd128:idx=10'd145;
8'd129:idx=10'd81;
8'd142:idx=10'd545;
8'd143:idx=10'd162;
8'd162:idx=10'd50;
8'd163:idx=10'd546;
8'd167:idx=10'd547;
8'd171:idx=10'd548;
8'd172:idx=10'd549;
8'd233:idx=10'd154;
8'd234:idx=10'd163;
default:idx=0;endcase
if(I_addr[7:0]>=8'd76 && I_addr[7:0]<=8'd127)idx=10'd1;
if(I_addr[7:0]>=8'd144 && I_addr[7:0]<=8'd161)idx=10'd1;
if(I_addr[7:0]>=8'd168 && I_addr[7:0]<=8'd170)idx=10'd68;
if(I_addr[7:0]>=8'd235 && I_addr[7:0]<=8'd255)idx=10'd1;
end
7'd77:begin
case(I_addr[7:0])
8'd33:idx=10'd550;
8'd34:idx=10'd57;
8'd46:idx=10'd164;
8'd47:idx=10'd551;
8'd48:idx=10'd9;
8'd66:idx=10'd26;
8'd67:idx=10'd552;
8'd68:idx=10'd164;
8'd71:idx=10'd553;
8'd72:idx=10'd72;
8'd73:idx=10'd554;
8'd74:idx=10'd71;
8'd75:idx=10'd555;
8'd76:idx=10'd556;
8'd137:idx=10'd557;
8'd138:idx=10'd150;
8'd193:idx=10'd37;
8'd194:idx=10'd62;
8'd207:idx=10'd558;
8'd208:idx=10'd102;
8'd227:idx=10'd162;
8'd228:idx=10'd559;
8'd232:idx=10'd560;
8'd233:idx=10'd11;
8'd234:idx=10'd88;
8'd235:idx=10'd561;
default:idx=0;endcase
if(I_addr[7:0]>=8'd0 && I_addr[7:0]<=8'd32)idx=10'd1;
if(I_addr[7:0]>=8'd49 && I_addr[7:0]<=8'd65)idx=10'd1;
if(I_addr[7:0]>=8'd139 && I_addr[7:0]<=8'd192)idx=10'd1;
if(I_addr[7:0]>=8'd209 && I_addr[7:0]<=8'd226)idx=10'd1;
end
7'd78:begin
case(I_addr[7:0])
8'd40:idx=10'd562;
8'd41:idx=10'd163;
8'd98:idx=10'd46;
8'd99:idx=10'd563;
8'd112:idx=10'd156;
8'd113:idx=10'd26;
8'd131:idx=10'd26;
8'd132:idx=10'd564;
8'd133:idx=10'd151;
8'd136:idx=10'd565;
8'd137:idx=10'd566;
8'd138:idx=10'd91;
8'd139:idx=10'd90;
8'd200:idx=10'd161;
8'd201:idx=10'd153;
default:idx=0;endcase
if(I_addr[7:0]>=8'd42 && I_addr[7:0]<=8'd97)idx=10'd1;
if(I_addr[7:0]>=8'd114 && I_addr[7:0]<=8'd130)idx=10'd1;
if(I_addr[7:0]>=8'd202 && I_addr[7:0]<=8'd255)idx=10'd9;
end
7'd79:begin
case(I_addr[7:0])
8'd0:idx=10'd9;
8'd1:idx=10'd9;
8'd2:idx=10'd34;
8'd3:idx=10'd155;
8'd16:idx=10'd567;
8'd17:idx=10'd568;
8'd36:idx=10'd149;
8'd37:idx=10'd569;
8'd41:idx=10'd570;
8'd42:idx=10'd571;
8'd103:idx=10'd165;
8'd104:idx=10'd572;
8'd163:idx=10'd573;
8'd164:idx=10'd165;
8'd177:idx=10'd574;
8'd178:idx=10'd575;
8'd196:idx=10'd576;
8'd197:idx=10'd577;
8'd201:idx=10'd578;
8'd202:idx=10'd579;
default:idx=0;endcase
if(I_addr[7:0]>=8'd18 && I_addr[7:0]<=8'd35)idx=10'd9;
if(I_addr[7:0]>=8'd105 && I_addr[7:0]<=8'd162)idx=10'd12;
if(I_addr[7:0]>=8'd179 && I_addr[7:0]<=8'd195)idx=10'd12;
end
default:idx=0;endcase end
always @* begin case(idx)
10'd0: O_pixel=25'h0000000;
10'd1: O_pixel=25'h11c2d4e;
10'd2: O_pixel=25'h1ed1c24;
10'd3: O_pixel=25'h1f01e26;
10'd4: O_pixel=25'h1f01c25;
10'd5: O_pixel=25'h1ee1c24;
10'd6: O_pixel=25'h1f77e81;
10'd7: O_pixel=25'h1fa797d;
10'd8: O_pixel=25'h1ef1e26;
10'd9: O_pixel=25'h11c2d4f;
10'd10: O_pixel=25'h1f47579;
10'd11: O_pixel=25'h1ef1c24;
10'd12: O_pixel=25'h15b6579;
10'd13: O_pixel=25'h1f5646a;
10'd14: O_pixel=25'h1fa8084;
10'd15: O_pixel=25'h1f57276;
10'd16: O_pixel=25'h1f78a8c;
10'd17: O_pixel=25'h1f12027;
10'd18: O_pixel=25'h1f96b70;
10'd19: O_pixel=25'h1ef2027;
10'd20: O_pixel=25'h1f58386;
10'd21: O_pixel=25'h1f5595f;
10'd22: O_pixel=25'h1f11d25;
10'd23: O_pixel=25'h1fb8c90;
10'd24: O_pixel=25'h1ef1d25;
10'd25: O_pixel=25'h1f5666a;
10'd26: O_pixel=25'h11d2e4f;
10'd27: O_pixel=25'h1f2222a;
10'd28: O_pixel=25'h11e2f50;
10'd29: O_pixel=25'h1f89698;
10'd30: O_pixel=25'h1203050;
10'd31: O_pixel=25'h1f96065;
10'd32: O_pixel=25'h1838999;
10'd33: O_pixel=25'h1f69193;
10'd34: O_pixel=25'h11f3051;
10'd35: O_pixel=25'h1ef2129;
10'd36: O_pixel=25'h1f54e55;
10'd37: O_pixel=25'h1203151;
10'd38: O_pixel=25'h1233454;
10'd39: O_pixel=25'h13b4965;
10'd40: O_pixel=25'h1203152;
10'd41: O_pixel=25'h1203051;
10'd42: O_pixel=25'h11f3050;
10'd43: O_pixel=25'h1253555;
10'd44: O_pixel=25'h1334260;
10'd45: O_pixel=25'h1394764;
10'd46: O_pixel=25'h1354461;
10'd47: O_pixel=25'h1f12028;
10'd48: O_pixel=25'h17c8596;
10'd49: O_pixel=25'h1c9ccd2;
10'd50: O_pixel=25'h12a3a59;
10'd51: O_pixel=25'h1c7cad0;
10'd52: O_pixel=25'h1263656;
10'd53: O_pixel=25'h1c3c7ce;
10'd54: O_pixel=25'h1223353;
10'd55: O_pixel=25'h1cdcfd5;
10'd56: O_pixel=25'h1213252;
10'd57: O_pixel=25'h1ccced4;
10'd58: O_pixel=25'h13a4864;
10'd59: O_pixel=25'h1f1222a;
10'd60: O_pixel=25'h1798294;
10'd61: O_pixel=25'h12b3b59;
10'd62: O_pixel=25'h1798193;
10'd63: O_pixel=25'h1c6c9d0;
10'd64: O_pixel=25'h1767f91;
10'd65: O_pixel=25'h1d8dade;
10'd66: O_pixel=25'h1727c8f;
10'd67: O_pixel=25'h1233353;
10'd68: O_pixel=25'h1fb9a9d;
10'd69: O_pixel=25'h1cccfd5;
10'd70: O_pixel=25'h15f697f;
10'd71: O_pixel=25'h1f21f27;
10'd72: O_pixel=25'h1f62c34;
10'd73: O_pixel=25'h17f8798;
10'd74: O_pixel=25'h1263757;
10'd75: O_pixel=25'h18d94a3;
10'd76: O_pixel=25'h13c4a65;
10'd77: O_pixel=25'h1ee1d25;
10'd78: O_pixel=25'h1213152;
10'd79: O_pixel=25'h1808898;
10'd80: O_pixel=25'h1213253;
10'd81: O_pixel=25'h1838b9b;
10'd82: O_pixel=25'h1fcd9da;
10'd83: O_pixel=25'h17d8596;
10'd84: O_pixel=25'h1394763;
10'd85: O_pixel=25'h1fab2b4;
10'd86: O_pixel=25'h17e8697;
10'd87: O_pixel=25'h17b8394;
10'd88: O_pixel=25'h1f1242c;
10'd89: O_pixel=25'h1cbced4;
10'd90: O_pixel=25'h1fcdedf;
10'd91: O_pixel=25'h1f54b51;
10'd92: O_pixel=25'h1faacae;
10'd93: O_pixel=25'h1364461;
10'd94: O_pixel=25'h1c4c7ce;
10'd95: O_pixel=25'h1344360;
10'd96: O_pixel=25'h1cacdd3;
10'd97: O_pixel=25'h12f3f5d;
10'd98: O_pixel=25'h1fab8ba;
10'd99: O_pixel=25'h1b9bdc6;
10'd100: O_pixel=25'h12d3d5b;
10'd101: O_pixel=25'h1c9cbd2;
10'd102: O_pixel=25'h12c3c5a;
10'd103: O_pixel=25'h1eaebed;
10'd104: O_pixel=25'h1384663;
10'd105: O_pixel=25'h11c2e4f;
10'd106: O_pixel=25'h1e9eaec;
10'd107: O_pixel=25'h1fa7176;
10'd108: O_pixel=25'h1abb0ba;
10'd109: O_pixel=25'h1f4343a;
10'd110: O_pixel=25'h1fac1c3;
10'd111: O_pixel=25'h1c8cbd1;
10'd112: O_pixel=25'h1374663;
10'd113: O_pixel=25'h1e3e4e7;
10'd114: O_pixel=25'h19fa5b1;
10'd115: O_pixel=25'h1e2e4e7;
10'd116: O_pixel=25'h14f5b74;
10'd117: O_pixel=25'h1364562;
10'd118: O_pixel=25'h11d2e4e;
10'd119: O_pixel=25'h1e2e3e6;
10'd120: O_pixel=25'h1606a80;
10'd121: O_pixel=25'h12f3e5c;
10'd122: O_pixel=25'h1999fac;
10'd123: O_pixel=25'h1dddee2;
10'd124: O_pixel=25'h19ba2ae;
10'd125: O_pixel=25'h1959ba9;
10'd126: O_pixel=25'h1f8676c;
10'd127: O_pixel=25'h148556f;
10'd128: O_pixel=25'h1223354;
10'd129: O_pixel=25'h1dfe1e4;
10'd130: O_pixel=25'h1d6d8dd;
10'd131: O_pixel=25'h147546e;
10'd132: O_pixel=25'h1778092;
10'd133: O_pixel=25'h1959ca9;
10'd134: O_pixel=25'h1243555;
10'd135: O_pixel=25'h1424f6a;
10'd136: O_pixel=25'h1c6c9cf;
10'd137: O_pixel=25'h1404e69;
10'd138: O_pixel=25'h1e5e6e9;
10'd139: O_pixel=25'h1b6bac3;
10'd140: O_pixel=25'h1c5c8cf;
10'd141: O_pixel=25'h1dadce0;
10'd142: O_pixel=25'h1334360;
10'd143: O_pixel=25'h145526c;
10'd144: O_pixel=25'h18e95a3;
10'd145: O_pixel=25'h1223253;
10'd146: O_pixel=25'h1737d90;
10'd147: O_pixel=25'h18c93a2;
10'd148: O_pixel=25'h1a3a9b5;
10'd149: O_pixel=25'h1283858;
10'd150: O_pixel=25'h11d2e50;
10'd151: O_pixel=25'h1e6e7ea;
10'd152: O_pixel=25'h1c2c6cd;
10'd153: O_pixel=25'h11d2f50;
10'd154: O_pixel=25'h1c1c4cc;
10'd155: O_pixel=25'h1717b8f;
10'd156: O_pixel=25'h1677186;
10'd157: O_pixel=25'h1f32b32;
10'd158: O_pixel=25'h11e2f51;
10'd159: O_pixel=25'h1c2c5cd;
10'd160: O_pixel=25'h132425f;
10'd161: O_pixel=25'h1707a8e;
10'd162: O_pixel=25'h1293958;
10'd163: O_pixel=25'h1324160;
10'd164: O_pixel=25'h1e8e9eb;
10'd165: O_pixel=25'h1d8d9dd;
10'd166: O_pixel=25'h1d3d4d8;
10'd167: O_pixel=25'h1fcd5d5;
10'd168: O_pixel=25'h1f88688;
10'd169: O_pixel=25'h1f87e82;
10'd170: O_pixel=25'h1fba9ab;
10'd171: O_pixel=25'h1d6d9dd;
10'd172: O_pixel=25'h1f8575d;
10'd173: O_pixel=25'h1f11e26;
10'd174: O_pixel=25'h1faabae;
10'd175: O_pixel=25'h1f9a6a9;
10'd176: O_pixel=25'h1f2282f;
10'd177: O_pixel=25'h1f75d62;
10'd178: O_pixel=25'h1ced0d6;
10'd179: O_pixel=25'h143516b;
10'd180: O_pixel=25'h1d5d7dc;
10'd181: O_pixel=25'h1f6565b;
10'd182: O_pixel=25'h1f32a32;
10'd183: O_pixel=25'h1faaeb0;
10'd184: O_pixel=25'h17f8797;
10'd185: O_pixel=25'h18990a0;
10'd186: O_pixel=25'h1f9a3a5;
10'd187: O_pixel=25'h1f3272f;
10'd188: O_pixel=25'h1f75d63;
10'd189: O_pixel=25'h1414e6a;
10'd190: O_pixel=25'h1d3d5da;
10'd191: O_pixel=25'h1fb8c8f;
10'd192: O_pixel=25'h1fb7a7f;
10'd193: O_pixel=25'h1fbbfc1;
10'd194: O_pixel=25'h1868d9d;
10'd195: O_pixel=25'h1cdd0d5;
10'd196: O_pixel=25'h13f4c68;
10'd197: O_pixel=25'h1d0d3d8;
10'd198: O_pixel=25'h1818999;
10'd199: O_pixel=25'h13d4a66;
10'd200: O_pixel=25'h1cfd1d6;
10'd201: O_pixel=25'h17f8799;
10'd202: O_pixel=25'h1818898;
10'd203: O_pixel=25'h1cccfd4;
10'd204: O_pixel=25'h1f89b9d;
10'd205: O_pixel=25'h1f57579;
10'd206: O_pixel=25'h1f77f82;
10'd207: O_pixel=25'h1f99ea0;
10'd208: O_pixel=25'h1f2272e;
10'd209: O_pixel=25'h1f86166;
10'd210: O_pixel=25'h1ccced3;
10'd211: O_pixel=25'h1caccd2;
10'd212: O_pixel=25'h1fcdfe0;
10'd213: O_pixel=25'h1f54e53;
10'd214: O_pixel=25'h1f32c33;
10'd215: O_pixel=25'h1f89b9e;
10'd216: O_pixel=25'h1f76167;
10'd217: O_pixel=25'h1384562;
10'd218: O_pixel=25'h1c7c9d0;
10'd219: O_pixel=25'h1f42d34;
10'd220: O_pixel=25'h1fab3b5;
10'd221: O_pixel=25'h1788092;
10'd222: O_pixel=25'h1f7666c;
10'd223: O_pixel=25'h1f6646a;
10'd224: O_pixel=25'h1fa898d;
10'd225: O_pixel=25'h1757d8f;
10'd226: O_pixel=25'h1c0c3cb;
10'd227: O_pixel=25'h16f788c;
10'd228: O_pixel=25'h131415e;
10'd229: O_pixel=25'h1bdc1c8;
10'd230: O_pixel=25'h17d8496;
10'd231: O_pixel=25'h16b7589;
10'd232: O_pixel=25'h1facdce;
10'd233: O_pixel=25'h1fb8689;
10'd234: O_pixel=25'h1fb8185;
10'd235: O_pixel=25'h1fab5b8;
10'd236: O_pixel=25'h1cbced3;
10'd237: O_pixel=25'h1babfc7;
10'd238: O_pixel=25'h1fcd8d8;
10'd239: O_pixel=25'h1f6454b;
10'd240: O_pixel=25'h1f11c25;
10'd241: O_pixel=25'h1f52f36;
10'd242: O_pixel=25'h1677287;
10'd243: O_pixel=25'h1f88d90;
10'd244: O_pixel=25'h1f6676c;
10'd245: O_pixel=25'h1394864;
10'd246: O_pixel=25'h12e3d5c;
10'd247: O_pixel=25'h1fcd7d8;
10'd248: O_pixel=25'h1f54349;
10'd249: O_pixel=25'h1f22e36;
10'd250: O_pixel=25'h1fababc;
10'd251: O_pixel=25'h1667085;
10'd252: O_pixel=25'h1f88e91;
10'd253: O_pixel=25'h1f6696e;
10'd254: O_pixel=25'h1c9ccd3;
10'd255: O_pixel=25'h1b6bac4;
10'd256: O_pixel=25'h1fcddde;
10'd257: O_pixel=25'h1f98084;
10'd258: O_pixel=25'h1f7777b;
10'd259: O_pixel=25'h1fbc9ca;
10'd260: O_pixel=25'h1636e84;
10'd261: O_pixel=25'h1b4b9c2;
10'd262: O_pixel=25'h17b8495;
10'd263: O_pixel=25'h1636e83;
10'd264: O_pixel=25'h12c3b5a;
10'd265: O_pixel=25'h1b2b6c0;
10'd266: O_pixel=25'h1616b81;
10'd267: O_pixel=25'h1afb4bd;
10'd268: O_pixel=25'h1fba2a4;
10'd269: O_pixel=25'h1f88a8d;
10'd270: O_pixel=25'h1fa9699;
10'd271: O_pixel=25'h1fa8b8e;
10'd272: O_pixel=25'h1f5252c;
10'd273: O_pixel=25'h1f32129;
10'd274: O_pixel=25'h1384662;
10'd275: O_pixel=25'h12a3b59;
10'd276: O_pixel=25'h1fcd3d4;
10'd277: O_pixel=25'h1f54046;
10'd278: O_pixel=25'h1798293;
10'd279: O_pixel=25'h15b667d;
10'd280: O_pixel=25'h1e7e8eb;
10'd281: O_pixel=25'h1f88589;
10'd282: O_pixel=25'h1f12129;
10'd283: O_pixel=25'h1f77377;
10'd284: O_pixel=25'h1374662;
10'd285: O_pixel=25'h1a8adb8;
10'd286: O_pixel=25'h1fcd2d3;
10'd287: O_pixel=25'h1f53f46;
10'd288: O_pixel=25'h1f01c24;
10'd289: O_pixel=25'h1f4343b;
10'd290: O_pixel=25'h1fbc2c4;
10'd291: O_pixel=25'h159647b;
10'd292: O_pixel=25'h1e6e7e9;
10'd293: O_pixel=25'h1fb9ea1;
10'd294: O_pixel=25'h1fa6c71;
10'd295: O_pixel=25'h1fa6c70;
10'd296: O_pixel=25'h1f99093;
10'd297: O_pixel=25'h1283958;
10'd298: O_pixel=25'h1a5aab5;
10'd299: O_pixel=25'h17a8395;
10'd300: O_pixel=25'h11e3050;
10'd301: O_pixel=25'h1556178;
10'd302: O_pixel=25'h1e5e6e8;
10'd303: O_pixel=25'h1273757;
10'd304: O_pixel=25'h1a3a8b3;
10'd305: O_pixel=25'h1434f68;
10'd306: O_pixel=25'h13c4964;
10'd307: O_pixel=25'h1535e76;
10'd308: O_pixel=25'h1364561;
10'd309: O_pixel=25'h1a0a7b3;
10'd310: O_pixel=25'h19a9fad;
10'd311: O_pixel=25'h14f5c75;
10'd312: O_pixel=25'h1546078;
10'd313: O_pixel=25'h11d2d4f;
10'd314: O_pixel=25'h1e1e2e5;
10'd315: O_pixel=25'h1fbc3c4;
10'd316: O_pixel=25'h1f68487;
10'd317: O_pixel=25'h1f68689;
10'd318: O_pixel=25'h1fabfc0;
10'd319: O_pixel=25'h1a7acb7;
10'd320: O_pixel=25'h12a3958;
10'd321: O_pixel=25'h19da3af;
10'd322: O_pixel=25'h1fbcccd;
10'd323: O_pixel=25'h1f63e44;
10'd324: O_pixel=25'h1f43b41;
10'd325: O_pixel=25'h1fbc8c9;
10'd326: O_pixel=25'h1778193;
10'd327: O_pixel=25'h14f5b75;
10'd328: O_pixel=25'h1e8e9ec;
10'd329: O_pixel=25'h14e5a73;
10'd330: O_pixel=25'h1dfe0e3;
10'd331: O_pixel=25'h1f77f83;
10'd332: O_pixel=25'h1f01f27;
10'd333: O_pixel=25'h1f7797d;
10'd334: O_pixel=25'h19ea4b0;
10'd335: O_pixel=25'h1b5b9c1;
10'd336: O_pixel=25'h1243454;
10'd337: O_pixel=25'h1fbcbcc;
10'd338: O_pixel=25'h1f43a41;
10'd339: O_pixel=25'h1f33940;
10'd340: O_pixel=25'h1fbc8ca;
10'd341: O_pixel=25'h14e5b74;
10'd342: O_pixel=25'h1e1e3e6;
10'd343: O_pixel=25'h16b7488;
10'd344: O_pixel=25'h14a5670;
10'd345: O_pixel=25'h1f87c80;
10'd346: O_pixel=25'h1f02027;
10'd347: O_pixel=25'h1f87b7f;
10'd348: O_pixel=25'h1253655;
10'd349: O_pixel=25'h1bfc3ca;
10'd350: O_pixel=25'h133425f;
10'd351: O_pixel=25'h1233354;
10'd352: O_pixel=25'h1fbcfd0;
10'd353: O_pixel=25'h1fccfd0;
10'd354: O_pixel=25'h1757e91;
10'd355: O_pixel=25'h14e5b73;
10'd356: O_pixel=25'h1e0e1e5;
10'd357: O_pixel=25'h1747e90;
10'd358: O_pixel=25'h1dbdce0;
10'd359: O_pixel=25'h19ba1ae;
10'd360: O_pixel=25'h1c7cad1;
10'd361: O_pixel=25'h1374562;
10'd362: O_pixel=25'h18f96a5;
10'd363: O_pixel=25'h14d5a73;
10'd364: O_pixel=25'h17d8597;
10'd365: O_pixel=25'h144526d;
10'd366: O_pixel=25'h1c5c9d0;
10'd367: O_pixel=25'h1d0d2d7;
10'd368: O_pixel=25'h13f4d68;
10'd369: O_pixel=25'h14d5972;
10'd370: O_pixel=25'h1dee0e3;
10'd371: O_pixel=25'h18b91a1;
10'd372: O_pixel=25'h143516c;
10'd373: O_pixel=25'h1243554;
10'd374: O_pixel=25'h1999fad;
10'd375: O_pixel=25'h1d9dadf;
10'd376: O_pixel=25'h18a92a1;
10'd377: O_pixel=25'h1fb9a9c;
10'd378: O_pixel=25'h1fb8d90;
10'd379: O_pixel=25'h1fca3a6;
10'd380: O_pixel=25'h14b5872;
10'd381: O_pixel=25'h1dedfe3;
10'd382: O_pixel=25'h1d6d7dc;
10'd383: O_pixel=25'h1f97276;
10'd384: O_pixel=25'h1f32028;
10'd385: O_pixel=25'h1f42129;
10'd386: O_pixel=25'h1f98185;
10'd387: O_pixel=25'h1989eac;
10'd388: O_pixel=25'h18991a0;
10'd389: O_pixel=25'h1fac2c4;
10'd390: O_pixel=25'h1f3353c;
10'd391: O_pixel=25'h1f43c43;
10'd392: O_pixel=25'h1fccfcf;
10'd393: O_pixel=25'h1768091;
10'd394: O_pixel=25'h14a5771;
10'd395: O_pixel=25'h1dddfe2;
10'd396: O_pixel=25'h1a0a6b2;
10'd397: O_pixel=25'h1d3d6da;
10'd398: O_pixel=25'h1f77477;
10'd399: O_pixel=25'h1f88286;
10'd400: O_pixel=25'h1c4c8ce;
10'd401: O_pixel=25'h1344461;
10'd402: O_pixel=25'h1989eab;
10'd403: O_pixel=25'h156627a;
10'd404: O_pixel=25'h1878e9e;
10'd405: O_pixel=25'h1f01d25;
10'd406: O_pixel=25'h1f53d44;
10'd407: O_pixel=25'h1fcd0d1;
10'd408: O_pixel=25'h1757f91;
10'd409: O_pixel=25'h149566f;
10'd410: O_pixel=25'h1dcdee2;
10'd411: O_pixel=25'h1a9aeb9;
10'd412: O_pixel=25'h13e4c67;
10'd413: O_pixel=25'h1d1d4d9;
10'd414: O_pixel=25'h1f99092;
10'd415: O_pixel=25'h1f6666a;
10'd416: O_pixel=25'h1f6676b;
10'd417: O_pixel=25'h1fa9a9d;
10'd418: O_pixel=25'h1344361;
10'd419: O_pixel=25'h1626c82;
10'd420: O_pixel=25'h1858d9c;
10'd421: O_pixel=25'h1747e91;
10'd422: O_pixel=25'h1dbdde1;
10'd423: O_pixel=25'h13d4b67;
10'd424: O_pixel=25'h1cfd1d7;
10'd425: O_pixel=25'h1354361;
10'd426: O_pixel=25'h19399a7;
10'd427: O_pixel=25'h16d768a;
10'd428: O_pixel=25'h1828a9a;
10'd429: O_pixel=25'h1737c90;
10'd430: O_pixel=25'h11f2f51;
10'd431: O_pixel=25'h1c1c4cb;
10'd432: O_pixel=25'h19097a5;
10'd433: O_pixel=25'h1788093;
10'd434: O_pixel=25'h11f2f50;
10'd435: O_pixel=25'h1717b8e;
10'd436: O_pixel=25'h146536d;
10'd437: O_pixel=25'h1d9dbdf;
10'd438: O_pixel=25'h1c9cdd3;
10'd439: O_pixel=25'h1f9c3c4;
10'd440: O_pixel=25'h1f9979a;
10'd441: O_pixel=25'h1f8999b;
10'd442: O_pixel=25'h1fbd1d1;
10'd443: O_pixel=25'h18f96a4;
10'd444: O_pixel=25'h180889a;
10'd445: O_pixel=25'h1fabdbf;
10'd446: O_pixel=25'h1f6353c;
10'd447: O_pixel=25'h1f7454b;
10'd448: O_pixel=25'h1fcd4d5;
10'd449: O_pixel=25'h1d2d4d9;
10'd450: O_pixel=25'h1f7676c;
10'd451: O_pixel=25'h1f12128;
10'd452: O_pixel=25'h1f98a8e;
10'd453: O_pixel=25'h1c3c6ce;
10'd454: O_pixel=25'h1344260;
10'd455: O_pixel=25'h18e94a3;
10'd456: O_pixel=25'h1f22e35;
10'd457: O_pixel=25'h1f54147;
10'd458: O_pixel=25'h1fcd4d6;
10'd459: O_pixel=25'h149556f;
10'd460: O_pixel=25'h1374561;
10'd461: O_pixel=25'h1f6666b;
10'd462: O_pixel=25'h1f22129;
10'd463: O_pixel=25'h1f98b8e;
10'd464: O_pixel=25'h1999eab;
10'd465: O_pixel=25'h1253656;
10'd466: O_pixel=25'h1737c8f;
10'd467: O_pixel=25'h1fbc0c2;
10'd468: O_pixel=25'h1fa676d;
10'd469: O_pixel=25'h1fcd8da;
10'd470: O_pixel=25'h143506b;
10'd471: O_pixel=25'h1d6d8dc;
10'd472: O_pixel=25'h1e1e2e6;
10'd473: O_pixel=25'h1515e76;
10'd474: O_pixel=25'h1354360;
10'd475: O_pixel=25'h1c3c6cc;
10'd476: O_pixel=25'h1717a8d;
10'd477: O_pixel=25'h142506a;
10'd478: O_pixel=25'h1d5d7db;
10'd479: O_pixel=25'h158647c;
10'd480: O_pixel=25'h132415e;
10'd481: O_pixel=25'h1c0c3ca;
10'd482: O_pixel=25'h18a91a0;
10'd483: O_pixel=25'h1acb1bb;
10'd484: O_pixel=25'h16c768a;
10'd485: O_pixel=25'h1243452;
10'd486: O_pixel=25'h1676f82;
10'd487: O_pixel=25'h1868c9c;
10'd488: O_pixel=25'h1646e84;
10'd489: O_pixel=25'h131405d;
10'd490: O_pixel=25'h1bdc0c8;
10'd491: O_pixel=25'h11d2d4e;
10'd492: O_pixel=25'h1213151;
10'd493: O_pixel=25'h1e9eaed;
10'd494: O_pixel=25'h1b9bdc5;
10'd495: O_pixel=25'h1313f5d;
10'd496: O_pixel=25'h16a7488;
10'd497: O_pixel=25'h1fa9d9f;
10'd498: O_pixel=25'h170798c;
10'd499: O_pixel=25'h1f96569;
10'd500: O_pixel=25'h1f3282f;
10'd501: O_pixel=25'h1fa8f93;
10'd502: O_pixel=25'h1566179;
10'd503: O_pixel=25'h1c3c7cd;
10'd504: O_pixel=25'h1364462;
10'd505: O_pixel=25'h1f5444a;
10'd506: O_pixel=25'h1fcd8d9;
10'd507: O_pixel=25'h1717a8e;
10'd508: O_pixel=25'h17b8395;
10'd509: O_pixel=25'h1f75e63;
10'd510: O_pixel=25'h1f88e92;
10'd511: O_pixel=25'h1c1c5cc;
10'd512: O_pixel=25'h1324260;
10'd513: O_pixel=25'h1505c75;
10'd514: O_pixel=25'h13a4865;
10'd515: O_pixel=25'h1646f84;
10'd516: O_pixel=25'h1fab0b2;
10'd517: O_pixel=25'h1f5454c;
10'd518: O_pixel=25'h16f798d;
10'd519: O_pixel=25'h1838b9c;
10'd520: O_pixel=25'h12c3c5b;
10'd521: O_pixel=25'h1b3b7c1;
10'd522: O_pixel=25'h1fa7579;
10'd523: O_pixel=25'h1f64f55;
10'd524: O_pixel=25'h1fa9c9f;
10'd525: O_pixel=25'h14c5872;
10'd526: O_pixel=25'h1d3d6db;
10'd527: O_pixel=25'h1414f6a;
10'd528: O_pixel=25'h1616c82;
10'd529: O_pixel=25'h19096a5;
10'd530: O_pixel=25'h12b3b5a;
10'd531: O_pixel=25'h1b0b5bf;
10'd532: O_pixel=25'h1c2c5cc;
10'd533: O_pixel=25'h148546e;
10'd534: O_pixel=25'h1dcdde1;
10'd535: O_pixel=25'h14b5871;
10'd536: O_pixel=25'h15f6a80;
10'd537: O_pixel=25'h1707a8d;
10'd538: O_pixel=25'h19ba1ad;
10'd539: O_pixel=25'h1aeb3bd;
10'd540: O_pixel=25'h1d2d5d9;
10'd541: O_pixel=25'h1545f77;
10'd542: O_pixel=25'h15c677e;
10'd543: O_pixel=25'h1eaeaed;
10'd544: O_pixel=25'h1727b8f;
10'd545: O_pixel=25'h1a6abb6;
10'd546: O_pixel=25'h1adb1bc;
10'd547: O_pixel=25'h1fcbfc0;
10'd548: O_pixel=25'h1fc9ea0;
10'd549: O_pixel=25'h1fddadb;
10'd550: O_pixel=25'h13c4965;
10'd551: O_pixel=25'h15b677d;
10'd552: O_pixel=25'h15a667c;
10'd553: O_pixel=25'h1faaaac;
10'd554: O_pixel=25'h1f11f27;
10'd555: O_pixel=25'h1f94c52;
10'd556: O_pixel=25'h1fddcdd;
10'd557: O_pixel=25'h1727b8e;
10'd558: O_pixel=25'h1afb4be;
10'd559: O_pixel=25'h1aaafb9;
10'd560: O_pixel=25'h1f65a5f;
10'd561: O_pixel=25'h1f8989a;
10'd562: O_pixel=25'h1c0c4cb;
10'd563: O_pixel=25'h1c5c9cf;
10'd564: O_pixel=25'h158637b;
10'd565: O_pixel=25'h1f9a8ab;
10'd566: O_pixel=25'h1f32931;
10'd567: O_pixel=25'h1bbbfc6;
10'd568: O_pixel=25'h132405e;
10'd569: O_pixel=25'h1a6acb7;
10'd570: O_pixel=25'h1f86065;
10'd571: O_pixel=25'h1f9989b;
10'd572: O_pixel=25'h16e7688;
10'd573: O_pixel=25'h16e7687;
10'd574: O_pixel=25'h18b909f;
10'd575: O_pixel=25'h15b657a;
10'd576: O_pixel=25'h15c657a;
10'd577: O_pixel=25'h1898e9c;
10'd578: O_pixel=25'h1fbc3c5;
10'd579: O_pixel=25'h1fde0e1;
default: O_pixel=0;endcase end
endmodule
