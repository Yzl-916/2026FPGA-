// Display-only sketch / emboss / shared-window Gaussian / thresholded sharpen.
// Three registered pixel stages in every mode; no extra filter frame latency.
// The inspection/tracking scene remains bit-exact and aligned with the display.
// One 1280x10 synchronous line RAM: 8-bit gray + 2-bit raw sketch strength.
// Sketch gets stronger strokes and a causal 2x2 maximum; emboss is unchanged.
// No multiplier, additional pixel stage or frame buffer.
module art_style_display #(
    parameter integer ENABLE_FILTERS=0,
    parameter integer ENABLE_GAUSSIAN=1,
    parameter integer IMG_WIDTH=1280,
    parameter integer IMG_HEIGHT=720,
    parameter integer DEBOUNCE_CYCLES=750000,
    parameter integer PRESERVE_OSD=1,
    parameter integer SHOW_STATUS=1
)(
    input wire clk,rst_n,key_n,
    input wire [2:0] frame_effect_mode,
    input wire [23:0] filter_gaussian_rgb,
    input wire [23:0] filter_sharpen_rgb,
    input wire [1:0] frame_mode_async,
    input wire night_requested,
    input wire vs,hs,de,
    input wire [23:0] scene_rgb,rgb,
    output reg out_vs,out_hs,out_de,
    output reg [23:0] out_scene,out_rgb,
    output wire [2:0] selected_mode,
    output reg [2:0] active_mode
);
    reg [1:0] mode_meta,mode_sync;
    reg frame_pending;
    reg [10:0] x;
    reg [9:0] y;
    wire valid_pixel=de && !vs;
    wire art_enabled=(mode_sync==2'd0) && !night_requested;
    wire [2:0] pixel_style=frame_pending ?
        (ENABLE_FILTERS ? frame_effect_mode:(art_enabled ? selected_mode:3'd0)):active_mode;
    generate if(ENABLE_FILTERS)begin:g_filter_key
        display_filter_key_control #(.DEBOUNCE_CYCLES(DEBOUNCE_CYCLES),.ENABLE_GAUSSIAN(ENABLE_GAUSSIAN)) u_key(
            .clk(clk),.rst_n(rst_n),.key_n(key_n),.enable(art_enabled),.selected_mode(selected_mode));
    end else begin:g_legacy_key
        wire [1:0] legacy_selection;
        morphology_key_control #(.DEBOUNCE_CYCLES(DEBOUNCE_CYCLES)) u_art_key(
            .clk(clk),.rst_n(rst_n),.key_n(key_n),.enable(art_enabled),.selected_mode(legacy_selection));
        assign selected_mode={1'b0,legacy_selection};
    end endgenerate
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            mode_meta<=0;mode_sync<=0;frame_pending<=1;active_mode<=0;x<=0;y<=0;
        end else begin
            mode_meta<=frame_mode_async;mode_sync<=mode_meta;
            if(vs) begin frame_pending<=1;x<=0;y<=0;end
            else if(de) begin
                if(frame_pending) begin active_mode<=pixel_style;frame_pending<=0;end
                if(x==IMG_WIDTH-1) begin x<=0;if(y<IMG_HEIGHT-1)y<=y+1'b1;end
                else x<=x+1'b1;
            end
        end
    end

    wire [9:0] gray_sum={2'b0,scene_rgb[23:16]}+{1'b0,scene_rgb[15:8],1'b0}
                        +{2'b0,scene_rgb[7:0]}+10'd2;
    wire [7:0] gray_now=gray_sum[9:2];
    (* ram_style="bram" *) reg [9:0] line_mem [0:IMG_WIDTH-1];
    reg [9:0] row0;
    wire [7:0] top0=row0[7:0];
    reg [7:0] gray0,left_previous,top_previous;
    reg [1:0] raw_left,raw_top_left;
    wire [1:0] raw_strength;
    reg [10:0] x0;
    reg [9:0] y0;
    reg vs0,hs0,de0,vs1,hs1,de1;
    reg [23:0] rgb0,scene0,rgb1,scene1;
    reg [2:0] style0,style1;
    reg protected0,protected1,panel0,panel1,ink1;
    // Read current column, then write it on the following clock. Thus a
    // continuous row never depends on the RAM's same-address read/write mode.
    // First-row replication masks all uninitialised RAM contents after VS.
    always @(posedge clk) begin
        if(rst_n && valid_pixel) row0<=line_mem[x];
        if(rst_n && de0) line_mem[x0]<={raw_strength,gray0};
    end
    wire protected_now=PRESERVE_OSD && ((x<160 && y<160) ||
        (x>=375 && x<575 && y>=120 && y<144));
    wire panel_now=SHOW_STATUS && pixel_style!=0 && x>=16 && x<(pixel_style>=3 ? 96:64) && y>=176 && y<208;
    wire text_now=x>=24 && x<(pixel_style>=3 ? 88:56) && y>=184 && y<200;
    wire [10:0] text_x=x-11'd24;
    wire [9:0] text_y=y-10'd184;
    reg [3:0] glyph;
    always @* begin
        if(pixel_style==1)glyph={3'd0,text_x[4]};
        else if(pixel_style==2)glyph=4'd2+{3'd0,text_x[4]};
        else if(ENABLE_GAUSSIAN && pixel_style==3)glyph=4'd4+{2'd0,text_x[5:4]};
        else if(pixel_style==4)glyph=4'd8+{2'd0,text_x[5:4]};
        else glyph=0;
    end
    function [15:0] font_row;
        input [7:0] addr;
        begin
            case(addr)
                // BEGIN GENERATED ART FONT
                8'd0:font_row=16'h0000;
                8'd1:font_row=16'h0180;
                8'd2:font_row=16'h3ffc;
                8'd3:font_row=16'h0180;
                8'd4:font_row=16'h1ff8;
                8'd5:font_row=16'h0180;
                8'd6:font_row=16'h7ffe;
                8'd7:font_row=16'h0300;
                8'd8:font_row=16'h1ff0;
                8'd9:font_row=16'h0988;
                8'd10:font_row=16'h063c;
                8'd11:font_row=16'h1fc4;
                8'd12:font_row=16'h0890;
                8'd13:font_row=16'h389c;
                8'd14:font_row=16'h2384;
                8'd15:font_row=16'h0000;
                8'd16:font_row=16'h1088;
                8'd17:font_row=16'h1088;
                8'd18:font_row=16'h13fe;
                8'd19:font_row=16'h1088;
                8'd20:font_row=16'h7c88;
                8'd21:font_row=16'h1000;
                8'd22:font_row=16'h13fc;
                8'd23:font_row=16'h3b24;
                8'd24:font_row=16'h7324;
                8'd25:font_row=16'h13fc;
                8'd26:font_row=16'h1324;
                8'd27:font_row=16'h1324;
                8'd28:font_row=16'h1324;
                8'd29:font_row=16'h33fc;
                8'd30:font_row=16'h0306;
                8'd31:font_row=16'h0000;
                8'd32:font_row=16'h0000;
                8'd33:font_row=16'h2004;
                8'd34:font_row=16'h3bfc;
                8'd35:font_row=16'h0844;
                8'd36:font_row=16'h024c;
                8'd37:font_row=16'h0328;
                8'd38:font_row=16'h3008;
                8'd39:font_row=16'h13fc;
                8'd40:font_row=16'h0018;
                8'd41:font_row=16'h0020;
                8'd42:font_row=16'h17fe;
                8'd43:font_row=16'h3020;
                8'd44:font_row=16'h2020;
                8'd45:font_row=16'h6020;
                8'd46:font_row=16'h40e0;
                8'd47:font_row=16'h0080;
                8'd48:font_row=16'h0028;
                8'd49:font_row=16'h7f24;
                8'd50:font_row=16'h6920;
                8'd51:font_row=16'h7d7e;
                8'd52:font_row=16'h6968;
                8'd53:font_row=16'h69e8;
                8'd54:font_row=16'h7f7e;
                8'd55:font_row=16'h6168;
                8'd56:font_row=16'h7d68;
                8'd57:font_row=16'h757e;
                8'd58:font_row=16'h5568;
                8'd59:font_row=16'h5d68;
                8'd60:font_row=16'h417e;
                8'd61:font_row=16'h4360;
                8'd62:font_row=16'h0060;
                8'd63:font_row=16'h0000;
                8'd64:font_row=16'h0000;
                8'd65:font_row=16'h0100;
                8'd66:font_row=16'h0180;
                8'd67:font_row=16'h7ffe;
                8'd68:font_row=16'h1ff0;
                8'd69:font_row=16'h0810;
                8'd70:font_row=16'h0810;
                8'd71:font_row=16'h1ff0;
                8'd72:font_row=16'h7ffe;
                8'd73:font_row=16'h2006;
                8'd74:font_row=16'h27e6;
                8'd75:font_row=16'h2426;
                8'd76:font_row=16'h2426;
                8'd77:font_row=16'h27e6;
                8'd78:font_row=16'h200e;
                8'd79:font_row=16'h0008;
                8'd80:font_row=16'h0000;
                8'd81:font_row=16'h3302;
                8'd82:font_row=16'h337e;
                8'd83:font_row=16'h7f60;
                8'd84:font_row=16'h3360;
                8'd85:font_row=16'h3f60;
                8'd86:font_row=16'h337e;
                8'd87:font_row=16'h337e;
                8'd88:font_row=16'h3f4c;
                8'd89:font_row=16'h334c;
                8'd90:font_row=16'h7fcc;
                8'd91:font_row=16'h004c;
                8'd92:font_row=16'h32cc;
                8'd93:font_row=16'h608c;
                8'd94:font_row=16'h418c;
                8'd95:font_row=16'h0000;
                8'd96:font_row=16'h0000;
                8'd97:font_row=16'h0040;
                8'd98:font_row=16'h207c;
                8'd99:font_row=16'h1840;
                8'd100:font_row=16'h07fe;
                8'd101:font_row=16'h0444;
                8'd102:font_row=16'h6478;
                8'd103:font_row=16'h15c0;
                8'd104:font_row=16'h0444;
                8'd105:font_row=16'h1478;
                8'd106:font_row=16'h1420;
                8'd107:font_row=16'h34a4;
                8'd108:font_row=16'h2792;
                8'd109:font_row=16'h6a8a;
                8'd110:font_row=16'h4af8;
                8'd111:font_row=16'h0000;
                8'd112:font_row=16'h0000;
                8'd113:font_row=16'h0020;
                8'd114:font_row=16'h3020;
                8'd115:font_row=16'h1bfe;
                8'd116:font_row=16'h0224;
                8'd117:font_row=16'h4224;
                8'd118:font_row=16'h7220;
                8'd119:font_row=16'h13fc;
                8'd120:font_row=16'h0288;
                8'd121:font_row=16'h1a88;
                8'd122:font_row=16'h12d8;
                8'd123:font_row=16'h3450;
                8'd124:font_row=16'h6420;
                8'd125:font_row=16'h4cd8;
                8'd126:font_row=16'h0b8e;
                8'd127:font_row=16'h0200;
                8'd128:font_row=16'h1084;
                8'd129:font_row=16'h1088;
                8'd130:font_row=16'h3c48;
                8'd131:font_row=16'h7c10;
                8'd132:font_row=16'h41fc;
                8'd133:font_row=16'h3d84;
                8'd134:font_row=16'h1184;
                8'd135:font_row=16'h11fc;
                8'd136:font_row=16'h7c50;
                8'd137:font_row=16'h1050;
                8'd138:font_row=16'h1090;
                8'd139:font_row=16'h1490;
                8'd140:font_row=16'h1992;
                8'd141:font_row=16'h331e;
                8'd142:font_row=16'h0200;
                8'd143:font_row=16'h0000;
                8'd144:font_row=16'h0000;
                8'd145:font_row=16'h08c0;
                8'd146:font_row=16'h0cc0;
                8'd147:font_row=16'h08c4;
                8'd148:font_row=16'h18c4;
                8'd149:font_row=16'h18cc;
                8'd150:font_row=16'h38d8;
                8'd151:font_row=16'h78e0;
                8'd152:font_row=16'h18c0;
                8'd153:font_row=16'h19c0;
                8'd154:font_row=16'h1fc0;
                8'd155:font_row=16'h18c0;
                8'd156:font_row=16'h18c2;
                8'd157:font_row=16'h18c2;
                8'd158:font_row=16'h187e;
                8'd159:font_row=16'h0000;
                8'd160:font_row=16'h018c;
                8'd161:font_row=16'h1088;
                8'd162:font_row=16'h13fe;
                8'd163:font_row=16'h1222;
                8'd164:font_row=16'h12aa;
                8'd165:font_row=16'h7eaa;
                8'd166:font_row=16'h1222;
                8'd167:font_row=16'h13fe;
                8'd168:font_row=16'h1000;
                8'd169:font_row=16'h11fc;
                8'd170:font_row=16'h1d04;
                8'd171:font_row=16'h71fc;
                8'd172:font_row=16'h0104;
                8'd173:font_row=16'h01fc;
                8'd174:font_row=16'h0104;
                8'd175:font_row=16'h0000;
                8'd176:font_row=16'h0000;
                8'd177:font_row=16'h01fc;
                8'd178:font_row=16'h7d04;
                8'd179:font_row=16'h0d04;
                8'd180:font_row=16'h0dfc;
                8'd181:font_row=16'h7c20;
                8'd182:font_row=16'h6020;
                8'd183:font_row=16'h61fc;
                8'd184:font_row=16'h7924;
                8'd185:font_row=16'h0924;
                8'd186:font_row=16'h09fc;
                8'd187:font_row=16'h0920;
                8'd188:font_row=16'h0824;
                8'd189:font_row=16'h083e;
                8'd190:font_row=16'h3bc2;
                8'd191:font_row=16'h0000;
                // END GENERATED ART FONT
                default:font_row=16'h0000;
            endcase
        end
    endfunction
    // BEGIN final_work ERAM FONT
    // One synchronous fetch replaces the combinational glyph table.
    // Column/text qualifiers take the same first stage; ink1 remains stage two.
    (* ram_style="bram" *) reg [15:0] text_rom[0:255];
    reg [15:0] text_row0;reg [3:0] text_col0;reg text_hit0;
    initial begin
        text_rom[0]=16'h0000;
        text_rom[1]=16'h0180;
        text_rom[2]=16'h3ffc;
        text_rom[3]=16'h0180;
        text_rom[4]=16'h1ff8;
        text_rom[5]=16'h0180;
        text_rom[6]=16'h7ffe;
        text_rom[7]=16'h0300;
        text_rom[8]=16'h1ff0;
        text_rom[9]=16'h0988;
        text_rom[10]=16'h063c;
        text_rom[11]=16'h1fc4;
        text_rom[12]=16'h0890;
        text_rom[13]=16'h389c;
        text_rom[14]=16'h2384;
        text_rom[15]=16'h0000;
        text_rom[16]=16'h1088;
        text_rom[17]=16'h1088;
        text_rom[18]=16'h13fe;
        text_rom[19]=16'h1088;
        text_rom[20]=16'h7c88;
        text_rom[21]=16'h1000;
        text_rom[22]=16'h13fc;
        text_rom[23]=16'h3b24;
        text_rom[24]=16'h7324;
        text_rom[25]=16'h13fc;
        text_rom[26]=16'h1324;
        text_rom[27]=16'h1324;
        text_rom[28]=16'h1324;
        text_rom[29]=16'h33fc;
        text_rom[30]=16'h0306;
        text_rom[31]=16'h0000;
        text_rom[32]=16'h0000;
        text_rom[33]=16'h2004;
        text_rom[34]=16'h3bfc;
        text_rom[35]=16'h0844;
        text_rom[36]=16'h024c;
        text_rom[37]=16'h0328;
        text_rom[38]=16'h3008;
        text_rom[39]=16'h13fc;
        text_rom[40]=16'h0018;
        text_rom[41]=16'h0020;
        text_rom[42]=16'h17fe;
        text_rom[43]=16'h3020;
        text_rom[44]=16'h2020;
        text_rom[45]=16'h6020;
        text_rom[46]=16'h40e0;
        text_rom[47]=16'h0080;
        text_rom[48]=16'h0028;
        text_rom[49]=16'h7f24;
        text_rom[50]=16'h6920;
        text_rom[51]=16'h7d7e;
        text_rom[52]=16'h6968;
        text_rom[53]=16'h69e8;
        text_rom[54]=16'h7f7e;
        text_rom[55]=16'h6168;
        text_rom[56]=16'h7d68;
        text_rom[57]=16'h757e;
        text_rom[58]=16'h5568;
        text_rom[59]=16'h5d68;
        text_rom[60]=16'h417e;
        text_rom[61]=16'h4360;
        text_rom[62]=16'h0060;
        text_rom[63]=16'h0000;
        text_rom[64]=16'h0000;
        text_rom[65]=16'h0100;
        text_rom[66]=16'h0180;
        text_rom[67]=16'h7ffe;
        text_rom[68]=16'h1ff0;
        text_rom[69]=16'h0810;
        text_rom[70]=16'h0810;
        text_rom[71]=16'h1ff0;
        text_rom[72]=16'h7ffe;
        text_rom[73]=16'h2006;
        text_rom[74]=16'h27e6;
        text_rom[75]=16'h2426;
        text_rom[76]=16'h2426;
        text_rom[77]=16'h27e6;
        text_rom[78]=16'h200e;
        text_rom[79]=16'h0008;
        text_rom[80]=16'h0000;
        text_rom[81]=16'h3302;
        text_rom[82]=16'h337e;
        text_rom[83]=16'h7f60;
        text_rom[84]=16'h3360;
        text_rom[85]=16'h3f60;
        text_rom[86]=16'h337e;
        text_rom[87]=16'h337e;
        text_rom[88]=16'h3f4c;
        text_rom[89]=16'h334c;
        text_rom[90]=16'h7fcc;
        text_rom[91]=16'h004c;
        text_rom[92]=16'h32cc;
        text_rom[93]=16'h608c;
        text_rom[94]=16'h418c;
        text_rom[95]=16'h0000;
        text_rom[96]=16'h0000;
        text_rom[97]=16'h0040;
        text_rom[98]=16'h207c;
        text_rom[99]=16'h1840;
        text_rom[100]=16'h07fe;
        text_rom[101]=16'h0444;
        text_rom[102]=16'h6478;
        text_rom[103]=16'h15c0;
        text_rom[104]=16'h0444;
        text_rom[105]=16'h1478;
        text_rom[106]=16'h1420;
        text_rom[107]=16'h34a4;
        text_rom[108]=16'h2792;
        text_rom[109]=16'h6a8a;
        text_rom[110]=16'h4af8;
        text_rom[111]=16'h0000;
        text_rom[112]=16'h0000;
        text_rom[113]=16'h0020;
        text_rom[114]=16'h3020;
        text_rom[115]=16'h1bfe;
        text_rom[116]=16'h0224;
        text_rom[117]=16'h4224;
        text_rom[118]=16'h7220;
        text_rom[119]=16'h13fc;
        text_rom[120]=16'h0288;
        text_rom[121]=16'h1a88;
        text_rom[122]=16'h12d8;
        text_rom[123]=16'h3450;
        text_rom[124]=16'h6420;
        text_rom[125]=16'h4cd8;
        text_rom[126]=16'h0b8e;
        text_rom[127]=16'h0200;
        text_rom[128]=16'h1084;
        text_rom[129]=16'h1088;
        text_rom[130]=16'h3c48;
        text_rom[131]=16'h7c10;
        text_rom[132]=16'h41fc;
        text_rom[133]=16'h3d84;
        text_rom[134]=16'h1184;
        text_rom[135]=16'h11fc;
        text_rom[136]=16'h7c50;
        text_rom[137]=16'h1050;
        text_rom[138]=16'h1090;
        text_rom[139]=16'h1490;
        text_rom[140]=16'h1992;
        text_rom[141]=16'h331e;
        text_rom[142]=16'h0200;
        text_rom[143]=16'h0000;
        text_rom[144]=16'h0000;
        text_rom[145]=16'h08c0;
        text_rom[146]=16'h0cc0;
        text_rom[147]=16'h08c4;
        text_rom[148]=16'h18c4;
        text_rom[149]=16'h18cc;
        text_rom[150]=16'h38d8;
        text_rom[151]=16'h78e0;
        text_rom[152]=16'h18c0;
        text_rom[153]=16'h19c0;
        text_rom[154]=16'h1fc0;
        text_rom[155]=16'h18c0;
        text_rom[156]=16'h18c2;
        text_rom[157]=16'h18c2;
        text_rom[158]=16'h187e;
        text_rom[159]=16'h0000;
        text_rom[160]=16'h018c;
        text_rom[161]=16'h1088;
        text_rom[162]=16'h13fe;
        text_rom[163]=16'h1222;
        text_rom[164]=16'h12aa;
        text_rom[165]=16'h7eaa;
        text_rom[166]=16'h1222;
        text_rom[167]=16'h13fe;
        text_rom[168]=16'h1000;
        text_rom[169]=16'h11fc;
        text_rom[170]=16'h1d04;
        text_rom[171]=16'h71fc;
        text_rom[172]=16'h0104;
        text_rom[173]=16'h01fc;
        text_rom[174]=16'h0104;
        text_rom[175]=16'h0000;
        text_rom[176]=16'h0000;
        text_rom[177]=16'h01fc;
        text_rom[178]=16'h7d04;
        text_rom[179]=16'h0d04;
        text_rom[180]=16'h0dfc;
        text_rom[181]=16'h7c20;
        text_rom[182]=16'h6020;
        text_rom[183]=16'h61fc;
        text_rom[184]=16'h7924;
        text_rom[185]=16'h0924;
        text_rom[186]=16'h09fc;
        text_rom[187]=16'h0920;
        text_rom[188]=16'h0824;
        text_rom[189]=16'h083e;
        text_rom[190]=16'h3bc2;
        text_rom[191]=16'h0000;
        text_rom[192]=16'h0000;
        text_rom[193]=16'h0000;
        text_rom[194]=16'h0000;
        text_rom[195]=16'h0000;
        text_rom[196]=16'h0000;
        text_rom[197]=16'h0000;
        text_rom[198]=16'h0000;
        text_rom[199]=16'h0000;
        text_rom[200]=16'h0000;
        text_rom[201]=16'h0000;
        text_rom[202]=16'h0000;
        text_rom[203]=16'h0000;
        text_rom[204]=16'h0000;
        text_rom[205]=16'h0000;
        text_rom[206]=16'h0000;
        text_rom[207]=16'h0000;
        text_rom[208]=16'h0000;
        text_rom[209]=16'h0000;
        text_rom[210]=16'h0000;
        text_rom[211]=16'h0000;
        text_rom[212]=16'h0000;
        text_rom[213]=16'h0000;
        text_rom[214]=16'h0000;
        text_rom[215]=16'h0000;
        text_rom[216]=16'h0000;
        text_rom[217]=16'h0000;
        text_rom[218]=16'h0000;
        text_rom[219]=16'h0000;
        text_rom[220]=16'h0000;
        text_rom[221]=16'h0000;
        text_rom[222]=16'h0000;
        text_rom[223]=16'h0000;
        text_rom[224]=16'h0000;
        text_rom[225]=16'h0000;
        text_rom[226]=16'h0000;
        text_rom[227]=16'h0000;
        text_rom[228]=16'h0000;
        text_rom[229]=16'h0000;
        text_rom[230]=16'h0000;
        text_rom[231]=16'h0000;
        text_rom[232]=16'h0000;
        text_rom[233]=16'h0000;
        text_rom[234]=16'h0000;
        text_rom[235]=16'h0000;
        text_rom[236]=16'h0000;
        text_rom[237]=16'h0000;
        text_rom[238]=16'h0000;
        text_rom[239]=16'h0000;
        text_rom[240]=16'h0000;
        text_rom[241]=16'h0000;
        text_rom[242]=16'h0000;
        text_rom[243]=16'h0000;
        text_rom[244]=16'h0000;
        text_rom[245]=16'h0000;
        text_rom[246]=16'h0000;
        text_rom[247]=16'h0000;
        text_rom[248]=16'h0000;
        text_rom[249]=16'h0000;
        text_rom[250]=16'h0000;
        text_rom[251]=16'h0000;
        text_rom[252]=16'h0000;
        text_rom[253]=16'h0000;
        text_rom[254]=16'h0000;
        text_rom[255]=16'h0000;
    end
    always @(posedge clk)text_row0<=text_rom[{glyph,text_y[3:0]}];
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin text_col0<=0;text_hit0<=0;end
        else begin text_col0<=text_x[3:0];text_hit0<=text_now;end
    end
    wire text_ink_stage1=text_hit0 && text_row0[15-text_col0];
    // END final_work ERAM FONT

    wire [7:0] left0=(x0==0) ? gray0:left_previous;
    wire [7:0] above0=(y0==0) ? gray0:top0;
    wire [7:0] above_left0=(y0==0) ? left0:((x0==0) ? top0:top_previous);
    wire [7:0] diagonal_a=(gray0>=above_left0) ? gray0-above_left0:above_left0-gray0;
    wire [7:0] diagonal_b=(left0>=above0) ? left0-above0:above0-left0;
    wire [8:0] magnitude={1'b0,diagonal_a}+{1'b0,diagonal_b};
    // Preserve faint contours, darken medium ones, and thicken each raw edge
    // by one pixel right/down. Store RAW strength, never the expanded result,
    // so a stroke cannot recursively grow across a row or into the next frame.
    assign raw_strength=(magnitude>=9'd32) ? 2'd3:
                            ((magnitude>=9'd16) ? 2'd2:((magnitude>9'd6) ? 2'd1:2'd0));
    wire [1:0] strength_left=(x0==0) ? 2'd0:raw_left;
    wire [1:0] strength_top=(y0==0) ? 2'd0:row0[9:8];
    wire [1:0] strength_corner=(x0==0 || y0==0) ? 2'd0:raw_top_left;
    wire [1:0] max_bottom=(raw_strength>=strength_left) ? raw_strength:strength_left;
    wire [1:0] max_top=(strength_top>=strength_corner) ? strength_top:strength_corner;
    reg [1:0] stroke1;
    reg signed [10:0] relief1;
    wire signed [10:0] center_signed=$signed({3'b000,gray0});
    wire signed [10:0] corner_signed=$signed({3'b000,above_left0});
    wire [7:0] sketch_value=(stroke1==0) ? 8'd255:
                            ((stroke1==1) ? 8'd160:((stroke1==2) ? 8'd48:8'd0));
    wire [7:0] emboss_value=(relief1<0) ? 8'd0:((relief1>11'sd255) ? 8'd255:relief1[7:0]);
    wire [7:0] style_value=(style1==1) ? sketch_value:emboss_value;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            gray0<=0;x0<=0;y0<=0;left_previous<=0;top_previous<=0;
            vs0<=0;hs0<=0;de0<=0;vs1<=0;hs1<=0;de1<=0;
            rgb0<=0;scene0<=0;rgb1<=0;scene1<=0;style0<=0;style1<=0;
            protected0<=0;protected1<=0;panel0<=0;panel1<=0;ink1<=0;
            raw_left<=0;raw_top_left<=0;stroke1<=0;relief1<=0;
            out_vs<=0;out_hs<=0;out_de<=0;out_scene<=0;out_rgb<=0;
        end else begin
            vs0<=vs;hs0<=hs;de0<=valid_pixel;
            rgb0<=rgb;scene0<=scene_rgb;gray0<=gray_now;x0<=x;y0<=y;style0<=pixel_style;
            protected0<=protected_now;panel0<=panel_now;
            vs1<=vs0;hs1<=hs0;de1<=de0;
            rgb1<=rgb0;scene1<=scene0;style1<=style0;
            protected1<=protected0;panel1<=panel0;ink1<=text_ink_stage1;
            if(de0) begin
                left_previous<=gray0;top_previous<=top0;
                raw_left<=raw_strength;raw_top_left<=row0[9:8];
            end
            stroke1<=(max_bottom>=max_top) ? max_bottom:max_top;
            relief1<=11'sd128+((center_signed-corner_signed)<<<1);
            out_vs<=vs1;out_hs<=hs1;out_de<=de1;out_scene<=scene1;
            if(de1 && style1!=0) begin
                if(panel1) out_rgb<=ink1 ? 24'hffffff:24'h182030;
                else if(protected1) out_rgb<=rgb1;
                else if(ENABLE_FILTERS && ENABLE_GAUSSIAN && style1==3)out_rgb<=filter_gaussian_rgb;
                else if(ENABLE_FILTERS && style1==4)out_rgb<=filter_sharpen_rgb;
                else out_rgb<={style_value,style_value,style_value};
            end else out_rgb<=rgb1;
        end
    end
endmodule
