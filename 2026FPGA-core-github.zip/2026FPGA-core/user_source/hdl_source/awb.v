/*****************************************************************
Company : MiLianKe Electronic Technology Co., Ltd.
WebSite:https://www.milianke.com
TechWeb:https://www.uisrc.com
tmall-shop:https://milianke.tmall.com
jd-shop:https://milianke.jd.com
taobao-shop: https://milianke.taobao.com
Description: 
The reference demo provided by Milianke is only used for learning. 
We cannot ensure that the demo itself is free of bugs, so users 
should be responsible for the technical problems and consequences
caused by the use of their own products.
@Author      :   XiaoQingquan 
@Time        :   2024/10 
version:     :   
@Description :   在原基础上删去了一些赘余的代码，并且优化了时序，加入BRAM IP核，
                 让从除法器出来的每一个数据都可以对上相应的像素数据进行增益，使
                 得它的适用行更加广泛了。
*****************************************************************/
module awb  #(   
    parameter IMG_HEIGHT = 1080,
    parameter IMG_WIDTH  = 1920,
    // Compile-time A/B only. The released design uses 0; the comparison
    // preparation script changes only this default to 1 in a source copy.
    parameter RESOURCE_BASELINE = 0
) 
(
    input                   I_clk  ,
    input                   I_rst_n,


    input                   I_tlast  ,
    input                   I_tuser  ,
    input [95:0]            I_tdata  ,
    input                   I_tvalid , 
    output                  I_tready ,

    output                  O_tlast  ,
    output                  O_tuser  ,
    output [95:0]           O_tdata  ,
    output                  O_tvalid ,
    input                   O_tready
);

/*****************************************************************
                          RGB565תRGB888                                        
*****************************************************************/

    // //RGB565??????888
    // wire [4:0]  rgb565_r   = I_st_data[11+:5];
    // wire [5:0]  rgb565_g   = I_st_data[5+:6];
    // wire [4:0]  rgb565_b   = I_st_data[0+:5];
    
    // wire [23:0] rgb888     = {{rgb565_r[4:0],rgb565_r[2:0]},{rgb565_g[5:0],rgb565_g[1:0]},{rgb565_b[4:0],rgb565_b[2:0]}};
    
    // wire [7:0]  rgb888_r   = rgb888[16+:8];
    // wire [7:0]  rgb888_g   = rgb888[8+:8] ;
    // wire [7:0]  rgb888_b   = rgb888[0+:8] ;
    
  /*****************************************************************
                          中间信号                                        
*****************************************************************/


  reg         I_tvalid_r0,I_tvalid_r1;
  reg  [95:0] I_tdata_d0,I_tdata_d1;


  //累加RGB通道的�??
  reg  [31:0]         sum_r[0:3];
  reg  [31:0]         sum_g[0:3];
  reg  [31:0]         sum_b[0:3];

  
  wire  [95:0]        data_d0 ;
  wire                valid_d0;
  wire                I_tuser_r0;    

  reg                 I_tuser_r1;

  reg   [95:0]        data_d1 ;
  reg                 valid_d1;
  reg   [9:0]         rgb_sum[0:3];//每个像素点RGB的和
  /*****************************************************************
                            平均值计�??                                      
*****************************************************************/

// 对输入数据和有效信号进行寄存，形成流水线
always @(posedge I_clk or negedge I_rst_n) begin
    if (!I_rst_n) begin
        I_tdata_d0  <= 0;
        I_tdata_d1  <= 0;
        {I_tvalid_r0,I_tvalid_r1} <= 0;
    end else begin
        I_tdata_d0  <= I_tdata   ;
        I_tdata_d1  <= I_tdata_d0;
        I_tvalid_r0 <= I_tvalid;
        I_tvalid_r1 <= I_tvalid_r0;
    end
end

// 将输入数据拆分为4个像素的RGB分量
wire [7:0] rgb888_r_d[0:3];
wire [7:0] rgb888_g_d[0:3];
wire [7:0] rgb888_b_d[0:3];

assign  rgb888_r_d[0] = I_tdata[16+:8];
assign  rgb888_g_d[0] = I_tdata[8+:8];
assign  rgb888_b_d[0] = I_tdata[0+:8];


// 将输入数据拆分为4个像素的RGB分量
wire [7:0] rgb888_r_d0[0:3];
wire [7:0] rgb888_g_d0[0:3];
wire [7:0] rgb888_b_d0[0:3];

assign  rgb888_r_d0[0] = I_tdata_d0[16+:8];
assign  rgb888_g_d0[0] = I_tdata_d0[8+:8];
assign  rgb888_b_d0[0] = I_tdata_d0[0+:8];


        ///削弱白色
        always @(posedge I_clk or negedge I_rst_n) begin
            if(!I_rst_n) begin
                rgb_sum[0] <= 0;
            end
            else if(I_tvalid)begin
                rgb_sum[0] <= rgb888_r_d[0] + rgb888_g_d[0] + rgb888_b_d[0];
            end
        end

        // 对每个通道的值进行累加，用于计算平均值
        always @(posedge I_clk or negedge I_rst_n) begin
            if (!I_rst_n || I_tuser) begin
                // 复位或行开始信号有效时，清零累加器
                sum_r[0] <= 1;
                sum_g[0] <= 1;
                sum_b[0] <= 1;
            end else if (I_tvalid_r0 && (rgb_sum[0] < 720)) begin
                // 当输入有效时，累加RGB分量的值
                sum_r[0] <= sum_r[0] + rgb888_r_d0[0];
                sum_g[0] <= sum_g[0] + rgb888_g_d0[0];
                sum_b[0] <= sum_b[0] + rgb888_b_d0[0];
            end
        end

  /*****************************************************************
                           计算增益                                       
*****************************************************************/

  wire [47:0] dout_R[3:0];
  wire [47:0] dout_B[3:0];

  wire done[3:0];

  reg [31:0] frame_r, frame_g, frame_b;
  reg [19:0] sample_count;
  reg div_start;
  always @(posedge I_clk or negedge I_rst_n) begin
      if(!I_rst_n) begin frame_r<=1; frame_g<=1; frame_b<=1; sample_count<=0; div_start<=0; end
      else begin
          div_start<=0;
          if(I_tuser) begin
              if(sample_count>=1024) begin
                  frame_r<=sum_r[0]; frame_g<=sum_g[0]; frame_b<=sum_b[0]; div_start<=1;
              end
              sample_count<=0;
          end else if(I_tvalid_r0 && rgb_sum[0]<720) sample_count<=sample_count+1'b1;
      end
  end
  wire [47:0] in_r_x1;
  wire [47:0] in_b_x1;
  assign in_r_x1 = dout_R[0][47:0];
  assign in_b_x1 = dout_B[0][47:0];



/*****************************************************************
                   IP 调用                                    
*****************************************************************/
    //为了保证合理的延迟，这里使用了除法器

    // V13: frame statistics need two divisions per frame, not per pixel.
    // Two small iterative datapaths replace two fully pipelined IPs.
    // Exact results and the original 50-stage done timing are preserved.
    generate if (RESOURCE_BASELINE) begin : g_resource_baseline
      awb_gain_divider_pair_baseline gain_divider (
        .clk(I_clk), .rst(!I_rst_n), .start(div_start),
        .numerator({frame_g,16'd0}),
        .denominator_r(frame_r), .denominator_b(frame_b),
        .quotient_r(dout_R[0]), .quotient_b(dout_B[0]), .done(done[0])
      );
    end else begin : g_resource_optimized
      awb_gain_divider_pair gain_divider (
        .clk(I_clk), .rst(!I_rst_n), .start(div_start),
        .numerator({frame_g,16'd0}),
        .denominator_r(frame_r), .denominator_b(frame_b),
        .quotient_r(dout_R[0]), .quotient_b(dout_B[0]), .done(done[0])
      );
    end endgenerate

    signal_delay #(
        .IMG_HEIGHT   (IMG_HEIGHT),
        .IMG_WIDTH    (IMG_WIDTH ),
        .DATA_WIDTH   (96  ),
        .DELAY_CYCLE  (50),
        .RAM_ADDR_WIDTH (RESOURCE_BASELINE ? 11 : 0)
    )signal_delay_d (
        /*input                       */ .I_clk  (I_clk  ),
        /*input                       */ .I_rst_n(I_rst_n),
        /*input                       */ .I_tuser(I_tuser),  //synthesis keep 
        /*input  wire                 */ .I_valid(I_tvalid_r1),  //synthesis keep 
        /*input  wire [DATA_WIDTH-1:0]*/ .I_data (I_tdata_d1 ),   //synthesis keep 
        /*output wire                 */ .O_valid(valid_d0   ),  //synthesis keep 
        /*output wire [DATA_WIDTH-1:0]*/ .O_data (data_d0    ),   //synthesis keep 
        /*output wire                 */ .O_tuser(I_tuser_r0 )
    );

    

/*****************************************************************
                            ��������                                      
*****************************************************************/

    reg  [19:0]   in_r_r1;
    reg  [19:0]   in_b_r1;
    reg [19:0] pending_r, pending_b;
    reg gain_ready;
    function [19:0] bounded_gain;
        input [47:0] q;
        begin
            if(q<48'h000000010000) bounded_gain=20'h10000;
            else if(q>48'h000000020000) bounded_gain=20'h20000;
            else bounded_gain=q[19:0];
        end
    endfunction
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            in_r_r1<=20'h10000; in_b_r1<=20'h10000;
            pending_r<=20'h10000; pending_b<=20'h10000; gain_ready<=0;
        end else begin
            if(done[0]) begin
                pending_r<=bounded_gain(in_r_x1); pending_b<=bounded_gain(in_b_x1); gain_ready<=1;
            end
            if(I_tuser && gain_ready) begin
                in_r_r1<=in_r_r1-(in_r_r1>>3)+(pending_r>>3);
                in_b_r1<=in_b_r1-(in_b_r1>>3)+(pending_b>>3);
            end
        end
    end

    ////信号同步
    always @(posedge I_clk or negedge I_rst_n) begin
      if (!I_rst_n) begin
          valid_d1 <= 0;
          data_d1  <= 0;
          I_tuser_r1 <= 0;
      end else begin
          valid_d1 <= valid_d0;
          data_d1  <= data_d0 ;
          I_tuser_r1 <= I_tuser_r0;
      end
    end
/*****************************************************************
                           ��������                                       
*****************************************************************/

    reg [27:0] R_new_r1;
    reg [27:0] G_new_r1;
    reg [27:0] B_new_r1;

    reg [27:0] R_new_r2;
    reg [27:0] G_new_r2;
    reg [27:0] B_new_r2;

    reg [27:0] R_new_r3;
    reg [27:0] G_new_r3;
    reg [27:0] B_new_r3;

    reg [27:0] R_new_r4;
    reg [27:0] G_new_r4;
    reg [27:0] B_new_r4;


    wire   [7:0] rgb888_r_d1[0:3];
    wire   [7:0] rgb888_g_d1[0:3];
    wire   [7:0] rgb888_b_d1[0:3];

    assign  rgb888_r_d1[0] = data_d1[16+:8];
    assign  rgb888_g_d1[0] = data_d1[8+:8];
    assign  rgb888_b_d1[0] = data_d1[0+:8];

    assign  rgb888_r_d1[1] = data_d1[40+:8];
    assign  rgb888_g_d1[1] = data_d1[32+:8];
    assign  rgb888_b_d1[1] = data_d1[24+:8];

    assign  rgb888_r_d1[2] = data_d1[64+:8];
    assign  rgb888_g_d1[2] = data_d1[56+:8];
    assign  rgb888_b_d1[2] = data_d1[48+:8];

    assign  rgb888_r_d1[3] = data_d1[88+:8];
    assign  rgb888_g_d1[3] = data_d1[80+:8];
    assign  rgb888_b_d1[3] = data_d1[72+:8];
    always @(posedge I_clk or negedge I_rst_n)begin 
        if(!I_rst_n)begin
            R_new_r1 <= 0;
            G_new_r1 <= 0;
            B_new_r1 <= 0;

            R_new_r2 <= 0;
            G_new_r2 <= 0;
            B_new_r2 <= 0;

            R_new_r3 <= 0;
            G_new_r3 <= 0;
            B_new_r3 <= 0;

            R_new_r4 <= 0;
            G_new_r4 <= 0;
            B_new_r4 <= 0;
        end
        else if(valid_d1) begin
            R_new_r1 <= in_r_r1 * rgb888_r_d1[0];
            G_new_r1 <=           rgb888_g_d1[0];
            B_new_r1 <= in_b_r1 * rgb888_b_d1[0];

            R_new_r2 <= in_r_r1 * rgb888_r_d1[1];
            G_new_r2 <=           rgb888_g_d1[1];
            B_new_r2 <= in_b_r1 * rgb888_b_d1[1];

            R_new_r3 <= in_r_r1 * rgb888_r_d1[2];
            G_new_r3 <=           rgb888_g_d1[2];
            B_new_r3 <= in_b_r1 * rgb888_b_d1[2];

            R_new_r4 <= in_r_r1 * rgb888_r_d1[3];
            G_new_r4 <=           rgb888_g_d1[3];
            B_new_r4 <= in_b_r1 * rgb888_b_d1[3];
        end
    end

/*****************************************************************
                            �������???                                      
*****************************************************************/

    wire [7:0] R_new_x1;
    wire [7:0] G_new_x1;
    wire [7:0] B_new_x1;

    wire [7:0] R_new_x2;
    wire [7:0] G_new_x2;
    wire [7:0] B_new_x2;

    wire [7:0] R_new_x3;
    wire [7:0] G_new_x3;
    wire [7:0] B_new_x3;

    wire [7:0] R_new_x4;
    wire [7:0] G_new_x4;
    wire [7:0] B_new_x4;

    assign R_new_x1 = (R_new_r1[27:24])?255:R_new_r1[23:16];
    assign G_new_x1 =  G_new_r1;
    assign B_new_x1 = (B_new_r1[27:24])?255:B_new_r1[23:16];

    assign R_new_x2 = (R_new_r2[27:24])?255:R_new_r2[23:16];
    assign G_new_x2 =  G_new_r2;
    assign B_new_x2 = (B_new_r2[27:24])?255:B_new_r2[23:16];

    assign R_new_x3 = (R_new_r3[27:24])?255:R_new_r3[23:16];
    assign G_new_x3 =  G_new_r3;
    assign B_new_x3 = (B_new_r3[27:24])?255:B_new_r3[23:16];

    assign R_new_x4 = (R_new_r4[27:24])?255:R_new_r4[23:16];
    assign G_new_x4 =  G_new_r4;
    assign B_new_x4 = (B_new_r4[27:24])?255:B_new_r4[23:16];
/*****************************************************************
                           ͬ���ź�                                       
*****************************************************************/

    reg valid_d2,I_tuser_r2;
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n)begin
            valid_d2 <= 0;
            I_tuser_r2 <= 0;
        end
        else begin
            valid_d2 <= valid_d1;
            I_tuser_r2 <= I_tuser_r1;
        end
    end


    assign  O_tlast  = (valid_d1 == 0) && (valid_d2 == 1);   
    assign  O_tuser  = I_tuser ;   
    assign  O_tvalid = valid_d2;

    assign  O_tdata = O_tvalid?{R_new_x4,G_new_x4,B_new_x4,
                       R_new_x3,G_new_x3,B_new_x3,
                       R_new_x2,G_new_x2,B_new_x2,
                       R_new_x1,G_new_x1,B_new_x1}:0;
    // assign O_t_data = {R_new[7-:5],G_new[7-:6],B_new[7-:5]};
    assign  I_tready = O_tready;
 
endmodule




// Two exact floor(numerator/denominator) results with the original IP timing:
// start accepted at edge N, done and both quotients available after edge N+49.
// Frame statistics are latched on start. start occurs at least 1024 sampled
// clocks apart in awb; a request while busy is intentionally not accepted.
// A zero denominator returns all ones, matching the original unsigned IP.
// Registers hold while idle to avoid unnecessary divider switching.
module awb_gain_divider_pair(
    input wire clk, rst, start,
    input wire [47:0] numerator,
    input wire [31:0] denominator_r, denominator_b,
    output reg [47:0] quotient_r, quotient_b,
    output reg done
);
reg busy;
reg [5:0] step;
reg [47:0] work_r, work_b;
reg [31:0] den_r, den_b, rem_r, rem_b;
wire [32:0] trial_r = {rem_r, work_r[47]};
wire [32:0] trial_b = {rem_b, work_b[47]};
wire [32:0] diff_r = trial_r - {1'b0, den_r};
wire [32:0] diff_b = trial_b - {1'b0, den_b};
// For a nonzero divisor, remainder<divisor makes bit 32 a valid borrow bit.
wire subtract_r = (den_r==0) || !diff_r[32];
wire subtract_b = (den_b==0) || !diff_b[32];
always @(posedge clk or posedge rst) begin
    if(rst) begin
        busy<=0; step<=0; done<=0;
        work_r<=0; work_b<=0; den_r<=0; den_b<=0;
        rem_r<=0; rem_b<=0; quotient_r<=0; quotient_b<=0;
    end else begin
        done<=0;
        if(!busy) begin
            if(start) begin
                busy<=1; step<=0;
                work_r<=numerator; work_b<=numerator;
                den_r<=denominator_r; den_b<=denominator_b;
                rem_r<=0; rem_b<=0;
            end
        end else begin
            if(step==48) begin
                quotient_r<=work_r; quotient_b<=work_b;
                busy<=0; done<=1;
            end else begin
                work_r<={work_r[46:0],subtract_r};
                work_b<={work_b[46:0],subtract_b};
                rem_r<=subtract_r ? diff_r[31:0] : trial_r[31:0];
                rem_b<=subtract_b ? diff_b[31:0] : trial_b[31:0];
                step<=step+1'b1;
            end
        end
    end
end
endmodule

// Same externally visible contract as awb_gain_divider_pair, implemented by
// the original two 50-stage pipelined divider IPs. The adapter deliberately
// retains the current reset-abort fix and ignores starts while busy. It is
// compiled only into the separately built comparison baseline, never into
// the optimized bitstream. Thus no runtime switch changes allocated hardware.
module awb_gain_divider_pair_baseline(
    input wire clk, rst, start,
    input wire [47:0] numerator,
    input wire [31:0] denominator_r, denominator_b,
    output wire [47:0] quotient_r, quotient_b,
    output wire done
);
reg busy;
reg [49:0] valid_pipe;
reg [47:0] held_r, held_b;
wire accept_start = start && !busy;
wire [47:0] raw_r, raw_b;
// Ignore the IP's internal valid shift register: it does not clear every
// stage on reset. This resettable token cancels every in-flight transaction.
assign done = valid_pipe[49];
assign quotient_r = done ? raw_r : held_r;
assign quotient_b = done ? raw_b : held_b;
divider div_r(.clk(clk), .rst(rst), .start(accept_start),
    .numerator(numerator), .denominator(denominator_r),
    .quotient(raw_r), .done(), .remainder());
divider div_b(.clk(clk), .rst(rst), .start(accept_start),
    .numerator(numerator), .denominator(denominator_b),
    .quotient(raw_b), .done(), .remainder());
always @(posedge clk or posedge rst) begin
    if(rst) begin
        busy<=0; valid_pipe<=0; held_r<=0; held_b<=0;
    end else begin
        valid_pipe<={valid_pipe[48:0],accept_start};
        if(accept_start) busy<=1;
        else if(valid_pipe[48]) busy<=0;
        if(done) begin held_r<=raw_r; held_b<=raw_b; end
    end
end
endmodule
