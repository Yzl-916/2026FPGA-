// Display-only cool/warm control. KEY1/KEY2 are active-low physical buttons.
// Both held for 1 s toggle enable once, then require both released to re-arm.
// Each enable starts neutral. A single press steps immediately after debounce;
// holding the key repeats every 400 ms. There are three levels in each direction.
// V21.34: video-reference gold warmth and blue/violet cold atmosphere.
// Warm midtone light, cool deep shadows, soft highlights and restrained chroma. Tone, chroma and split colour balance share frame-stable
// three-level strength. This is a creative atmosphere, not Kelvin calibration.
// Each channel can move at most halfway toward its destination endpoint.
// Whole-pixel black/white stay exact; dark coloured channels can take ambient
// light. Interior channels cannot newly clip, and saturated objects retain detail.
// Four pixel stages for both neutral/bypass and adjusted output.
module color_temperature_display #(
    parameter integer DEBOUNCE_CYCLES = 750000,
    parameter integer HOLD_CYCLES = 75000000,
    parameter integer STEP_CYCLES = 30000000
)(
    input wire clk, rst_n,
    input wire [1:0] keys_n,
    input wire vs, hs, de,
    input wire [23:0] rgb,
    output reg out_vs, out_hs, out_de,
    output reg [23:0] out_rgb,
    output reg enabled,
    output reg signed [5:0] level,
    output reg active_enabled,
    output reg signed [5:0] active_level,
    output wire [1:0] debounced_keys,synchronized_keys
);
    localparam integer DW = DEBOUNCE_CYCLES<=1 ? 1 : $clog2(DEBOUNCE_CYCLES);
    localparam integer HW = HOLD_CYCLES<=1 ? 1 : $clog2(HOLD_CYCLES);
    localparam integer SW = STEP_CYCLES<=1 ? 1 : $clog2(STEP_CYCLES);
    reg [1:0] key_meta, key_sync, key_stable;
    assign debounced_keys=key_stable;
    assign synchronized_keys=key_sync;
    reg [DW-1:0] debounce0, debounce1;
    reg [HW-1:0] hold_count;
    reg [SW-1:0] step_count;
    reg chord_locked;
    reg [1:0] single_direction;
    reg frame_pending;
    wire frame_first = frame_pending && de && !vs;
    wire pixel_enabled = frame_first ? enabled : active_enabled;
    wire signed [5:0] pixel_level = frame_first ? level : active_level;
    wire [5:0] absolute_level = pixel_level[5] ? -pixel_level : pixel_level;
    wire [3:0] strength = !pixel_enabled ? 4'd0 :
        absolute_level==6'd1 ? 4'd3 :
        absolute_level==6'd2 ? 4'd5 :
        absolute_level==6'd3 ? 4'd8 : 4'd0;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            key_meta<=2'b11; key_sync<=2'b11; key_stable<=2'b11;
            debounce0<=0; debounce1<=0;
        end else begin
            key_meta<=keys_n; key_sync<=key_meta;
            if(key_sync[0]==key_stable[0]) debounce0<=0;
            else if(debounce0==DEBOUNCE_CYCLES-1) begin
                key_stable[0]<=key_sync[0]; debounce0<=0;
            end else debounce0<=debounce0+1'b1;
            if(key_sync[1]==key_stable[1]) debounce1<=0;
            else if(debounce1==DEBOUNCE_CYCLES-1) begin
                key_stable[1]<=key_sync[1]; debounce1<=0;
            end else debounce1<=debounce1+1'b1;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            enabled<=0; level<=0; hold_count<=0; step_count<=0;
            chord_locked<=0; single_direction<=0;
        end else if(key_stable==2'b11) begin
            hold_count<=0; step_count<=0; chord_locked<=0; single_direction<=0;
        end else if(chord_locked) begin
            // Partial release must not cause a colour step or another toggle.
            hold_count<=0; step_count<=0; single_direction<=0;
        end else if(key_stable==2'b00) begin
            step_count<=0; single_direction<=0;
            if(hold_count==HOLD_CYCLES-1) begin
                enabled<=!enabled; level<=0; hold_count<=0; chord_locked<=1;
            end else hold_count<=hold_count+1'b1;
        end else begin
            hold_count<=0;
            if(!enabled) begin step_count<=0; single_direction<=0; end
            else if(single_direction!=key_stable) begin
                single_direction<=key_stable; step_count<=0;
                if(key_stable==2'b10 && level<6'sd3) level<=level+6'sd1;
                else if(key_stable==2'b01 && level> -6'sd3) level<=level-6'sd1;
            end else if(step_count==STEP_CYCLES-1) begin
                step_count<=0;
                if(key_stable==2'b10 && level<6'sd3) level<=level+6'sd1;
                else if(key_stable==2'b01 && level> -6'sd3) level<=level-6'sd1;
            end else step_count<=step_count+1'b1;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin frame_pending<=1; active_enabled<=0; active_level<=0; end
        else if(vs) frame_pending<=1;
        else if(frame_first) begin
            frame_pending<=0; active_enabled<=enabled; active_level<=level;
        end
    end

    // Symmetric rounding of numerator * strength / 128. Numerators describe
    // the full-strength offset in sixteenths; strength is 3, 5 or 8 eighths.
    function signed [7:0] round_offset;
        input signed [11:0] value;
        input [3:0] amount;
        reg signed [15:0] v, scaled;
        reg [15:0] magnitude;
        reg [7:0] rounded;
        begin
            v={{4{value[11]}},value};
            case(amount)
                4'd3: scaled=(v<<1)+v;
                4'd5: scaled=(v<<2)+v;
                4'd8: scaled=v<<3;
                default: scaled=0;
            endcase
            magnitude=scaled[15] ? -scaled : scaled;
            rounded=(magnitude+16'd64)>>7;
            round_offset=scaled[15] ? -$signed(rounded) : $signed(rounded);
        end
    endfunction
    function [7:0] protect_channel;
        input [7:0] channel;
        input signed [7:0] offset;
        reg [7:0] headroom;
        reg signed [8:0] bound, delta, result;
        begin
            headroom=offset[7] ? channel : 8'd255-channel;
            bound=$signed({2'b00,headroom[7:1]});
            delta={offset[7],offset};
            if(delta>bound) delta=bound;
            else if(delta < -bound) delta=-bound;
            result=$signed({1'b0,channel})+delta;
            protect_channel=result[7:0];
        end
    endfunction
    reg vs_1, hs_1, de_1, cool_1;
    reg vs_2, hs_2, de_2, vs_3, hs_3, de_3;
    reg [23:0] rgb_1, rgb_2, rgb_3;
    reg [7:0] luma_1;
    reg [3:0] strength_1, strength_2;
    reg signed [11:0] red_numerator_2, green_numerator_2, blue_numerator_2;
    reg signed [7:0] red_offset_3, green_offset_3, blue_offset_3;
    wire [9:0] luma_sum={2'b00,rgb[23:16]}+{1'b0,rgb[15:8],1'b0}+
        {2'b00,rgb[7:0]}+10'd2;
    wire [7:0] shadow_weight=luma_1<8'd80 ? luma_1 :
        luma_1<8'd160 ? 8'd160-luma_1 : 8'd0;
    wire [7:0] highlight_weight=luma_1<8'd64 ? 8'd0 :
        luma_1<8'd160 ? luma_1-8'd64 : 8'd255-luma_1;
    wire signed [11:0] s={4'b0000,shadow_weight};
    wire signed [11:0] h={4'b0000,highlight_weight};
    wire [7:0] midtone_weight=luma_1<8'd128 ? luma_1 : 8'd255-luma_1;
    wire signed [11:0] m={4'b0000,midtone_weight};
    wire signed [11:0] y={4'b0000,luma_1};
    wire signed [11:0] r={4'b0000,rgb_1[23:16]};
    wire signed [11:0] g={4'b0000,rgb_1[15:8]};
    wire signed [11:0] b={4'b0000,rgb_1[7:0]};
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            vs_1<=0; hs_1<=0; de_1<=0; cool_1<=0; rgb_1<=0;
            vs_2<=0; hs_2<=0; de_2<=0; rgb_2<=0;
            vs_3<=0; hs_3<=0; de_3<=0; rgb_3<=0;
            luma_1<=0; strength_1<=0; strength_2<=0;
            red_numerator_2<=0; green_numerator_2<=0; blue_numerator_2<=0;
            red_offset_3<=0; green_offset_3<=0; blue_offset_3<=0;
            out_vs<=0; out_hs<=0; out_de<=0; out_rgb<=0;
        end else begin
            // 1: frame-stable controls, source RGB and rounded luma.
            vs_1<=vs; hs_1<=hs; de_1<=de;
            rgb_1<=rgb; cool_1<=pixel_level[5];
            luma_1<=luma_sum[9:2]; strength_1<=strength;
            // 2: mood in sixteenths, tuned to the user's reference video.
            // Warm: +2M soft light, gold balance (5S+5H,S+2H,-6S-8H).
            // Cool: H-2S contrast, blue shadows (-3S,-3S,12S),
            // icy highlights (-4H,-2H,7H). Both restrain chroma by (Y-C)/16.
            // Expanded below to share arithmetic. No multipliers or line RAM.
            vs_2<=vs_1; hs_2<=hs_1; de_2<=de_1; rgb_2<=rgb_1;
            strength_2<=strength_1;
            if(cool_1) begin
                red_numerator_2<=-(s<<2)-s-(h<<1)-h+(y-r);
                green_numerator_2<=-(s<<2)-s-h+(y-g);
                blue_numerator_2<=(s<<3)+(s<<1)+(h<<3)+(y-b);
            end else begin
                red_numerator_2<=(s<<2)+s+(h<<2)+h+(m<<1)+(y-r);
                green_numerator_2<=s+(h<<1)+(m<<1)+(y-g);
                blue_numerator_2<=-(s<<2)-(s<<1)-(h<<3)+(m<<1)+(y-b);
            end
            // 3: three strength levels with symmetric signed rounding.
            vs_3<=vs_2; hs_3<=hs_2; de_3<=de_2; rgb_3<=rgb_2;
            red_offset_3<=round_offset(red_numerator_2,strength_2);
            green_offset_3<=round_offset(green_numerator_2,strength_2);
            blue_offset_3<=round_offset(blue_numerator_2,strength_2);
            // 4: bound movement toward each endpoint; avoid new channel clipping.
            out_vs<=vs_3; out_hs<=hs_3; out_de<=de_3;
            out_rgb<={protect_channel(rgb_3[23:16],red_offset_3),
                protect_channel(rgb_3[15:8],green_offset_3),
                protect_channel(rgb_3[7:0],blue_offset_3)};
        end
    end
endmodule
