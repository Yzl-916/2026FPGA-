// V21.26: SW4 controls colour/detection brightness; optional mode2 default.
// Two synchronization registers precede a consecutive-sample debounce filter.
// 750000 samples at the 75 MHz pixel clock = 10 ms. Changes become visible
// only at the first active pixel of a frame; the mixer still has two input
// pipeline registers before it uses tone_active for that pixel.
module demo_switch_control #(
    parameter integer DEBOUNCE_CYCLES = 750000,
    parameter integer ENHANCE_TONE_DEFAULT = 0
)(
    input wire clk, rst_n,
    input wire tone_sw,
    input wire [1:0] frame_mode_async,
    input wire vs, de,
    output reg tone_selected,
    output reg tone_active
);
    localparam integer COUNTER_WIDTH = (DEBOUNCE_CYCLES <= 1) ? 1 : $clog2(DEBOUNCE_CYCLES);
    reg tone_meta, tone_sync;
    reg [1:0] mode_meta, mode_sync;
    reg tone_stable;
    reg [COUNTER_WIDTH-1:0] tone_count;
    reg frame_pending;
    wire enhance_default = (ENHANCE_TONE_DEFAULT != 0) && (mode_sync == 2'd2);

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            tone_meta<=0; tone_sync<=0;
            mode_meta<=0; mode_sync<=0;
            tone_stable<=0;
            tone_count<=0;
            tone_selected<=0; tone_active<=0;
            frame_pending<=1;
        end else begin
            tone_meta<=tone_sw; tone_sync<=tone_meta;
            mode_meta<=frame_mode_async; mode_sync<=mode_meta;

            if(tone_sync==tone_stable) tone_count<=0;
            else if(tone_count==DEBOUNCE_CYCLES-1) begin
                tone_stable<=tone_sync; tone_count<=0;
            end else tone_count<=tone_count+1'b1;

            // The DDR display tag settles during vertical blanking. Do not
            // select the tone curve using the physical algorithm switch:
            // the buffered frame can still belong to the previous mode.
            if(vs) frame_pending<=1;
            else if(de && frame_pending) begin
                frame_pending<=0;
                tone_selected<=tone_stable || enhance_default;
                tone_active<=enhance_default ||
                             (tone_stable && (mode_sync[1]==mode_sync[0]));
            end
        end
    end
endmodule
