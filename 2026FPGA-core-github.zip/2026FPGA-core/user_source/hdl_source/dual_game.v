// Two equal-latency renderers share one raster, tracker, timer and debounce.
module dual_game #(
    parameter SHORT_CYCLES=5000, SECOND_CYCLES=10000, CHARGE_SAMPLES=48
)(
    input wire clk,rst_n,allowed,vs,de,timer_tick,
    input wire [23:0] rgb,
    input wire [1:0] keys_n,debounced_keys,synchronized_keys,
    input wire observation_update,observation_valid,
    input wire [10:0] observation_x,
    input wire [9:0] observation_y,
    input wire [7:0] observation_id,
    output wire requested,selected_magic,out_vs,out_de,
    output wire [23:0] out_rgb
);
    reg vs_d;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)vs_d<=0;else vs_d<=vs;
    end
    wire frame_tick=vs && !vs_d;
    wire start_press,switch_press;
    fruit_key_control #(.EXTERNAL_KEYS(1),.EXTERNAL_TICK(1),.SHORT_CYCLES(SHORT_CYCLES)) start_control(
        .clk(clk),.rst_n(rst_n),.enable(allowed),.keys_n(keys_n),.timer_tick(timer_tick),
        .debounced_keys(debounced_keys),.synchronized_keys(synchronized_keys),.press(start_press));
    fruit_key_control #(.EXTERNAL_KEYS(1),.EXTERNAL_TICK(1),.SHORT_CYCLES(SHORT_CYCLES)) switch_control(
        .clk(clk),.rst_n(rst_n),.enable(allowed),.keys_n({keys_n[0],keys_n[1]}),.timer_tick(timer_tick),
        .debounced_keys({debounced_keys[0],debounced_keys[1]}),
        .synchronized_keys({synchronized_keys[0],synchronized_keys[1]}),.press(switch_press));
    wire fruit_requested,magic_requested,fruit_allowed,magic_allowed,fruit_key,magic_key;
    dual_game_control control(.clk(clk),.rst_n(rst_n),.frame_tick(frame_tick),.allowed(allowed),
        .start_press(start_press),.switch_press(switch_press),
        .fruit_requested(fruit_requested),.magic_requested(magic_requested),
        .selected_magic(selected_magic),.requested(requested),
        .fruit_allowed(fruit_allowed),.magic_allowed(magic_allowed),.fruit_key(fruit_key),.magic_key(magic_key));
    wire fruit_vs,fruit_de,magic_vs,magic_de;
    wire [23:0] fruit_rgb,magic_rgb;
    wire [1:0] S_game_state;
    wire [7:0] S_game_score,S_game_time;wire [3:0] S_game_combo,S_game_flash;
    wire S_game_cursor_valid;wire [8:0] S_game_cursor_x,S_game_previous_x;wire [7:0] S_game_cursor_y,S_game_previous_y;
    wire [5:0] S_fruit_state,S_fruit_kind;wire [26:0] S_fruit_x;wire [29:0] S_fruit_y;wire [11:0] S_fruit_age;
    fruit_game_core #(.EXTERNAL_TICK(1),.SECOND_CYCLES(SECOND_CYCLES)) u_fruit_game_core(
        .clk(clk),.rst_n(rst_n),.frame_tick(frame_tick),
        .allowed(fruit_allowed),.key_press(fruit_key),.timer_tick(timer_tick),
        .observation_update(observation_update),.observation_valid(observation_valid),
        .observation_x(observation_x),.observation_y(observation_y),.observation_id(observation_id),
        .requested(fruit_requested),.state(S_game_state),.score10_bcd(S_game_score),.time_bcd(S_game_time),
        .combo(S_game_combo),.flash(S_game_flash),.cursor_valid(S_game_cursor_valid),
        .cursor_x(S_game_cursor_x),.cursor_y(S_game_cursor_y),.previous_x(S_game_previous_x),.previous_y(S_game_previous_y),
        .fruit_state(S_fruit_state),.fruit_kind(S_fruit_kind),.fruit_x(S_fruit_x),.fruit_y(S_fruit_y),.fruit_age(S_fruit_age));
    fruit_game_display u_fruit_game_display(
        .clk(clk),.rst_n(rst_n),.vs(vs),.de(de),.rgb(rgb),
        .state(S_game_state),.score10_bcd(S_game_score),.time_bcd(S_game_time),.combo(S_game_combo),.flash(S_game_flash),
        .cursor_valid(S_game_cursor_valid),.cursor_x(S_game_cursor_x),.cursor_y(S_game_cursor_y),
        .previous_x(S_game_previous_x),.previous_y(S_game_previous_y),
        .fruit_state(S_fruit_state),.fruit_kind(S_fruit_kind),.fruit_x(S_fruit_x),.fruit_y(S_fruit_y),.fruit_age(S_fruit_age),
        .out_vs(fruit_vs),.out_de(fruit_de),.out_rgb(fruit_rgb));
    wire S_magic_cursor_valid,S_magic_armed,S_magic_wave_active;
    wire [8:0] S_magic_x,S_magic_wave_x;wire [7:0] S_magic_y,S_magic_wave_y;
    wire [6:0] S_magic_phase;wire [5:0] S_magic_charge,S_magic_wave_age;
    magic_core #(.CHARGE_SAMPLES(CHARGE_SAMPLES)) u_magic_core(
        .clk(clk),.rst_n(rst_n),.frame_tick(frame_tick),
        .allowed(magic_allowed),.key_press(magic_key),
        .observation_update(observation_update),.observation_valid(observation_valid),
        .observation_x(observation_x),.observation_y(observation_y),.observation_id(observation_id),
        .requested(magic_requested),.cursor_valid(S_magic_cursor_valid),.cursor_x(S_magic_x),.cursor_y(S_magic_y),
        .phase(S_magic_phase),.charge(S_magic_charge),.armed(S_magic_armed),.wave_active(S_magic_wave_active),
        .wave_x(S_magic_wave_x),.wave_y(S_magic_wave_y),.wave_age(S_magic_wave_age));
    magic_display u_magic_display(
        .clk(clk),.rst_n(rst_n),.vs(vs),.de(de),.rgb(rgb),
        .requested(magic_requested),.cursor_valid(S_magic_cursor_valid),.cursor_x(S_magic_x),.cursor_y(S_magic_y),
        .phase(S_magic_phase),.charge(S_magic_charge),.armed(S_magic_armed),.wave_active(S_magic_wave_active),
        .wave_x(S_magic_wave_x),.wave_y(S_magic_wave_y),.wave_age(S_magic_wave_age),
        .out_vs(magic_vs),.out_de(magic_de),.out_rgb(magic_rgb));

    reg [2:0] selection_pipe;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)selection_pipe<=0;
        else selection_pipe<={selection_pipe[1:0],selected_magic};
    end
    assign out_vs=fruit_vs;
    assign out_de=fruit_de;
    assign out_rgb=selection_pipe[2] ? magic_rgb:fruit_rgb;
endmodule
