// Commit selection and gestures at VS. K2 switches only an active session.
// Inactive selection is remembered; K1 restarts the last selected activity.
module dual_game_control(
    input wire clk,rst_n,frame_tick,allowed,start_press,switch_press,
    input wire fruit_requested,magic_requested,
    output reg selected_magic,
    output wire requested,fruit_allowed,magic_allowed,fruit_key,magic_key
);
    reg start_pending,switch_pending;
    assign requested=selected_magic ? magic_requested:fruit_requested;
    wire change_mode=(switch_pending || switch_press) && requested;
    wire target_magic=selected_magic ^ change_mode;
    wire action=start_pending || start_press || change_mode;
    assign fruit_allowed=allowed && !(frame_tick ? target_magic:selected_magic);
    assign magic_allowed=allowed && (frame_tick ? target_magic:selected_magic);
    assign fruit_key=frame_tick && allowed && !target_magic && action;
    assign magic_key=frame_tick && allowed && target_magic && action;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin selected_magic<=0;start_pending<=0;switch_pending<=0;end
        else if(!allowed)begin start_pending<=0;switch_pending<=0;end
        else if(frame_tick)begin
            selected_magic<=target_magic;start_pending<=0;switch_pending<=0;
        end else begin
            if(start_press)start_pending<=1;
            if(switch_press && requested)switch_pending<=1;
        end
    end
endmodule
