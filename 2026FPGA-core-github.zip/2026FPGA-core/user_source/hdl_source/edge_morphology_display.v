// Final display-only morphology. All modes share LINE_TOTAL+3 clocks latency.
// RGB/VS/DE are delayed together; colour, detection, cartoon and night pixels
// pass through unchanged. Only the white-foreground edge view is processed.
module edge_morphology_display #(
    parameter integer IMG_WIDTH=1280,IMG_HEIGHT=720,LINE_TOTAL=1650,
    parameter integer DEBOUNCE_CYCLES=750000,
    parameter integer PRESERVE_OSD=1,SHOW_STATUS=1
)(
    input wire clk,rst_n,key_n,
    input wire [1:0] frame_mode_async,
    input wire night_requested,
    input wire vs,de,
    input wire [23:0] rgb,
    output reg out_vs,out_de,
    output reg [23:0] out_rgb,
    output wire [1:0] selected_mode,
    output reg [1:0] active_mode
);
    localparam integer DELAY=LINE_TOTAL+2,DEPTH=DELAY+1;
    localparam integer AW=$clog2(DEPTH);
    reg [1:0] mode_meta,mode_sync,frame_op;
    morphology_key_control #(.DEBOUNCE_CYCLES(DEBOUNCE_CYCLES)) u_key(
        .clk(clk),.rst_n(rst_n),.key_n(key_n),.enable(mode_sync==1 && !night_requested),.selected_mode(selected_mode));
    reg pending,frame_edge;
    reg [10:0] x;
    reg [9:0] y;
    wire edge_now=pending ? (mode_sync==1 && !night_requested):frame_edge;
    wire [1:0] op_now=pending ? selected_mode:frame_op;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            mode_meta<=0;mode_sync<=0;frame_op<=0;pending<=1;frame_edge<=0;x<=0;y<=0;
        end else begin
            mode_meta<=frame_mode_async;mode_sync<=mode_meta;
            if(vs) begin x<=0;y<=0;pending<=1;end
            else if(de) begin
                if(pending) begin frame_op<=selected_mode;frame_edge<=mode_sync==1 && !night_requested;pending<=0;end
                if(x==IMG_WIDTH-1) begin x<=0;y<=y+1'b1;end else x<=x+1'b1;
            end
        end
    end
    function protected_pixel;
        input [10:0] px;
        input [9:0] py;
        begin
            protected_pixel=PRESERVE_OSD &&
                ((px<160 && py<160) ||
                 (px>=375 && px<575 && py>=120 && py<144) ||
                 (px>=1024 && px<1264 && py>=16 && py<64) ||
                 (px>=928 && px<1264 && py>=72 && py<160) ||
                 (px>=1024 && px<1264 && py>=224 && py<264));
        end
    endfunction
    wire eroded,dilated,morph_valid;
    wire [10:0] morph_x;
    wire [9:0] morph_y;
    // OSD must not seed new white morphology pixels outside its own rectangle.
    wire binary_pixel=rgb[15] && !protected_pixel(x,y);
    morphology_binary_3x3_raster #(.IMG_WIDTH(IMG_WIDTH),.IMG_HEIGHT(IMG_HEIGHT),.LINE_TOTAL(LINE_TOTAL)) u_morph(
        .clk(clk),.rst_n(rst_n),.vs(vs),.de(de),.pixel(binary_pixel),
        .eroded(eroded),.dilated(dilated),.valid(morph_valid),.out_x(morph_x),.out_y(morph_y));

    // Input payload on E0 is read on E0+DELAY. Different read/write addresses
    // avoid same-address RAM collisions. Uninitialised data is masked on reset.
    (* ram_style="bram" *) reg [28:0] delay_mem [0:DEPTH-1];
    reg [AW-1:0] ptr,filled;
    wire [AW-1:0] next_ptr=ptr==DEPTH-1 ? 0:ptr+1'b1;
    reg [28:0] delayed;
    reg delayed_ready;
    always @(posedge clk) begin
        if(rst_n) begin
            delay_mem[ptr]<={edge_now,op_now,vs,de,rgb};
            delayed<=delay_mem[next_ptr];
        end
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin ptr<=0;filled<=0;delayed_ready<=0;end
        else begin
            ptr<=next_ptr;
            if(filled<DELAY) filled<=filled+1'b1;
            delayed_ready<=filled==DELAY;
        end
    end
    wire d_edge=delayed[28],d_vs=delayed[25],d_de=delayed[24];
    wire [1:0] d_op=delayed[27:26];
    wire [23:0] d_rgb=delayed[23:0];
    reg [10:0] ox;
    reg [9:0] oy;

    // Logic-only 5x7 ASCII glyphs; no extra ERAM or DSP is used by the label.
    function [34:0] glyph;
        input [3:0] c;
        begin case(c)
          1:glyph=35'b11110_00001_00001_01110_00001_00001_11110; // 3
          2:glyph=35'b10001_10001_01010_00100_01010_10001_10001; // X
          3:glyph=35'b11110_10001_10001_11110_10001_10001_11110; // B
          4:glyph=35'b10001_10001_01010_00100_00100_00100_00100; // Y
          5:glyph=35'b11110_10001_10001_11110_10000_10000_10000; // P
          6:glyph=35'b01110_10001_10001_11111_10001_10001_10001; // A
          7:glyph=35'b01111_10000_10000_01110_00001_00001_11110; // S
          8:glyph=35'b11111_10000_10000_11110_10000_10000_11111; // E
          9:glyph=35'b11110_10001_10001_11110_10100_10010_10001; // R
          10:glyph=35'b01110_10001_10001_10001_10001_10001_01110; // O
          11:glyph=35'b11110_10001_10001_10001_10001_10001_11110; // D
          12:glyph=35'b11111_00100_00100_00100_00100_00100_11111; // I
          13:glyph=35'b10000_10000_10000_10000_10000_10000_11111; // L
          14:glyph=35'b11111_00100_00100_00100_00100_00100_00100; // T
          default:glyph=0;
        endcase end
    endfunction
    reg [3:0] character;
    wire [10:0] tx=ox-11'd24;
    wire [9:0] ty=oy-10'd184;
    always @* begin
        character=0;
        case(tx[7:4])
            0,2:character=1;
            1:character=2;
            4:character=d_op==0 ? 3:(d_op==1 ? 8:11);
            5:character=d_op==0 ? 4:(d_op==1 ? 9:12);
            6:character=d_op==0 ? 5:(d_op==1 ? 10:13);
            7:character=d_op==0 ? 6:(d_op==1 ? 11:6);
            8:character=d_op==0 ? 7:(d_op==1 ? 8:14);
            9:character=d_op==0 ? 7:(d_op==2 ? 8:0);
            default:character=0;
        endcase
    end
    wire [34:0] bits=glyph(character);
    wire status_panel=SHOW_STATUS && ox>=16 && ox<224 && oy>=176 && oy<208;
    wire status_ink=ox>=24 && ox<216 && oy>=184 && oy<198 &&
                    tx[3:1]<5 && bits[34-(ty[3:1]*5+tx[3:1])];
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin out_vs<=0;out_de<=0;out_rgb<=0;ox<=0;oy<=0;active_mode<=0;end
        else begin
            out_vs<=delayed_ready && d_vs;
            out_de<=delayed_ready && d_de;
            if(delayed_ready && d_vs) begin ox<=0;oy<=0;end
            else if(delayed_ready && d_de) begin
                if(ox==IMG_WIDTH-1) begin ox<=0;oy<=oy+1'b1;end else ox<=ox+1'b1;
                if(ox==0 && oy==0) active_mode<=d_edge ? d_op:2'd0;
            end
            if(!delayed_ready || !d_de) out_rgb<=0;
            else if(d_edge && status_panel) out_rgb<=status_ink ? 24'hc9f7da:24'h10202a;
            else if(d_edge && d_op!=0 && morph_valid && !protected_pixel(ox,oy))
                out_rgb<={24{d_op==1 ? eroded:dilated}};
            else out_rgb<=d_rgb;
        end
    end
endmodule
