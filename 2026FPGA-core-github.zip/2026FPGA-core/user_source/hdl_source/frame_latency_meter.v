// V16: matched-frame latency, RAW AXI first valid beat -> HDMI input first pixel.
// The released PLL produces 75 MHz, NOT its requested 74.25 MHz (PLL.v).
// One tick is 100 us. Registered Gray time crosses to the camera domain;
// the captured {valid, frame_id, time} travels with the DDR bank metadata.
module frame_latency_meter #(
    parameter TICK_CYCLES=7500
)(
    input wire pixel_clk, camera_clk, rst_n,
    input wire capture_first,
    output reg [48:0] capture_tag,
    input wire [48:0] display_tag_async,
    input wire display_vs, display_de,
    output reg [1:0] status, // 0=waiting, 1=valid, 2=older than 999.9 ms
    output reg [15:0] latency_bcd,
    output reg [19:0] frame_id_bcd,
    output wire tick_100us
);
    reg [12:0] tick_div;
    assign tick_100us=tick_div==TICK_CYCLES-1;
    reg [31:0] time_ticks, time_gray;
    wire [31:0] next_ticks=time_ticks+32'd1;
    always @(posedge pixel_clk or negedge rst_n) begin
        if(!rst_n) begin tick_div<=0; time_ticks<=0; time_gray<=0; end
        else if(tick_div==TICK_CYCLES-1) begin
            tick_div<=0; time_ticks<=next_ticks;
            time_gray<=next_ticks^(next_ticks>>1);
        end else tick_div<=tick_div+1'b1;
    end
    reg [31:0] gray_meta, gray_sync;
    wire [31:0] capture_time;
    genvar b;
    generate for(b=0;b<32;b=b+1) begin: gray_decode
        assign capture_time[b]=^gray_sync[31:b];
    end endgenerate
    reg [15:0] capture_id;
    always @(posedge camera_clk or negedge rst_n) begin
        if(!rst_n) begin
            gray_meta<=0; gray_sync<=0; capture_id<=0; capture_tag<=0;
        end else begin
            gray_meta<=time_gray; gray_sync<=gray_meta;
            if(capture_first) begin
                capture_id<=capture_id+1'b1;
                capture_tag<={1'b1,capture_id+16'd1,capture_time};
            end
        end
    end

    // video_out holds this entire payload from read-base selection through
    // the frame. Two stages settle during vertical blanking, before DE.
    reg [48:0] tag_meta, tag_sync;
    reg first_pending, measurement_pending;
    reg [31:0] elapsed, sampled_stamp, previous_stamp;
    reg [15:0] sampled_id, previous_id;
    reg sampled_valid, expired;
    reg [1:0] next_status;
    reg busy;
    reg [4:0] bit_count;
    reg [15:0] latency_shift, id_shift, latency_digits;
    reg [19:0] id_digits;
    function [15:0] add3_4;
        input [15:0] value;
        integer k;
        begin
            add3_4=value;
            for(k=0;k<4;k=k+1)
                if(value[k*4+:4]>=5) add3_4[k*4+:4]=value[k*4+:4]+4'd3;
        end
    endfunction
    function [19:0] add3_5;
        input [19:0] value;
        integer k;
        begin
            add3_5=value;
            for(k=0;k<5;k=k+1)
                if(value[k*4+:4]>=5) add3_5[k*4+:4]=value[k*4+:4]+4'd3;
        end
    endfunction
    wire [15:0] lat_adjust=add3_4(latency_digits);
    wire [19:0] id_adjust=add3_5(id_digits);
    wire [15:0] lat_step={lat_adjust[14:0],latency_shift[15]};
    wire [19:0] id_step={id_adjust[18:0],id_shift[15]};
    always @(posedge pixel_clk or negedge rst_n) begin
        if(!rst_n) begin
            tag_meta<=0; tag_sync<=0; first_pending<=1;
            measurement_pending<=0; elapsed<=0; sampled_stamp<=0;
            sampled_id<=0; sampled_valid<=0; previous_stamp<=0; previous_id<=0;
            expired<=0; next_status<=0; busy<=0; bit_count<=0;
            latency_shift<=0; id_shift<=0; latency_digits<=0; id_digits<=0;
            status<=0; latency_bcd<=0; frame_id_bcd<=0;
        end else begin
            tag_meta<=display_tag_async; tag_sync<=tag_meta;
            measurement_pending<=0;
            if(display_vs) first_pending<=1;
            else if(display_de && first_pending) begin
                first_pending<=0;
                elapsed<=time_ticks-tag_sync[31:0]; // unsigned modular subtraction
                sampled_stamp<=tag_sync[31:0]; sampled_id<=tag_sync[47:32];
                sampled_valid<=tag_sync[48]; measurement_pending<=1;
            end
            if(measurement_pending) begin
                previous_stamp<=sampled_stamp; previous_id<=sampled_id;
                if(!sampled_valid) begin next_status<=0; expired<=0; end
                else if(elapsed>32'd9999 ||
                        (expired && sampled_stamp==previous_stamp && sampled_id==previous_id)) begin
                    next_status<=2; expired<=1;
                end else begin next_status<=1; expired<=0; end
                // Iterative conversion: no division, multiplier, or frame store.
                latency_shift<=elapsed[15:0]; id_shift<=sampled_id;
                latency_digits<=0; id_digits<=0; bit_count<=0; busy<=1;
            end else if(busy) begin
                latency_digits<=lat_step; id_digits<=id_step;
                latency_shift<=latency_shift<<1; id_shift<=id_shift<<1;
                bit_count<=bit_count+1'b1;
                if(bit_count==15) begin
                    latency_bcd<=lat_step; frame_id_bcd<=id_step;
                    status<=next_status; busy<=0;
                end
            end
        end
    end
endmodule
