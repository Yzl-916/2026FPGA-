// Synchronous compact assets: one 4096x4 sprite ROM, one 1024x16 font ROM.
module fruit_assets #(
    parameter SPRITE_FILE="fruit_sprites.hex",
    parameter FONT_FILE="fruit_font.hex"
)(input wire clk,input wire [11:0] sprite_addr,input wire [9:0] font_addr,
  output reg [3:0] sprite_index,output reg [15:0] font_row);
    (* ram_style="bram" *) reg [3:0] sprites[0:4095];
    (* ram_style="bram" *) reg [15:0] font[0:1023];
    initial begin $readmemh(SPRITE_FILE,sprites);$readmemh(FONT_FILE,font);end
    always @(posedge clk)begin sprite_index<=sprites[sprite_addr];font_row<=font[font_addr];end
endmodule
