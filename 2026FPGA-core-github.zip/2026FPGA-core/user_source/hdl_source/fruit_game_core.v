// Game state changes only at the display VS edge (vertical blanking).
// Coordinates use a 320x180 quarter-resolution grid. No image memory/DSP.
// Swept cuts use a bounded Bresenham worker; no endpoint-only collision holes.
module fruit_game_core #(
    parameter SECOND_CYCLES=75000000,
    parameter EXTERNAL_TICK=0,
    parameter ROUND_SECONDS=30,
    parameter SPAWN_FRAMES=40,
    parameter STALE_FRAMES=8
)(
    input wire clk,rst_n,frame_tick,allowed,key_press,timer_tick,
    input wire observation_update,observation_valid,
    input wire [10:0] observation_x,
    input wire [9:0] observation_y,
    input wire [7:0] observation_id,
    output wire requested,
    output reg [1:0] state,
    output reg [7:0] score10_bcd,time_bcd,
    output reg [3:0] combo,
    output reg [3:0] flash,
    output reg cursor_valid,
    output reg [8:0] cursor_x,previous_x,
    output reg [7:0] cursor_y,previous_y,
    output wire [5:0] fruit_state,
    output wire [5:0] fruit_kind,
    output wire [26:0] fruit_x,
    output wire [29:0] fruit_y,
    output wire [11:0] fruit_age
);
    localparam OFF=0,READY=1,PLAY=2,OVER=3;
    localparam CW=SECOND_CYCLES<=1?1:$clog2(SECOND_CYCLES);
    localparam [7:0] ROUND_BCD=((ROUND_SECONDS/10)<<4)|(ROUND_SECONDS%10);
    reg [CW-1:0] second_count;
    reg second_pending;
    reg key_pending;
    reg [1:0] fs[0:2],kind[0:2];
    reg [8:0] fx[0:2];reg [9:0] fy[0:2];
    reg signed [2:0] vx[0:2];reg signed [5:0] vy[0:2];
    reg [3:0] age[0:2];
    genvar g;generate for(g=0;g<3;g=g+1)begin:packed_outputs
        assign fruit_state[g*2+:2]=fs[g];assign fruit_kind[g*2+:2]=kind[g];
        assign fruit_x[g*9+:9]=fx[g];assign fruit_y[g*10+:10]=fy[g];
        assign fruit_age[g*4+:4]=age[g];
    end endgenerate
    assign requested=state!=OFF;
    reg [15:0] random_state;
    reg [5:0] spawn_count,combo_count;
    reg [1:0] spawn_kind,gravity_phase;
    reg physics_phase;
    reg packet_new,packet_valid;
    reg [8:0] packet_x;reg [7:0] packet_y,packet_id,active_id;
    reg [3:0] stale;
    reg [2:0] pending_hits;
    reg worker;
    reg [1:0] collision_slot;
    reg signed [9:0] walk_x,walk_y,end_x,end_y;
    reg signed [10:0] walk_error;
    reg [8:0] walk_dx,walk_dy;
    reg step_x,step_y;
    wire signed [11:0] twice_error=$signed({walk_error[10],walk_error})<<<1;
    wire [8:0] move_dx=packet_x>=cursor_x?packet_x-cursor_x:cursor_x-packet_x;
    wire [8:0] move_dy=packet_y>=cursor_y?{1'b0,packet_y-cursor_y}:{1'b0,cursor_y-packet_y};
    wire new_sample=packet_new && packet_valid;
    wire cut_motion=cursor_valid && new_sample && packet_id==active_id &&
        (move_dx>=2 || move_dy>=2) && move_dx<=96 && move_dy<=96;
    reg [1:0] hit_count;
    reg bomb_hit;
    reg [1:0] free_slot;
    integer i,k_comb;
    always @*begin
        hit_count=0;bomb_hit=0;free_slot=3;
        for(k_comb=0;k_comb<3;k_comb=k_comb+1)begin
            if(fs[k_comb]==0 && free_slot==3)free_slot=k_comb;
            if(fs[k_comb]==1 && pending_hits[k_comb])begin
                if(kind[k_comb]==3)bomb_hit=1;else hit_count=hit_count+1'b1;
            end
        end
    end
    function [7:0] add_points;
        input [7:0] bcd;input [1:0] n;
        reg [4:0] ones;reg [4:0] tens;
        begin
            ones={1'b0,bcd[3:0]}+n;tens={1'b0,bcd[7:4]};
            if(ones>=10)begin ones=ones-10;tens=tens+1'b1;end
            add_points=tens>=10?8'h99:{tens[3:0],ones[3:0]};
        end
    endfunction
    function [7:0] subtract_two;
        input [7:0] b;
        begin
            if(b<=8'h02)subtract_two=0;
            else if(b[3:0]>=2)subtract_two=b-8'h02;
            else subtract_two={b[7:4]-4'd1,b[3:0]+4'd8};
        end
    endfunction
    function [7:0] decrement_bcd;
        input [7:0] b;
        begin decrement_bcd=b[3:0]==0?{b[7:4]-4'd1,4'd9}:b-8'd1;end
    endfunction
    // Observation mailbox. The worker and drawing always consume a frame snapshot.
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin packet_new<=0;packet_valid<=0;packet_x<=0;packet_y<=0;packet_id<=0;end
        else if(!requested)begin packet_new<=0;packet_valid<=0;end
        else begin
            if(frame_tick)packet_new<=0;
            if(observation_update)begin
                packet_new<=1;packet_valid<=observation_valid && observation_x<1280 && observation_y<720;
                packet_x<=observation_x[10:2];packet_y<=observation_y[9:2];packet_id<=observation_id;
            end
        end
    end
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin second_count<=0;second_pending<=0;key_pending<=0;end
        else begin
            if(frame_tick)begin second_pending<=0;key_pending<=0;end
            if(key_press && allowed && !frame_tick)key_pending<=1;
            if(!allowed)key_pending<=0;
            if(state!=PLAY)begin second_count<=0;second_pending<=0;end
            else if(!EXTERNAL_TICK || timer_tick)begin
                if(second_count==SECOND_CYCLES-1)begin second_count<=0;second_pending<=1;end
                else second_count<=second_count+1'b1;
            end
        end
    end
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state<=OFF;score10_bcd<=0;time_bcd<=ROUND_BCD;combo<=0;flash<=0;
            cursor_valid<=0;cursor_x<=0;cursor_y<=0;previous_x<=0;previous_y<=0;active_id<=0;stale<=0;
            random_state<=16'hb4e1;spawn_count<=0;spawn_kind<=0;gravity_phase<=0;physics_phase<=0;combo_count<=0;
            for(i=0;i<3;i=i+1)begin fs[i]<=0;kind[i]<=0;fx[i]<=0;fy[i]<=0;vx[i]<=0;vy[i]<=0;age[i]<=0;end
        end else if(frame_tick)begin
            random_state<={random_state[14:0],random_state[15]^random_state[13]^random_state[12]^random_state[10]};
            if(!allowed)begin state<=OFF;cursor_valid<=0;combo<=0;flash<=0;for(i=0;i<3;i=i+1)fs[i]<=0;end
            else if(key_pending || key_press)begin
                if(state==OFF || state==OVER)begin
                    state<=READY;score10_bcd<=0;time_bcd<=ROUND_BCD;combo<=0;flash<=0;spawn_count<=0;spawn_kind<=0;
                    physics_phase<=0;gravity_phase<=0;combo_count<=0;cursor_valid<=0;stale<=0;
                    for(i=0;i<3;i=i+1)begin fs[i]<=0;age[i]<=0;end
                end else begin state<=OFF;cursor_valid<=0;for(i=0;i<3;i=i+1)fs[i]<=0;end
            end else if(state!=OFF)begin
                if(new_sample)begin
                    cursor_x<=packet_x;cursor_y<=packet_y;cursor_valid<=1;active_id<=packet_id;stale<=0;
                    previous_x<=cut_motion?cursor_x:packet_x;previous_y<=cut_motion?cursor_y:packet_y;
                end else begin
                    previous_x<=cursor_x;previous_y<=cursor_y;
                    if(packet_new || stale>=STALE_FRAMES-1)cursor_valid<=0;
                    if(stale<STALE_FRAMES)stale<=stale+1'b1;
                end
                if(state==READY)begin
                    if(new_sample)begin state<=PLAY;spawn_count<=0;end
                end else if(state==PLAY)begin
                    if(flash!=0)flash<=flash-1'b1;
                    if(combo_count!=0)combo_count<=combo_count-1'b1;
                    if(combo_count==1)combo<=0;
                    if(second_pending)begin
                        time_bcd<=decrement_bcd(time_bcd);
                        if(time_bcd==8'h01)begin state<=OVER;cursor_valid<=0;for(i=0;i<3;i=i+1)fs[i]<=0;end
                    end
                    if(!(second_pending && time_bcd==8'h01))begin
                        if(bomb_hit)begin score10_bcd<=subtract_two(score10_bcd);combo<=0;combo_count<=0;flash<=12;end
                        else if(hit_count!=0)begin
                            score10_bcd<=add_points(score10_bcd,hit_count);combo_count<=60;
                            if(combo_count==0)combo<={2'b0,hit_count};
                            else if({1'b0,combo}+hit_count>9)combo<=9;
                            else combo<=combo+hit_count;
                        end
                        physics_phase<=!physics_phase;
                        if(physics_phase)gravity_phase<=gravity_phase==2?0:gravity_phase+1'b1;
                        for(i=0;i<3;i=i+1)begin
                            if(fs[i]==1 && pending_hits[i])begin fs[i]<=2;age[i]<=0;end
                            else if(physics_phase)begin
                                if(fs[i]==1)begin
                                    fx[i]<=fx[i]+{{6{vx[i][2]}},vx[i]};
                                    fy[i]<=fy[i]+{{4{vy[i][5]}},vy[i]};
                                    if(fx[i]<18)vx[i]<=1;else if(fx[i]>302)vx[i]<=-1;
                                    if(gravity_phase==2)vy[i]<=vy[i]+1'b1;
                                    if(fy[i]>205 && !vy[i][5])begin fs[i]<=0;if(kind[i]!=3)begin combo<=0;combo_count<=0;end end
                                end else if(fs[i]==2)begin
                                    if(age[i]==15)fs[i]<=0;else age[i]<=age[i]+1'b1;
                                end
                            end
                        end
                        if(spawn_count!=0)spawn_count<=spawn_count-1'b1;
                        else if(free_slot!=3)begin
                            fs[free_slot]<=1;kind[free_slot]<=spawn_kind;spawn_kind<=spawn_kind+1'b1;
                            fx[free_slot]<=9'd32+{1'b0,random_state[7:0]};fy[free_slot]<=190;
                            vx[free_slot]<=random_state[8]?3'sd1:-3'sd1;
                            vy[free_slot]<=random_state[9]?-6'sd9:-6'sd10;
                            age[free_slot]<=0;spawn_count<=SPAWN_FRAMES-1;
                        end
                    end
                end
            end
        end
    end
    // Each walk is <=97 grid steps / 291 clocks; one arithmetic unit checks three objects. Only the new camera observation can initiate it.
    // Result bits commit next VS, after which the struck objects cannot score twice.
    reg [9:0] adx,ady;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin worker<=0;collision_slot<=0;pending_hits<=0;walk_x<=0;walk_y<=0;end_x<=0;end_y<=0;
            walk_error<=0;walk_dx<=0;walk_dy<=0;step_x<=0;step_y<=0;end
        else if(frame_tick)begin
            pending_hits<=0;collision_slot<=0;
            worker<=state==PLAY && allowed && !(key_pending || key_press) && cut_motion;
            walk_x<=$signed({1'b0,cursor_x});walk_y<=$signed({2'b0,cursor_y});
            end_x<=$signed({1'b0,packet_x});end_y<=$signed({2'b0,packet_y});
            walk_dx<=move_dx;walk_dy<=move_dy;
            walk_error<=$signed({2'b0,move_dx})-$signed({2'b0,move_dy});
            step_x<=packet_x>=cursor_x;step_y<=packet_y>=cursor_y;
        end else if(worker)begin
            begin
                adx=walk_x>=$signed({1'b0,fx[collision_slot]})?walk_x-$signed({1'b0,fx[collision_slot]}):$signed({1'b0,fx[collision_slot]})-walk_x;
                ady=walk_y>=$signed(fy[collision_slot])?walk_y-$signed(fy[collision_slot]):$signed(fy[collision_slot])-walk_y;
                if(fs[collision_slot]==1 && adx<=14 && ady<=14 && adx+ady<=22)pending_hits[collision_slot]<=1;
            end
            if(collision_slot!=2)collision_slot<=collision_slot+1'b1;
            else begin
            collision_slot<=0;
            if(walk_x==end_x && walk_y==end_y)worker<=0;
            else begin
                if(twice_error> -$signed({3'b0,walk_dy}) && twice_error<$signed({3'b0,walk_dx}))
                    walk_error<=walk_error-$signed({2'b0,walk_dy})+$signed({2'b0,walk_dx});
                else if(twice_error> -$signed({3'b0,walk_dy}))walk_error<=walk_error-$signed({2'b0,walk_dy});
                else if(twice_error<$signed({3'b0,walk_dx}))walk_error<=walk_error+$signed({2'b0,walk_dx});
                if(twice_error> -$signed({3'b0,walk_dy}))walk_x<=step_x?walk_x+1'b1:walk_x-1'b1;
                if(twice_error<$signed({3'b0,walk_dx}))walk_y<=step_y?walk_y+1'b1:walk_y-1'b1;
            end
            end
        end
    end
endmodule
