// K1 short-release gesture. A chord, a held-at-reset key, a long press,
// or leaving the eligible mode cancels the entire gesture.
module fruit_key_control #(
    parameter DEBOUNCE_CYCLES=750000,
    parameter SHORT_CYCLES=37500000,
    parameter EXTERNAL_KEYS=0,
    parameter EXTERNAL_TICK=0
)(
    input wire clk,rst_n,enable,
    input wire [1:0] keys_n,
    input wire [1:0] debounced_keys,synchronized_keys,
    input wire timer_tick,
    output reg press
);
    localparam DW=DEBOUNCE_CYCLES<=1?1:$clog2(DEBOUNCE_CYCLES);
    localparam HW=SHORT_CYCLES<=1?1:$clog2(SHORT_CYCLES+1);
    reg [1:0] meta,local_sync,local_stable;
    wire [1:0] sync=EXTERNAL_KEYS?synchronized_keys:local_sync;
    wire [1:0] stable=EXTERNAL_KEYS?debounced_keys:local_stable;
    reg [DW-1:0] db0,db1;
    reg armed,candidate,old_k1;
    reg [HW-1:0] age;
    generate if(!EXTERNAL_KEYS)begin: debounce
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n)begin meta<=0;local_sync<=0;local_stable<=0;db0<=0;db1<=0;end
        else begin
            meta<=keys_n;local_sync<=meta;
            if(sync[0]==stable[0])db0<=0;
            else if(db0==DEBOUNCE_CYCLES-1)begin local_stable[0]<=sync[0];db0<=0;end
            else db0<=db0+1'b1;
            if(sync[1]==stable[1])db1<=0;
            else if(db1==DEBOUNCE_CYCLES-1)begin local_stable[1]<=sync[1];db1<=0;end
            else db1<=db1+1'b1;
        end
    end
    end endgenerate
    // Allow the shared input synchronizer to settle before accepting release.
    reg [3:0] startup;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)startup<=0;else startup<={startup[2:0],1'b1};
    end
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin press<=0;armed<=0;candidate<=0;old_k1<=0;age<=0;end
        else begin
            press<=0;old_k1<=stable[0];
            if(!enable || !startup[3])begin armed<=0;candidate<=0;age<=0;end
            else if(!stable[1] || !sync[1])begin armed<=0;candidate<=0;age<=0;end
            else if(!stable[0])begin
                if(old_k1)begin candidate<=armed;armed<=0;age<=0;end
                else if(candidate && (!EXTERNAL_TICK || timer_tick))begin
                    if(age==SHORT_CYCLES-1)candidate<=0;
                    else age<=age+1'b1;
                end
            end else begin
                if(!old_k1 && candidate)press<=1;
                candidate<=0;age<=0;if(sync==2'b11)armed<=1;
            end
        end
    end
endmodule
