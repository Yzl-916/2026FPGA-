// SW3 display-only grayscale. Two pixel stages for both bypass and grayscale.
// Weighted RGB luma, rounded: (77*R + 150*G + 29*B + 128) >> 8.
module grayscale_display #(
    parameter integer DEBOUNCE_CYCLES = 750000
)(
    input wire clk, rst_n,
    input wire gray_sw,
    input wire vs, hs, de,
    input wire [23:0] rgb,
    output reg out_vs, out_hs, out_de,
    output reg [23:0] out_rgb,
    output reg gray_active
);
    localparam integer CW = (DEBOUNCE_CYCLES <= 1) ? 1 : $clog2(DEBOUNCE_CYCLES);
    reg gray_meta, gray_sync, gray_stable;
    reg [CW-1:0] debounce_count;
    reg frame_pending;
    wire pixel_gray = (frame_pending && de && !vs) ? gray_stable : gray_active;
    reg vs_1, hs_1, de_1, gray_1;
    reg [23:0] rgb_1;
    wire [15:0] r = {8'd0,rgb[23:16]};
    wire [15:0] g = {8'd0,rgb[15:8]};
    wire [15:0] b = {8'd0,rgb[7:0]};
    reg [15:0] wr_1, wg_1, wb_1;
    wire [15:0] luma_sum = wr_1 + wg_1 + wb_1 + 16'd128;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            gray_meta<=0; gray_sync<=0; gray_stable<=0;
            debounce_count<=0; frame_pending<=1; gray_active<=0;
        end else begin
            gray_meta<=gray_sw; gray_sync<=gray_meta;
            if(gray_sync==gray_stable) debounce_count<=0;
            else if(debounce_count==DEBOUNCE_CYCLES-1) begin
                gray_stable<=gray_sync; debounce_count<=0;
            end else debounce_count<=debounce_count+1'b1;
            if(vs) frame_pending<=1;
            else if(de && frame_pending) begin
                frame_pending<=0;
                gray_active<=gray_stable;
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            vs_1<=0; hs_1<=0; de_1<=0; gray_1<=0; rgb_1<=0;
            wr_1<=0; wg_1<=0; wb_1<=0;
            out_vs<=0; out_hs<=0; out_de<=0; out_rgb<=0;
        end else begin
            vs_1<=vs; hs_1<=hs; de_1<=de;
            gray_1<=pixel_gray; rgb_1<=rgb;
            wr_1<=(r<<6)+(r<<3)+(r<<2)+r;
            wg_1<=(g<<7)+(g<<4)+(g<<2)+(g<<1);
            wb_1<=(b<<4)+(b<<3)+(b<<2)+b;
            out_vs<=vs_1; out_hs<=hs_1; out_de<=de_1;
            out_rgb<=gray_1 ? {3{luma_sum[15:8]}} : rgb_1;
        end
    end
endmodule
