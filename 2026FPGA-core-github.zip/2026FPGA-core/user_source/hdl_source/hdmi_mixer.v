module hdmi_mixer #(
    parameter H_OFFSET = 128,
    parameter V_OFFSET = 60,
    parameter IMG_WIDTH = 1280,
    parameter IMG_HEIGHT = 720,
    parameter integer DEBUG_MODE = 0,
    // Legacy default keeps the pre-V20 standalone mixer contract bit exact.
    // The V20 board top explicitly enables the physical demo switches.
    parameter integer DEMO_CONTROLS = 0,
    // V19.1 natural-colour curve; brightness enable is controlled separately.
    parameter integer RESTORE_BASE19 = 0,
    // V21.26 board profile: mode 2 always enables brightness correction.
    parameter integer ENHANCE_TONE_DEFAULT = 0,
    parameter integer FILTER_DEMO_ENABLE = 0,
    parameter integer CTRL_DEBOUNCE_CYCLES = 750000
)(
    input wire [2:0] I_art_selection,
    output reg [2:0] O_frame_effect,
    output wire [23:0] O_gaussian_rgb,
    output wire [23:0] O_sharpen_rgb,
    input wire I_color_view,
    input wire I_tone_sw,
    input wire I_night_active,
    input wire [1:0] I_frame_mode_async,
    output wire [23:0] O_display_frame_bcd,
    output wire O_tone_selected,
    output wire O_tone_active,
    input wire        I_clk,
    input wire        I_rst_n,

    input wire        I_video_vsync,
    input wire        I_video_hsync,
    input wire        I_video_de,
    input wire        I_video_user,
    input wire        I_video_last,

    input wire[3:0]   I_debug_status,

    output wire       O_video_rd_en,
    input wire[23:0]  I_video_rd_data,

    output reg        O_hdmi_vsync,
    output reg        O_hdmi_hsync,
    output reg        O_hdmi_de,
    output reg[23:0]  O_scene_data,
    output reg[35:0]  O_night_source_q4,
    output reg        O_night_de,
    output reg        O_night_vs,
    output reg[23:0]  O_hdmi_data
);

    reg        S_video_vsync_1d;
    reg        S_video_vsync_2d;
    reg        S_video_hsync_1d;
    reg        S_video_hsync_2d;
    reg        S_video_de_1d;
    reg        S_video_de_2d;
    reg [23:0] S_video_data_1d;
    reg [23:0] S_video_data_2d;
    reg [11:0] S_x;
    reg [11:0] S_y;
    reg [11:0] S_x_1d;
    reg [11:0] S_x_2d;
    reg [11:0] S_y_1d;
    reg [11:0] S_y_2d;

    reg        S_osd_hit;
    reg [23:0] S_osd_color;
    reg [11:0] S_logo_x;
    reg [11:0] S_logo_y;
    reg [3:0]  S_char_idx;
    reg [2:0]  S_char_row;
    reg [2:0]  S_char_col;
    reg [4:0]  S_char_bits;
    reg        S_char_on;
    reg        S_logo_blue_on;
    reg        S_logo_red_on;
    reg [11:0] S_logo_tmp_y;
    reg [3:0]  S_logo_red_band;
    reg [11:0] S_logo_red_x_start;
    reg [11:0] S_logo_red_x_end;
    reg [14:0] S_logo_addr;
    wire[24:0] S_logo_pixel;
    reg [31:0] S_frame_cnt;
    reg [11:0] S_dyn_x;
    reg [11:0] S_dyn_y;
    reg [3:0]  S_dyn_char;
    reg [2:0]  S_dyn_col;
    reg [2:0]  S_dyn_row;
    reg [4:0]  S_dyn_bits;
    reg        S_dyn_on;
    reg [3:0]  S_dyn_digit_idx;
    reg [11:0] S_dyn_digit_x;
    reg [6:0]  S_dyn_seg;
    reg [3:0]  S_cnt_d0;
    reg [3:0]  S_cnt_d1;
    reg [3:0]  S_cnt_d2;
    reg [3:0]  S_cnt_d3;
    reg [3:0]  S_cnt_d4;
    reg [3:0]  S_cnt_d5;
    assign O_display_frame_bcd = {S_cnt_d5,S_cnt_d4,S_cnt_d3,S_cnt_d2,S_cnt_d1,S_cnt_d0};
    reg [2:0]  S_lbl_row;
    reg [2:0]  S_lbl_col;
    reg [1:0]  S_lbl_idx;
    reg [4:0]  S_lbl_bits;
    reg [6:0]  S_lbl_local_x;
    reg [3:0]  S_dyn_dec_digit;
    reg [4:0]  S_cn_local_x;
    reg [4:0]  S_cn_local_y;
    reg [3:0]  S_cn_col;
    reg [3:0]  S_cn_row;
    reg [15:0] S_cn_row_bits;
    reg        S_cn_on;
    reg [9:0]  S_cn_scale_x;
    reg [9:0]  S_cn_scale_y;
    reg [7:0]  S_pf_char;
    reg [4:0]  S_pf_local_x;
    reg [4:0]  S_pf_local_y;
    reg [3:0]  S_pf_col;
    reg [3:0]  S_pf_row;
    wire [15:0] S_pf_row_bits;
    reg        S_pf_on;
    reg [9:0]  S_pf_scale_x;
    reg [9:0]  S_pf_scale_y;

    localparam LOGO_X = 12'd0;
    localparam LOGO_Y = 12'd0;
    localparam LOGO_W = 12'd160;
    localparam LOGO_H = 12'd160;

    localparam COLOR_LOGO_BLUE   = 24'h1f315c;
    localparam COLOR_LOGO_RED    = 24'hec1c2d;
    localparam COLOR_TEXT        = 24'h00e6ff;
    localparam DYN_OSD_X         = 12'd375;
    localparam DYN_OSD_Y         = 12'd120;
    localparam DYN_OSD_W         = 12'd200;
    localparam DYN_OSD_H         = 12'd24;
    localparam CN_Y_OFFSET       = 12'd2;
    localparam COLOR_DYN_TEXT    = 24'hfff200;
    localparam CHAR_AN           = 8'h80;
    localparam CHAR_LU           = 8'h81;
    localparam CHAR_C            = 8'h43;
    localparam CHAR_N            = 8'h4e;
    localparam CHAR_T            = 8'h54;
    localparam CHAR_0            = 8'h30;
    localparam CHAR_COLON        = 8'h3a;

    function [4:0] F_logo_text_bits;
        input [3:0] I_char;
        input [2:0] I_row;
        begin
            case(I_char)
                4'd0: begin
                    case(I_row) // A
                        3'd0: F_logo_text_bits = 5'b01110;
                        3'd1: F_logo_text_bits = 5'b10001;
                        3'd2: F_logo_text_bits = 5'b10001;
                        3'd3: F_logo_text_bits = 5'b11111;
                        3'd4: F_logo_text_bits = 5'b10001;
                        3'd5: F_logo_text_bits = 5'b10001;
                        3'd6: F_logo_text_bits = 5'b10001;
                        default: F_logo_text_bits = 5'b00000;
                    endcase
                end
                4'd1: begin
                    case(I_row) // N
                        3'd0: F_logo_text_bits = 5'b10001;
                        3'd1: F_logo_text_bits = 5'b11001;
                        3'd2: F_logo_text_bits = 5'b10101;
                        3'd3: F_logo_text_bits = 5'b10011;
                        3'd4: F_logo_text_bits = 5'b10001;
                        3'd5: F_logo_text_bits = 5'b10001;
                        3'd6: F_logo_text_bits = 5'b10001;
                        default: F_logo_text_bits = 5'b00000;
                    endcase
                end
                4'd2: begin
                    case(I_row) // L
                        3'd0: F_logo_text_bits = 5'b10000;
                        3'd1: F_logo_text_bits = 5'b10000;
                        3'd2: F_logo_text_bits = 5'b10000;
                        3'd3: F_logo_text_bits = 5'b10000;
                        3'd4: F_logo_text_bits = 5'b10000;
                        3'd5: F_logo_text_bits = 5'b10000;
                        3'd6: F_logo_text_bits = 5'b11111;
                        default: F_logo_text_bits = 5'b00000;
                    endcase
                end
                4'd3: begin
                    case(I_row) // O
                        3'd0: F_logo_text_bits = 5'b01110;
                        3'd1: F_logo_text_bits = 5'b10001;
                        3'd2: F_logo_text_bits = 5'b10001;
                        3'd3: F_logo_text_bits = 5'b10001;
                        3'd4: F_logo_text_bits = 5'b10001;
                        3'd5: F_logo_text_bits = 5'b10001;
                        3'd6: F_logo_text_bits = 5'b01110;
                        default: F_logo_text_bits = 5'b00000;
                    endcase
                end
                4'd4: begin
                    case(I_row) // G
                        3'd0: F_logo_text_bits = 5'b01110;
                        3'd1: F_logo_text_bits = 5'b10001;
                        3'd2: F_logo_text_bits = 5'b10000;
                        3'd3: F_logo_text_bits = 5'b10111;
                        3'd4: F_logo_text_bits = 5'b10001;
                        3'd5: F_logo_text_bits = 5'b10001;
                        3'd6: F_logo_text_bits = 5'b01110;
                        default: F_logo_text_bits = 5'b00000;
                    endcase
                end
                4'd5: begin
                    case(I_row) // I
                        3'd0: F_logo_text_bits = 5'b11111;
                        3'd1: F_logo_text_bits = 5'b00100;
                        3'd2: F_logo_text_bits = 5'b00100;
                        3'd3: F_logo_text_bits = 5'b00100;
                        3'd4: F_logo_text_bits = 5'b00100;
                        3'd5: F_logo_text_bits = 5'b00100;
                        3'd6: F_logo_text_bits = 5'b11111;
                        default: F_logo_text_bits = 5'b00000;
                    endcase
                end
                4'd6: begin
                    case(I_row) // C
                        3'd0: F_logo_text_bits = 5'b01110;
                        3'd1: F_logo_text_bits = 5'b10001;
                        3'd2: F_logo_text_bits = 5'b10000;
                        3'd3: F_logo_text_bits = 5'b10000;
                        3'd4: F_logo_text_bits = 5'b10000;
                        3'd5: F_logo_text_bits = 5'b10001;
                        3'd6: F_logo_text_bits = 5'b01110;
                        default: F_logo_text_bits = 5'b00000;
                    endcase
                end
                default: F_logo_text_bits = 5'b00000;
            endcase
        end
    endfunction

    // 7-seg bit mapping: {a,b,c,d,e,f,g}
    function [6:0] F_hex7seg;
        input [3:0] I_hex;
        begin
            case(I_hex)
                4'h0: F_hex7seg = 7'b1111110;
                4'h1: F_hex7seg = 7'b0110000;
                4'h2: F_hex7seg = 7'b1101101;
                4'h3: F_hex7seg = 7'b1111001;
                4'h4: F_hex7seg = 7'b0110011;
                4'h5: F_hex7seg = 7'b1011011;
                4'h6: F_hex7seg = 7'b1011111;
                4'h7: F_hex7seg = 7'b1110000;
                4'h8: F_hex7seg = 7'b1111111;
                4'h9: F_hex7seg = 7'b1111011;
                4'ha: F_hex7seg = 7'b1110111;
                4'hb: F_hex7seg = 7'b0011111;
                4'hc: F_hex7seg = 7'b1001110;
                4'hd: F_hex7seg = 7'b0111101;
                4'he: F_hex7seg = 7'b1001111;
                4'hf: F_hex7seg = 7'b1000111;
                default: F_hex7seg = 7'b0000000;
            endcase
        end
    endfunction

    function [4:0] F_cnt_label_bits;
        input [1:0] I_idx;
        input [2:0] I_row;
        begin
            case(I_idx)
                2'd0: begin // C
                    case(I_row)
                        3'd0: F_cnt_label_bits = 5'b01110;
                        3'd1: F_cnt_label_bits = 5'b10001;
                        3'd2: F_cnt_label_bits = 5'b10000;
                        3'd3: F_cnt_label_bits = 5'b10000;
                        3'd4: F_cnt_label_bits = 5'b10000;
                        3'd5: F_cnt_label_bits = 5'b10001;
                        3'd6: F_cnt_label_bits = 5'b01110;
                        default: F_cnt_label_bits = 5'b00000;
                    endcase
                end
                2'd1: begin // N
                    case(I_row)
                        3'd0: F_cnt_label_bits = 5'b10001;
                        3'd1: F_cnt_label_bits = 5'b11001;
                        3'd2: F_cnt_label_bits = 5'b10101;
                        3'd3: F_cnt_label_bits = 5'b10011;
                        3'd4: F_cnt_label_bits = 5'b10001;
                        3'd5: F_cnt_label_bits = 5'b10001;
                        3'd6: F_cnt_label_bits = 5'b10001;
                        default: F_cnt_label_bits = 5'b00000;
                    endcase
                end
                2'd2: begin // T
                    case(I_row)
                        3'd0: F_cnt_label_bits = 5'b11111;
                        3'd1: F_cnt_label_bits = 5'b00100;
                        3'd2: F_cnt_label_bits = 5'b00100;
                        3'd3: F_cnt_label_bits = 5'b00100;
                        3'd4: F_cnt_label_bits = 5'b00100;
                        3'd5: F_cnt_label_bits = 5'b00100;
                        3'd6: F_cnt_label_bits = 5'b00100;
                        default: F_cnt_label_bits = 5'b00000;
                    endcase
                end
                default: begin // ':'
                    case(I_row)
                        3'd2: F_cnt_label_bits = 5'b00100;
                        3'd5: F_cnt_label_bits = 5'b00100;
                        default: F_cnt_label_bits = 5'b00000;
                    endcase
                end
            endcase
        end
    endfunction

    // Minimal 16x16 Chinese bitmap rows for "an" and "lu".
    function [15:0] F_cn16_row;
        input I_char; // 0: an, 1: lu
        input [3:0] I_row;
        begin
            if(!I_char) begin
                case(I_row)
                    4'd0:  F_cn16_row = 16'h0200;
                    4'd1:  F_cn16_row = 16'h7ff0;
                    4'd2:  F_cn16_row = 16'h4410;
                    4'd3:  F_cn16_row = 16'h0400;
                    4'd4:  F_cn16_row = 16'h7ff0;
                    4'd5:  F_cn16_row = 16'h0840;
                    4'd6:  F_cn16_row = 16'h1040;
                    4'd7:  F_cn16_row = 16'h1c80;
                    4'd8:  F_cn16_row = 16'h0300;
                    4'd9:  F_cn16_row = 16'h0cc0;
                    4'd10: F_cn16_row = 16'h7020;
                    4'd11: F_cn16_row = 16'h0000;
                    4'd12: F_cn16_row = 16'h0000;
                    4'd13: F_cn16_row = 16'h0000;
                    4'd14: F_cn16_row = 16'h0000;
                    4'd15: F_cn16_row = 16'h0000;
                    default: F_cn16_row = 16'h0000;
                endcase
            end
            else begin
                case(I_row)
                    4'd0:  F_cn16_row = 16'h79e0;
                    4'd1:  F_cn16_row = 16'h4a20;
                    4'd2:  F_cn16_row = 16'h4d40;
                    4'd3:  F_cn16_row = 16'h7880;
                    4'd4:  F_cn16_row = 16'h1140;
                    4'd5:  F_cn16_row = 16'h1630;
                    4'd6:  F_cn16_row = 16'h5be0;
                    4'd7:  F_cn16_row = 16'h5220;
                    4'd8:  F_cn16_row = 16'h5220;
                    4'd9:  F_cn16_row = 16'h5be0;
                    4'd10: F_cn16_row = 16'h6220;
                    4'd11: F_cn16_row = 16'h0000;
                    4'd12: F_cn16_row = 16'h0000;
                    4'd13: F_cn16_row = 16'h0000;
                    4'd14: F_cn16_row = 16'h0000;
                    4'd15: F_cn16_row = 16'h0000;
                    default: F_cn16_row = 16'h0000;
                endcase
            end
        end
    endfunction

    function [4:0] F_dyn_char_bits;
        input [3:0] I_char;
        input [2:0] I_row;
        begin
            case(I_char)
                4'h0: begin case(I_row) 3'd0:F_dyn_char_bits=5'b01110; 3'd1:F_dyn_char_bits=5'b10001; 3'd2:F_dyn_char_bits=5'b10011; 3'd3:F_dyn_char_bits=5'b10101; 3'd4:F_dyn_char_bits=5'b11001; 3'd5:F_dyn_char_bits=5'b10001; 3'd6:F_dyn_char_bits=5'b01110; default:F_dyn_char_bits=5'b00000; endcase end
                4'h1: begin case(I_row) 3'd0:F_dyn_char_bits=5'b00100; 3'd1:F_dyn_char_bits=5'b01100; 3'd2:F_dyn_char_bits=5'b00100; 3'd3:F_dyn_char_bits=5'b00100; 3'd4:F_dyn_char_bits=5'b00100; 3'd5:F_dyn_char_bits=5'b00100; 3'd6:F_dyn_char_bits=5'b01110; default:F_dyn_char_bits=5'b00000; endcase end
                4'h2: begin case(I_row) 3'd0:F_dyn_char_bits=5'b01110; 3'd1:F_dyn_char_bits=5'b10001; 3'd2:F_dyn_char_bits=5'b00001; 3'd3:F_dyn_char_bits=5'b00110; 3'd4:F_dyn_char_bits=5'b01000; 3'd5:F_dyn_char_bits=5'b10000; 3'd6:F_dyn_char_bits=5'b11111; default:F_dyn_char_bits=5'b00000; endcase end
                4'h3: begin case(I_row) 3'd0:F_dyn_char_bits=5'b11110; 3'd1:F_dyn_char_bits=5'b00001; 3'd2:F_dyn_char_bits=5'b00001; 3'd3:F_dyn_char_bits=5'b01110; 3'd4:F_dyn_char_bits=5'b00001; 3'd5:F_dyn_char_bits=5'b00001; 3'd6:F_dyn_char_bits=5'b11110; default:F_dyn_char_bits=5'b00000; endcase end
                4'h4: begin case(I_row) 3'd0:F_dyn_char_bits=5'b00010; 3'd1:F_dyn_char_bits=5'b00110; 3'd2:F_dyn_char_bits=5'b01010; 3'd3:F_dyn_char_bits=5'b10010; 3'd4:F_dyn_char_bits=5'b11111; 3'd5:F_dyn_char_bits=5'b00010; 3'd6:F_dyn_char_bits=5'b00010; default:F_dyn_char_bits=5'b00000; endcase end
                4'h5: begin case(I_row) 3'd0:F_dyn_char_bits=5'b11111; 3'd1:F_dyn_char_bits=5'b10000; 3'd2:F_dyn_char_bits=5'b11110; 3'd3:F_dyn_char_bits=5'b00001; 3'd4:F_dyn_char_bits=5'b00001; 3'd5:F_dyn_char_bits=5'b10001; 3'd6:F_dyn_char_bits=5'b01110; default:F_dyn_char_bits=5'b00000; endcase end
                4'h6: begin case(I_row) 3'd0:F_dyn_char_bits=5'b00110; 3'd1:F_dyn_char_bits=5'b01000; 3'd2:F_dyn_char_bits=5'b10000; 3'd3:F_dyn_char_bits=5'b11110; 3'd4:F_dyn_char_bits=5'b10001; 3'd5:F_dyn_char_bits=5'b10001; 3'd6:F_dyn_char_bits=5'b01110; default:F_dyn_char_bits=5'b00000; endcase end
                4'h7: begin case(I_row) 3'd0:F_dyn_char_bits=5'b11111; 3'd1:F_dyn_char_bits=5'b00001; 3'd2:F_dyn_char_bits=5'b00010; 3'd3:F_dyn_char_bits=5'b00100; 3'd4:F_dyn_char_bits=5'b01000; 3'd5:F_dyn_char_bits=5'b01000; 3'd6:F_dyn_char_bits=5'b01000; default:F_dyn_char_bits=5'b00000; endcase end
                4'h8: begin case(I_row) 3'd0:F_dyn_char_bits=5'b01110; 3'd1:F_dyn_char_bits=5'b10001; 3'd2:F_dyn_char_bits=5'b10001; 3'd3:F_dyn_char_bits=5'b01110; 3'd4:F_dyn_char_bits=5'b10001; 3'd5:F_dyn_char_bits=5'b10001; 3'd6:F_dyn_char_bits=5'b01110; default:F_dyn_char_bits=5'b00000; endcase end
                4'h9: begin case(I_row) 3'd0:F_dyn_char_bits=5'b01110; 3'd1:F_dyn_char_bits=5'b10001; 3'd2:F_dyn_char_bits=5'b10001; 3'd3:F_dyn_char_bits=5'b01111; 3'd4:F_dyn_char_bits=5'b00001; 3'd5:F_dyn_char_bits=5'b00010; 3'd6:F_dyn_char_bits=5'b11100; default:F_dyn_char_bits=5'b00000; endcase end
                4'ha: begin case(I_row) 3'd0:F_dyn_char_bits=5'b01110; 3'd1:F_dyn_char_bits=5'b10001; 3'd2:F_dyn_char_bits=5'b10001; 3'd3:F_dyn_char_bits=5'b11111; 3'd4:F_dyn_char_bits=5'b10001; 3'd5:F_dyn_char_bits=5'b10001; 3'd6:F_dyn_char_bits=5'b10001; default:F_dyn_char_bits=5'b00000; endcase end
                4'hb: begin case(I_row) 3'd0:F_dyn_char_bits=5'b11110; 3'd1:F_dyn_char_bits=5'b10001; 3'd2:F_dyn_char_bits=5'b10001; 3'd3:F_dyn_char_bits=5'b11110; 3'd4:F_dyn_char_bits=5'b10001; 3'd5:F_dyn_char_bits=5'b10001; 3'd6:F_dyn_char_bits=5'b11110; default:F_dyn_char_bits=5'b00000; endcase end
                4'hc: begin case(I_row) 3'd0:F_dyn_char_bits=5'b01110; 3'd1:F_dyn_char_bits=5'b10001; 3'd2:F_dyn_char_bits=5'b10000; 3'd3:F_dyn_char_bits=5'b10000; 3'd4:F_dyn_char_bits=5'b10000; 3'd5:F_dyn_char_bits=5'b10001; 3'd6:F_dyn_char_bits=5'b01110; default:F_dyn_char_bits=5'b00000; endcase end
                4'hd: begin case(I_row) 3'd0:F_dyn_char_bits=5'b11110; 3'd1:F_dyn_char_bits=5'b10001; 3'd2:F_dyn_char_bits=5'b10001; 3'd3:F_dyn_char_bits=5'b10001; 3'd4:F_dyn_char_bits=5'b10001; 3'd5:F_dyn_char_bits=5'b10001; 3'd6:F_dyn_char_bits=5'b11110; default:F_dyn_char_bits=5'b00000; endcase end
                4'he: begin case(I_row) 3'd0:F_dyn_char_bits=5'b11111; 3'd1:F_dyn_char_bits=5'b10000; 3'd2:F_dyn_char_bits=5'b10000; 3'd3:F_dyn_char_bits=5'b11110; 3'd4:F_dyn_char_bits=5'b10000; 3'd5:F_dyn_char_bits=5'b10000; 3'd6:F_dyn_char_bits=5'b11111; default:F_dyn_char_bits=5'b00000; endcase end
                4'hf: begin case(I_row) 3'd0:F_dyn_char_bits=5'b11111; 3'd1:F_dyn_char_bits=5'b10000; 3'd2:F_dyn_char_bits=5'b10000; 3'd3:F_dyn_char_bits=5'b11110; 3'd4:F_dyn_char_bits=5'b10000; 3'd5:F_dyn_char_bits=5'b10000; 3'd6:F_dyn_char_bits=5'b10000; default:F_dyn_char_bits=5'b00000; endcase end
                default: F_dyn_char_bits = 5'b00000;
            endcase
        end
    endfunction

    // Unified prefix character library (16x16 rows): an/lu/C/N/T/:
    function [15:0] F_osd_char16_row;
        input [7:0] I_char;
        input [3:0] I_row;
        begin
            case(I_char)
                CHAR_AN: begin
                    case(I_row)
                        4'd0:  F_osd_char16_row = 16'h0200;
                        4'd1:  F_osd_char16_row = 16'h7ff0;
                        4'd2:  F_osd_char16_row = 16'h4410;
                        4'd3:  F_osd_char16_row = 16'h0400;
                        4'd4:  F_osd_char16_row = 16'h7ff0;
                        4'd5:  F_osd_char16_row = 16'h0840;
                        4'd6:  F_osd_char16_row = 16'h1040;
                        4'd7:  F_osd_char16_row = 16'h1c80;
                        4'd8:  F_osd_char16_row = 16'h0300;
                        4'd9:  F_osd_char16_row = 16'h0cc0;
                        4'd10: F_osd_char16_row = 16'h7020;
                        default: F_osd_char16_row = 16'h0000;
                    endcase
                end
                CHAR_LU: begin
                    case(I_row)
                        4'd0:  F_osd_char16_row = 16'h79e0;
                        4'd1:  F_osd_char16_row = 16'h4a20;
                        4'd2:  F_osd_char16_row = 16'h4d40;
                        4'd3:  F_osd_char16_row = 16'h7880;
                        4'd4:  F_osd_char16_row = 16'h1140;
                        4'd5:  F_osd_char16_row = 16'h1630;
                        4'd6:  F_osd_char16_row = 16'h5be0;
                        4'd7:  F_osd_char16_row = 16'h5220;
                        4'd8:  F_osd_char16_row = 16'h5220;
                        4'd9:  F_osd_char16_row = 16'h5be0;
                        4'd10: F_osd_char16_row = 16'h6220;
                        default: F_osd_char16_row = 16'h0000;
                    endcase
                end
                CHAR_C: begin
                    case(I_row)
                        4'd2:  F_osd_char16_row = 16'h03f0;
                        4'd3:  F_osd_char16_row = 16'h0c0c;
                        4'd4:  F_osd_char16_row = 16'h1800;
                        4'd5:  F_osd_char16_row = 16'h3000;
                        4'd6:  F_osd_char16_row = 16'h3000;
                        4'd7:  F_osd_char16_row = 16'h3000;
                        4'd8:  F_osd_char16_row = 16'h3000;
                        4'd9:  F_osd_char16_row = 16'h3000;
                        4'd10: F_osd_char16_row = 16'h1800;
                        4'd11: F_osd_char16_row = 16'h0c0c;
                        4'd12: F_osd_char16_row = 16'h03f0;
                        default: F_osd_char16_row = 16'h0000;
                    endcase
                end
                CHAR_N: begin
                    case(I_row)
                        4'd2:  F_osd_char16_row = 16'h300c;
                        4'd3:  F_osd_char16_row = 16'h380c;
                        4'd4:  F_osd_char16_row = 16'h3c0c;
                        4'd5:  F_osd_char16_row = 16'h360c;
                        4'd6:  F_osd_char16_row = 16'h330c;
                        4'd7:  F_osd_char16_row = 16'h318c;
                        4'd8:  F_osd_char16_row = 16'h30cc;
                        4'd9:  F_osd_char16_row = 16'h306c;
                        4'd10: F_osd_char16_row = 16'h303c;
                        4'd11: F_osd_char16_row = 16'h301c;
                        4'd12: F_osd_char16_row = 16'h300c;
                        default: F_osd_char16_row = 16'h0000;
                    endcase
                end
                CHAR_T: begin
                    case(I_row)
                        4'd2:  F_osd_char16_row = 16'h3ffc;
                        4'd3:  F_osd_char16_row = 16'h03c0;
                        4'd4:  F_osd_char16_row = 16'h03c0;
                        4'd5:  F_osd_char16_row = 16'h03c0;
                        4'd6:  F_osd_char16_row = 16'h03c0;
                        4'd7:  F_osd_char16_row = 16'h03c0;
                        4'd8:  F_osd_char16_row = 16'h03c0;
                        4'd9:  F_osd_char16_row = 16'h03c0;
                        4'd10: F_osd_char16_row = 16'h03c0;
                        4'd11: F_osd_char16_row = 16'h03c0;
                        4'd12: F_osd_char16_row = 16'h03c0;
                        default: F_osd_char16_row = 16'h0000;
                    endcase
                end
                CHAR_COLON: begin
                    case(I_row)
                        4'd6:  F_osd_char16_row = 16'h0180;
                        4'd7:  F_osd_char16_row = 16'h0180;
                        4'd10: F_osd_char16_row = 16'h0180;
                        4'd11: F_osd_char16_row = 16'h0180;
                        default: F_osd_char16_row = 16'h0000;
                    endcase
                end
                default: F_osd_char16_row = 16'h0000;
            endcase
        end
    endfunction

    assign O_video_rd_en = I_video_de;

    anlogic_logo_rom u_anlogic_logo_rom(
        .I_addr  ( S_logo_addr  ),
        .O_pixel ( S_logo_pixel )
    );

    osd_char_lib u_osd_char_lib(
        .I_char     ( S_pf_char     ),
        .I_row      ( S_pf_row      ),
        .O_row_bits ( S_pf_row_bits )
    );

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_x <= 12'd0;
            S_y <= 12'd0;
        end
        else if(I_video_user) begin
            // uivtc presents USER with the first active pixel. The current
            // pixel is (0,0); these counters describe the following pixel.
            S_x <= (I_video_de && !I_video_last) ? 12'd1 : 12'd0;
            S_y <= (I_video_de && I_video_last) ? 12'd1 : 12'd0;
        end
        else if(I_video_de) begin
            if(I_video_last) begin
                S_x <= 12'd0;
                S_y <= S_y + 12'd1;
            end
            else begin
                S_x <= S_x + 12'd1;
            end
        end
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_frame_cnt <= 32'd0;
            S_cnt_d0 <= 4'd0;
            S_cnt_d1 <= 4'd0;
            S_cnt_d2 <= 4'd0;
            S_cnt_d3 <= 4'd0;
            S_cnt_d4 <= 4'd0;
            S_cnt_d5 <= 4'd0;
        end
        else if(I_video_user) begin
            S_frame_cnt <= S_frame_cnt + 32'd1;
            if(S_cnt_d0 == 4'd9) begin
                S_cnt_d0 <= 4'd0;
                if(S_cnt_d1 == 4'd9) begin
                    S_cnt_d1 <= 4'd0;
                    if(S_cnt_d2 == 4'd9) begin
                        S_cnt_d2 <= 4'd0;
                        if(S_cnt_d3 == 4'd9) begin
                            S_cnt_d3 <= 4'd0;
                            if(S_cnt_d4 == 4'd9) begin
                                S_cnt_d4 <= 4'd0;
                                if(S_cnt_d5 == 4'd9)
                                    S_cnt_d5 <= 4'd0;
                                else
                                    S_cnt_d5 <= S_cnt_d5 + 4'd1;
                            end
                            else
                                S_cnt_d4 <= S_cnt_d4 + 4'd1;
                        end
                        else
                            S_cnt_d3 <= S_cnt_d3 + 4'd1;
                    end
                    else
                        S_cnt_d2 <= S_cnt_d2 + 4'd1;
                end
                else
                    S_cnt_d1 <= S_cnt_d1 + 4'd1;
            end
            else
                S_cnt_d0 <= S_cnt_d0 + 4'd1;
        end
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_x_1d <= 12'd0;
            S_x_2d <= 12'd0;
            S_y_1d <= 12'd0;
            S_y_2d <= 12'd0;
        end
        else begin
            S_x_1d <= I_video_user ? 12'd0 : S_x;
            S_x_2d <= S_x_1d;
            S_y_1d <= I_video_user ? 12'd0 : S_y;
            S_y_2d <= S_y_1d;
        end
    end

    // V21.18: use the existing E0/E1/E2 video latency for OSD too.
    // E0 captures coordinate decoding and addresses; E1 captures ROM/font
    // pixels; E2 combines the registered OSD with the unchanged video path.
    // No extra output clock, DSP, or frame/line buffer is introduced.
    wire [11:0] osd_x_now = I_video_user ? 12'd0 : S_x;
    wire [11:0] osd_y_now = I_video_user ? 12'd0 : S_y;
    wire [11:0] osd_dx = osd_x_now - DYN_OSD_X;
    wire [11:0] osd_dy = osd_y_now - DYN_OSD_Y;
    wire [11:0] logo_x_now = osd_x_now - LOGO_X;
    wire [11:0] logo_y_now = osd_y_now - LOGO_Y;
    wire [14:0] logo_addr_now = ({3'd0,logo_y_now} << 7) +
                                ({3'd0,logo_y_now} << 5) + {3'd0,logo_x_now};
    wire logo_valid_now = I_video_de &&
        osd_x_now >= LOGO_X && osd_x_now < LOGO_X+LOGO_W &&
        osd_y_now >= LOGO_Y && osd_y_now < LOGO_Y+LOGO_H;
    wire text_region_now = I_video_de &&
        osd_x_now >= DYN_OSD_X && osd_x_now < DYN_OSD_X+DYN_OSD_W &&
        osd_y_now >= DYN_OSD_Y && osd_y_now < DYN_OSD_Y+DYN_OSD_H;
    reg logo_valid_a, text_valid_a;
    reg text_valid_now;
    reg [7:0] font_char_now;
    reg [3:0] font_row_now, font_col_now;
    reg [4:0] local_x_now, local_y_now;
    reg [3:0] decimal_now;

    // Logo and dynamic text occupy disjoint rectangles. Decode them in
    // parallel so text validity never traverses the large logo ROM.
    always @* begin
        text_valid_now = 1'b0;
        font_char_now = 8'd0;
        font_row_now = 4'd0;
        font_col_now = 4'd0;
        local_x_now = 5'd0;
        local_y_now = 5'd0;
        decimal_now = 4'd0;
        if(text_region_now) begin
            if(osd_dx < 12'd48 && osd_dy >= CN_Y_OFFSET) begin
                font_char_now = osd_dx < 12'd24 ? CHAR_AN : CHAR_LU;
                local_x_now = osd_dx < 12'd24 ? osd_dx[4:0] : osd_dx-12'd24;
                local_y_now = osd_dy-CN_Y_OFFSET;
                font_col_now = scale_24_to_16(local_x_now);
                font_row_now = scale_24_to_16(local_y_now);
                text_valid_now = local_x_now < 5'd24 && local_y_now < 5'd24;
            end else if(osd_dx >= 12'd52 && osd_dx < 12'd108 &&
                        osd_dy >= 12'd4 && osd_dy < 12'd20) begin
                if(osd_dx < 12'd68) begin
                    font_char_now = CHAR_C; local_x_now = osd_dx-12'd52;
                end else if(osd_dx < 12'd84) begin
                    font_char_now = CHAR_N; local_x_now = osd_dx-12'd68;
                end else if(osd_dx < 12'd100) begin
                    font_char_now = CHAR_T; local_x_now = osd_dx-12'd84;
                end else begin
                    font_char_now = CHAR_COLON; local_x_now = osd_dx-12'd100;
                end
                local_y_now = osd_dy-12'd4;
                font_col_now = font_char_now==CHAR_COLON ?
                               {local_x_now[2:0],1'b0} : local_x_now[3:0];
                font_row_now = local_y_now[3:0];
                text_valid_now = 1'b1;
            end else if(osd_dx >= 12'd110 && osd_dx < 12'd200) begin
                if(osd_dx < 12'd125) begin local_x_now=osd_dx-12'd110;decimal_now=S_cnt_d5;end
                else if(osd_dx < 12'd140) begin local_x_now=osd_dx-12'd125;decimal_now=S_cnt_d4;end
                else if(osd_dx < 12'd155) begin local_x_now=osd_dx-12'd140;decimal_now=S_cnt_d3;end
                else if(osd_dx < 12'd170) begin local_x_now=osd_dx-12'd155;decimal_now=S_cnt_d2;end
                else if(osd_dx < 12'd185) begin local_x_now=osd_dx-12'd170;decimal_now=S_cnt_d1;end
                else begin local_x_now=osd_dx-12'd185;decimal_now=S_cnt_d0;end
                font_char_now = CHAR_0+{4'd0,decimal_now};
                font_col_now = local_x_now[3:0];
                font_row_now = scale_24_to_16(osd_dy[4:0]);
                text_valid_now = local_x_now < 5'd15;
            end
        end
    end
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_logo_addr <= 15'd0;
            logo_valid_a <= 1'b0; text_valid_a <= 1'b0;
            S_pf_char <= 8'd0; S_pf_row <= 4'd0; S_pf_col <= 4'd0;
            S_osd_hit <= 1'b0; S_osd_color <= 24'd0;
        end else begin
            S_logo_addr <= logo_addr_now;
            logo_valid_a <= logo_valid_now;
            text_valid_a <= text_valid_now;
            S_pf_char <= font_char_now;
            S_pf_row <= font_row_now;
            S_pf_col <= font_col_now;
            if(logo_valid_a && S_logo_pixel[24]) begin
                S_osd_hit <= 1'b1;
                S_osd_color <= S_logo_pixel[23:0];
            end else if(text_valid_a && S_pf_row_bits[4'd15-S_pf_col]) begin
                S_osd_hit <= 1'b1;
                S_osd_color <= COLOR_DYN_TEXT;
            end else begin
                S_osd_hit <= 1'b0;
                S_osd_color <= 24'd0;
            end
        end
    end

    // The effect is committed at the same first-DE as the brightness policy.
    // Its tag reaches the art renderer before the matching three-stage pixels.
    reg [1:0] filter_mode_meta,filter_mode_sync;
    reg filter_pending;
    always @(posedge I_clk or negedge I_rst_n)begin
        if(!I_rst_n)begin filter_mode_meta<=0;filter_mode_sync<=0;filter_pending<=1;O_frame_effect<=0;end
        else begin
            filter_mode_meta<=I_frame_mode_async;filter_mode_sync<=filter_mode_meta;
            if(I_video_vsync)filter_pending<=1;
            else if(I_video_de && filter_pending)begin
                filter_pending<=0;
                O_frame_effect<=(FILTER_DEMO_ENABLE && filter_mode_sync==0 && !I_night_active && I_art_selection<=4) ? I_art_selection:3'd0;
            end
        end
    end
    wire filter_window=((O_frame_effect==3) || (O_frame_effect==4)) && !I_night_active;

    wire tone_enabled;
    wire dn_color_enabled;
    generate if(DEMO_CONTROLS != 0) begin : g_demo_controls
        demo_switch_control #(
            .DEBOUNCE_CYCLES(CTRL_DEBOUNCE_CYCLES),
            .ENHANCE_TONE_DEFAULT(ENHANCE_TONE_DEFAULT)
        ) u_controls (
            .clk(I_clk), .rst_n(I_rst_n),
            .tone_sw(I_tone_sw),
            .frame_mode_async(I_frame_mode_async),
            .vs(I_video_vsync), .de(I_video_de),
            .tone_selected(O_tone_selected),
            .tone_active(tone_enabled)
        );
        // Match demo_switch_control's buffered-mode synchronization and
        // first-DE boundary. Denoise applies to colour/detection frames
        // independently of SW4; SW4 continues to select brightness only.
        reg [1:0] dn_mode_meta, dn_mode_sync;
        reg dn_frame_pending, dn_frame_color;
        always @(posedge I_clk or negedge I_rst_n) begin
            if(!I_rst_n) begin
                dn_mode_meta <= 2'd0;
                dn_mode_sync <= 2'd0;
                dn_frame_pending <= 1'b1;
                dn_frame_color <= 1'b0;
            end else begin
                dn_mode_meta <= I_frame_mode_async;
                dn_mode_sync <= dn_mode_meta;
                if(I_video_vsync)
                    dn_frame_pending <= 1'b1;
                else if(I_video_de && dn_frame_pending) begin
                    dn_frame_pending <= 1'b0;
                    dn_frame_color <= (dn_mode_sync[1] == dn_mode_sync[0]);
                end
            end
        end
        assign dn_color_enabled = dn_frame_color;
    end else begin : g_legacy_controls
        reg tone_meta, tone_sync, legacy_tone_enabled;
        always @(posedge I_clk or negedge I_rst_n) begin
            if(!I_rst_n) begin tone_meta<=0; tone_sync<=0; legacy_tone_enabled<=0; end
            else begin
                tone_meta<=I_color_view; tone_sync<=tone_meta;
                if(I_video_vsync) legacy_tone_enabled<=tone_sync;
            end
        end
        assign tone_enabled=legacy_tone_enabled;
        assign O_tone_selected=legacy_tone_enabled;
        assign dn_color_enabled=legacy_tone_enabled;
    end endgenerate
    assign O_tone_active=tone_enabled;
    // Exact floor(local_coordinate * 16 / 24), truncated to the original
    // four-bit result. Small coordinate domain maps directly into LUTs.
    function [3:0] scale_24_to_16;
        input [4:0] coordinate;
        begin
            case(coordinate)
                5'd0: scale_24_to_16 = 4'd0;
                5'd1: scale_24_to_16 = 4'd0;
                5'd2: scale_24_to_16 = 4'd1;
                5'd3: scale_24_to_16 = 4'd2;
                5'd4: scale_24_to_16 = 4'd2;
                5'd5: scale_24_to_16 = 4'd3;
                5'd6: scale_24_to_16 = 4'd4;
                5'd7: scale_24_to_16 = 4'd4;
                5'd8: scale_24_to_16 = 4'd5;
                5'd9: scale_24_to_16 = 4'd6;
                5'd10: scale_24_to_16 = 4'd6;
                5'd11: scale_24_to_16 = 4'd7;
                5'd12: scale_24_to_16 = 4'd8;
                5'd13: scale_24_to_16 = 4'd8;
                5'd14: scale_24_to_16 = 4'd9;
                5'd15: scale_24_to_16 = 4'd10;
                5'd16: scale_24_to_16 = 4'd10;
                5'd17: scale_24_to_16 = 4'd11;
                5'd18: scale_24_to_16 = 4'd12;
                5'd19: scale_24_to_16 = 4'd12;
                5'd20: scale_24_to_16 = 4'd13;
                5'd21: scale_24_to_16 = 4'd14;
                5'd22: scale_24_to_16 = 4'd14;
                5'd23: scale_24_to_16 = 4'd15;
                5'd24: scale_24_to_16 = 4'd0;
                5'd25: scale_24_to_16 = 4'd0;
                5'd26: scale_24_to_16 = 4'd1;
                5'd27: scale_24_to_16 = 4'd2;
                5'd28: scale_24_to_16 = 4'd2;
                5'd29: scale_24_to_16 = 4'd3;
                5'd30: scale_24_to_16 = 4'd4;
                5'd31: scale_24_to_16 = 4'd4;
                default: scale_24_to_16 = 4'd0;
            endcase
        end
    endfunction

    function [7:0] display_tone;
        input [7:0] v;
        begin
            case(v)
            8'd0: display_tone=8'd0;
            8'd1: display_tone=8'd12;
            8'd2: display_tone=8'd18;
            8'd3: display_tone=8'd22;
            8'd4: display_tone=8'd26;
            8'd5: display_tone=8'd29;
            8'd6: display_tone=8'd32;
            8'd7: display_tone=8'd35;
            8'd8: display_tone=8'd38;
            8'd9: display_tone=8'd41;
            8'd10: display_tone=8'd43;
            8'd11: display_tone=8'd45;
            8'd12: display_tone=8'd47;
            8'd13: display_tone=8'd50;
            8'd14: display_tone=8'd52;
            8'd15: display_tone=8'd54;
            8'd16: display_tone=8'd56;
            8'd17: display_tone=8'd58;
            8'd18: display_tone=8'd59;
            8'd19: display_tone=8'd61;
            8'd20: display_tone=8'd63;
            8'd21: display_tone=8'd65;
            8'd22: display_tone=8'd66;
            8'd23: display_tone=8'd68;
            8'd24: display_tone=8'd70;
            8'd25: display_tone=8'd71;
            8'd26: display_tone=8'd73;
            8'd27: display_tone=8'd74;
            8'd28: display_tone=8'd76;
            8'd29: display_tone=8'd77;
            8'd30: display_tone=8'd79;
            8'd31: display_tone=8'd80;
            8'd32: display_tone=8'd81;
            8'd33: display_tone=8'd83;
            8'd34: display_tone=8'd84;
            8'd35: display_tone=8'd86;
            8'd36: display_tone=8'd87;
            8'd37: display_tone=8'd88;
            8'd38: display_tone=8'd90;
            8'd39: display_tone=8'd91;
            8'd40: display_tone=8'd92;
            8'd41: display_tone=8'd93;
            8'd42: display_tone=8'd95;
            8'd43: display_tone=8'd96;
            8'd44: display_tone=8'd97;
            8'd45: display_tone=8'd98;
            8'd46: display_tone=8'd99;
            8'd47: display_tone=8'd101;
            8'd48: display_tone=8'd102;
            8'd49: display_tone=8'd103;
            8'd50: display_tone=8'd104;
            8'd51: display_tone=8'd105;
            8'd52: display_tone=8'd106;
            8'd53: display_tone=8'd107;
            8'd54: display_tone=8'd109;
            8'd55: display_tone=8'd110;
            8'd56: display_tone=8'd111;
            8'd57: display_tone=8'd112;
            8'd58: display_tone=8'd113;
            8'd59: display_tone=8'd114;
            8'd60: display_tone=8'd115;
            8'd61: display_tone=8'd116;
            8'd62: display_tone=8'd117;
            8'd63: display_tone=8'd118;
            8'd64: display_tone=8'd119;
            8'd65: display_tone=8'd120;
            8'd66: display_tone=8'd121;
            8'd67: display_tone=8'd122;
            8'd68: display_tone=8'd123;
            8'd69: display_tone=8'd124;
            8'd70: display_tone=8'd125;
            8'd71: display_tone=8'd126;
            8'd72: display_tone=8'd127;
            8'd73: display_tone=8'd128;
            8'd74: display_tone=8'd129;
            8'd75: display_tone=8'd130;
            8'd76: display_tone=8'd131;
            8'd77: display_tone=8'd132;
            8'd78: display_tone=8'd133;
            8'd79: display_tone=8'd134;
            8'd80: display_tone=8'd135;
            8'd81: display_tone=8'd136;
            8'd82: display_tone=8'd137;
            8'd83: display_tone=8'd138;
            8'd84: display_tone=8'd138;
            8'd85: display_tone=8'd139;
            8'd86: display_tone=8'd140;
            8'd87: display_tone=8'd141;
            8'd88: display_tone=8'd142;
            8'd89: display_tone=8'd143;
            8'd90: display_tone=8'd144;
            8'd91: display_tone=8'd145;
            8'd92: display_tone=8'd146;
            8'd93: display_tone=8'd146;
            8'd94: display_tone=8'd147;
            8'd95: display_tone=8'd148;
            8'd96: display_tone=8'd149;
            8'd97: display_tone=8'd150;
            8'd98: display_tone=8'd151;
            8'd99: display_tone=8'd152;
            8'd100: display_tone=8'd152;
            8'd101: display_tone=8'd153;
            8'd102: display_tone=8'd154;
            8'd103: display_tone=8'd155;
            8'd104: display_tone=8'd156;
            8'd105: display_tone=8'd157;
            8'd106: display_tone=8'd157;
            8'd107: display_tone=8'd158;
            8'd108: display_tone=8'd159;
            8'd109: display_tone=8'd160;
            8'd110: display_tone=8'd161;
            8'd111: display_tone=8'd161;
            8'd112: display_tone=8'd162;
            8'd113: display_tone=8'd163;
            8'd114: display_tone=8'd164;
            8'd115: display_tone=8'd165;
            8'd116: display_tone=8'd165;
            8'd117: display_tone=8'd166;
            8'd118: display_tone=8'd167;
            8'd119: display_tone=8'd168;
            8'd120: display_tone=8'd168;
            8'd121: display_tone=8'd169;
            8'd122: display_tone=8'd170;
            8'd123: display_tone=8'd171;
            8'd124: display_tone=8'd172;
            8'd125: display_tone=8'd172;
            8'd126: display_tone=8'd173;
            8'd127: display_tone=8'd174;
            8'd128: display_tone=8'd175;
            8'd129: display_tone=8'd175;
            8'd130: display_tone=8'd176;
            8'd131: display_tone=8'd177;
            8'd132: display_tone=8'd178;
            8'd133: display_tone=8'd178;
            8'd134: display_tone=8'd179;
            8'd135: display_tone=8'd180;
            8'd136: display_tone=8'd180;
            8'd137: display_tone=8'd181;
            8'd138: display_tone=8'd182;
            8'd139: display_tone=8'd183;
            8'd140: display_tone=8'd183;
            8'd141: display_tone=8'd184;
            8'd142: display_tone=8'd185;
            8'd143: display_tone=8'd186;
            8'd144: display_tone=8'd186;
            8'd145: display_tone=8'd187;
            8'd146: display_tone=8'd188;
            8'd147: display_tone=8'd188;
            8'd148: display_tone=8'd189;
            8'd149: display_tone=8'd190;
            8'd150: display_tone=8'd190;
            8'd151: display_tone=8'd191;
            8'd152: display_tone=8'd192;
            8'd153: display_tone=8'd193;
            8'd154: display_tone=8'd193;
            8'd155: display_tone=8'd194;
            8'd156: display_tone=8'd195;
            8'd157: display_tone=8'd195;
            8'd158: display_tone=8'd196;
            8'd159: display_tone=8'd197;
            8'd160: display_tone=8'd197;
            8'd161: display_tone=8'd198;
            8'd162: display_tone=8'd199;
            8'd163: display_tone=8'd199;
            8'd164: display_tone=8'd200;
            8'd165: display_tone=8'd201;
            8'd166: display_tone=8'd201;
            8'd167: display_tone=8'd202;
            8'd168: display_tone=8'd203;
            8'd169: display_tone=8'd203;
            8'd170: display_tone=8'd204;
            8'd171: display_tone=8'd205;
            8'd172: display_tone=8'd205;
            8'd173: display_tone=8'd206;
            8'd174: display_tone=8'd207;
            8'd175: display_tone=8'd207;
            8'd176: display_tone=8'd208;
            8'd177: display_tone=8'd209;
            8'd178: display_tone=8'd209;
            8'd179: display_tone=8'd210;
            8'd180: display_tone=8'd211;
            8'd181: display_tone=8'd211;
            8'd182: display_tone=8'd212;
            8'd183: display_tone=8'd212;
            8'd184: display_tone=8'd213;
            8'd185: display_tone=8'd214;
            8'd186: display_tone=8'd214;
            8'd187: display_tone=8'd215;
            8'd188: display_tone=8'd216;
            8'd189: display_tone=8'd216;
            8'd190: display_tone=8'd217;
            8'd191: display_tone=8'd218;
            8'd192: display_tone=8'd218;
            8'd193: display_tone=8'd219;
            8'd194: display_tone=8'd219;
            8'd195: display_tone=8'd220;
            8'd196: display_tone=8'd221;
            8'd197: display_tone=8'd221;
            8'd198: display_tone=8'd222;
            8'd199: display_tone=8'd222;
            8'd200: display_tone=8'd223;
            8'd201: display_tone=8'd224;
            8'd202: display_tone=8'd224;
            8'd203: display_tone=8'd225;
            8'd204: display_tone=8'd226;
            8'd205: display_tone=8'd226;
            8'd206: display_tone=8'd227;
            8'd207: display_tone=8'd227;
            8'd208: display_tone=8'd228;
            8'd209: display_tone=8'd229;
            8'd210: display_tone=8'd229;
            8'd211: display_tone=8'd230;
            8'd212: display_tone=8'd230;
            8'd213: display_tone=8'd231;
            8'd214: display_tone=8'd232;
            8'd215: display_tone=8'd232;
            8'd216: display_tone=8'd233;
            8'd217: display_tone=8'd233;
            8'd218: display_tone=8'd234;
            8'd219: display_tone=8'd235;
            8'd220: display_tone=8'd235;
            8'd221: display_tone=8'd236;
            8'd222: display_tone=8'd236;
            8'd223: display_tone=8'd237;
            8'd224: display_tone=8'd237;
            8'd225: display_tone=8'd238;
            8'd226: display_tone=8'd239;
            8'd227: display_tone=8'd239;
            8'd228: display_tone=8'd240;
            8'd229: display_tone=8'd240;
            8'd230: display_tone=8'd241;
            8'd231: display_tone=8'd242;
            8'd232: display_tone=8'd242;
            8'd233: display_tone=8'd243;
            8'd234: display_tone=8'd243;
            8'd235: display_tone=8'd244;
            8'd236: display_tone=8'd244;
            8'd237: display_tone=8'd245;
            8'd238: display_tone=8'd246;
            8'd239: display_tone=8'd246;
            8'd240: display_tone=8'd247;
            8'd241: display_tone=8'd247;
            8'd242: display_tone=8'd248;
            8'd243: display_tone=8'd248;
            8'd244: display_tone=8'd249;
            8'd245: display_tone=8'd249;
            8'd246: display_tone=8'd250;
            8'd247: display_tone=8'd251;
            8'd248: display_tone=8'd251;
            8'd249: display_tone=8'd252;
            8'd250: display_tone=8'd252;
            8'd251: display_tone=8'd253;
            8'd252: display_tone=8'd253;
            8'd253: display_tone=8'd254;
            8'd254: display_tone=8'd254;
            8'd255: display_tone=8'd255;
            default: display_tone=0;
            endcase
        end
    endfunction
    // V21.20 NATURAL COLOUR BEGIN
    // Exact V19.4 display curve. TD SWUG106 section 4.2.7 defines
    // rom_style="none" as SLICE implementation; 4.2.19 also disables RAM.
    // Keep the named object so these directives bind before ROM inference.
    // Three asynchronous reads feed the unchanged E0 input registers.
    (* rom_style="none", no_ram *) reg [7:0] natural_tone_rom [0:255];
    initial begin
        natural_tone_rom[0]=RESTORE_BASE19 ? 8'd0 : 8'd0;
        natural_tone_rom[1]=RESTORE_BASE19 ? 8'd1 : 8'd1;
        natural_tone_rom[2]=RESTORE_BASE19 ? 8'd2 : 8'd2;
        natural_tone_rom[3]=RESTORE_BASE19 ? 8'd3 : 8'd3;
        natural_tone_rom[4]=RESTORE_BASE19 ? 8'd4 : 8'd4;
        natural_tone_rom[5]=RESTORE_BASE19 ? 8'd6 : 8'd6;
        natural_tone_rom[6]=RESTORE_BASE19 ? 8'd7 : 8'd7;
        natural_tone_rom[7]=RESTORE_BASE19 ? 8'd9 : 8'd9;
        natural_tone_rom[8]=RESTORE_BASE19 ? 8'd10 : 8'd10;
        natural_tone_rom[9]=RESTORE_BASE19 ? 8'd12 : 8'd12;
        natural_tone_rom[10]=RESTORE_BASE19 ? 8'd14 : 8'd14;
        natural_tone_rom[11]=RESTORE_BASE19 ? 8'd16 : 8'd16;
        natural_tone_rom[12]=RESTORE_BASE19 ? 8'd18 : 8'd18;
        natural_tone_rom[13]=RESTORE_BASE19 ? 8'd19 : 8'd19;
        natural_tone_rom[14]=RESTORE_BASE19 ? 8'd21 : 8'd21;
        natural_tone_rom[15]=RESTORE_BASE19 ? 8'd23 : 8'd23;
        natural_tone_rom[16]=RESTORE_BASE19 ? 8'd25 : 8'd25;
        natural_tone_rom[17]=RESTORE_BASE19 ? 8'd27 : 8'd27;
        natural_tone_rom[18]=RESTORE_BASE19 ? 8'd29 : 8'd29;
        natural_tone_rom[19]=RESTORE_BASE19 ? 8'd30 : 8'd31;
        natural_tone_rom[20]=RESTORE_BASE19 ? 8'd32 : 8'd33;
        natural_tone_rom[21]=RESTORE_BASE19 ? 8'd34 : 8'd35;
        natural_tone_rom[22]=RESTORE_BASE19 ? 8'd36 : 8'd37;
        natural_tone_rom[23]=RESTORE_BASE19 ? 8'd38 : 8'd39;
        natural_tone_rom[24]=RESTORE_BASE19 ? 8'd40 : 8'd42;
        natural_tone_rom[25]=RESTORE_BASE19 ? 8'd41 : 8'd44;
        natural_tone_rom[26]=RESTORE_BASE19 ? 8'd43 : 8'd46;
        natural_tone_rom[27]=RESTORE_BASE19 ? 8'd45 : 8'd48;
        natural_tone_rom[28]=RESTORE_BASE19 ? 8'd47 : 8'd50;
        natural_tone_rom[29]=RESTORE_BASE19 ? 8'd49 : 8'd52;
        natural_tone_rom[30]=RESTORE_BASE19 ? 8'd50 : 8'd54;
        natural_tone_rom[31]=RESTORE_BASE19 ? 8'd52 : 8'd56;
        natural_tone_rom[32]=RESTORE_BASE19 ? 8'd54 : 8'd58;
        natural_tone_rom[33]=RESTORE_BASE19 ? 8'd55 : 8'd60;
        natural_tone_rom[34]=RESTORE_BASE19 ? 8'd57 : 8'd62;
        natural_tone_rom[35]=RESTORE_BASE19 ? 8'd58 : 8'd63;
        natural_tone_rom[36]=RESTORE_BASE19 ? 8'd60 : 8'd65;
        natural_tone_rom[37]=RESTORE_BASE19 ? 8'd61 : 8'd67;
        natural_tone_rom[38]=RESTORE_BASE19 ? 8'd63 : 8'd69;
        natural_tone_rom[39]=RESTORE_BASE19 ? 8'd64 : 8'd70;
        natural_tone_rom[40]=RESTORE_BASE19 ? 8'd66 : 8'd72;
        natural_tone_rom[41]=RESTORE_BASE19 ? 8'd67 : 8'd74;
        natural_tone_rom[42]=RESTORE_BASE19 ? 8'd69 : 8'd76;
        natural_tone_rom[43]=RESTORE_BASE19 ? 8'd70 : 8'd77;
        natural_tone_rom[44]=RESTORE_BASE19 ? 8'd72 : 8'd79;
        natural_tone_rom[45]=RESTORE_BASE19 ? 8'd73 : 8'd81;
        natural_tone_rom[46]=RESTORE_BASE19 ? 8'd75 : 8'd83;
        natural_tone_rom[47]=RESTORE_BASE19 ? 8'd76 : 8'd84;
        natural_tone_rom[48]=RESTORE_BASE19 ? 8'd78 : 8'd86;
        natural_tone_rom[49]=RESTORE_BASE19 ? 8'd79 : 8'd88;
        natural_tone_rom[50]=RESTORE_BASE19 ? 8'd80 : 8'd90;
        natural_tone_rom[51]=RESTORE_BASE19 ? 8'd82 : 8'd91;
        natural_tone_rom[52]=RESTORE_BASE19 ? 8'd83 : 8'd93;
        natural_tone_rom[53]=RESTORE_BASE19 ? 8'd85 : 8'd95;
        natural_tone_rom[54]=RESTORE_BASE19 ? 8'd86 : 8'd97;
        natural_tone_rom[55]=RESTORE_BASE19 ? 8'd88 : 8'd98;
        natural_tone_rom[56]=RESTORE_BASE19 ? 8'd89 : 8'd100;
        natural_tone_rom[57]=RESTORE_BASE19 ? 8'd91 : 8'd102;
        natural_tone_rom[58]=RESTORE_BASE19 ? 8'd92 : 8'd104;
        natural_tone_rom[59]=RESTORE_BASE19 ? 8'd94 : 8'd105;
        natural_tone_rom[60]=RESTORE_BASE19 ? 8'd95 : 8'd107;
        natural_tone_rom[61]=RESTORE_BASE19 ? 8'd97 : 8'd109;
        natural_tone_rom[62]=RESTORE_BASE19 ? 8'd98 : 8'd111;
        natural_tone_rom[63]=RESTORE_BASE19 ? 8'd100 : 8'd112;
        natural_tone_rom[64]=RESTORE_BASE19 ? 8'd101 : 8'd114;
        natural_tone_rom[65]=RESTORE_BASE19 ? 8'd102 : 8'd115;
        natural_tone_rom[66]=RESTORE_BASE19 ? 8'd103 : 8'd117;
        natural_tone_rom[67]=RESTORE_BASE19 ? 8'd105 : 8'd118;
        natural_tone_rom[68]=RESTORE_BASE19 ? 8'd106 : 8'd119;
        natural_tone_rom[69]=RESTORE_BASE19 ? 8'd107 : 8'd121;
        natural_tone_rom[70]=RESTORE_BASE19 ? 8'd108 : 8'd122;
        natural_tone_rom[71]=RESTORE_BASE19 ? 8'd109 : 8'd123;
        natural_tone_rom[72]=RESTORE_BASE19 ? 8'd111 : 8'd125;
        natural_tone_rom[73]=RESTORE_BASE19 ? 8'd112 : 8'd126;
        natural_tone_rom[74]=RESTORE_BASE19 ? 8'd113 : 8'd127;
        natural_tone_rom[75]=RESTORE_BASE19 ? 8'd114 : 8'd128;
        natural_tone_rom[76]=RESTORE_BASE19 ? 8'd115 : 8'd130;
        natural_tone_rom[77]=RESTORE_BASE19 ? 8'd116 : 8'd131;
        natural_tone_rom[78]=RESTORE_BASE19 ? 8'd118 : 8'd132;
        natural_tone_rom[79]=RESTORE_BASE19 ? 8'd119 : 8'd134;
        natural_tone_rom[80]=RESTORE_BASE19 ? 8'd120 : 8'd135;
        natural_tone_rom[81]=RESTORE_BASE19 ? 8'd121 : 8'd136;
        natural_tone_rom[82]=RESTORE_BASE19 ? 8'd122 : 8'd138;
        natural_tone_rom[83]=RESTORE_BASE19 ? 8'd124 : 8'd139;
        natural_tone_rom[84]=RESTORE_BASE19 ? 8'd125 : 8'd140;
        natural_tone_rom[85]=RESTORE_BASE19 ? 8'd126 : 8'd142;
        natural_tone_rom[86]=RESTORE_BASE19 ? 8'd127 : 8'd143;
        natural_tone_rom[87]=RESTORE_BASE19 ? 8'd128 : 8'd144;
        natural_tone_rom[88]=RESTORE_BASE19 ? 8'd130 : 8'd146;
        natural_tone_rom[89]=RESTORE_BASE19 ? 8'd131 : 8'd147;
        natural_tone_rom[90]=RESTORE_BASE19 ? 8'd132 : 8'd148;
        natural_tone_rom[91]=RESTORE_BASE19 ? 8'd133 : 8'd149;
        natural_tone_rom[92]=RESTORE_BASE19 ? 8'd134 : 8'd151;
        natural_tone_rom[93]=RESTORE_BASE19 ? 8'd135 : 8'd152;
        natural_tone_rom[94]=RESTORE_BASE19 ? 8'd137 : 8'd153;
        natural_tone_rom[95]=RESTORE_BASE19 ? 8'd138 : 8'd155;
        natural_tone_rom[96]=RESTORE_BASE19 ? 8'd139 : 8'd156;
        natural_tone_rom[97]=RESTORE_BASE19 ? 8'd140 : 8'd157;
        natural_tone_rom[98]=RESTORE_BASE19 ? 8'd141 : 8'd158;
        natural_tone_rom[99]=RESTORE_BASE19 ? 8'd142 : 8'd159;
        natural_tone_rom[100]=RESTORE_BASE19 ? 8'd143 : 8'd160;
        natural_tone_rom[101]=RESTORE_BASE19 ? 8'd144 : 8'd161;
        natural_tone_rom[102]=RESTORE_BASE19 ? 8'd145 : 8'd162;
        natural_tone_rom[103]=RESTORE_BASE19 ? 8'd146 : 8'd163;
        natural_tone_rom[104]=RESTORE_BASE19 ? 8'd148 : 8'd164;
        natural_tone_rom[105]=RESTORE_BASE19 ? 8'd149 : 8'd164;
        natural_tone_rom[106]=RESTORE_BASE19 ? 8'd150 : 8'd165;
        natural_tone_rom[107]=RESTORE_BASE19 ? 8'd151 : 8'd166;
        natural_tone_rom[108]=RESTORE_BASE19 ? 8'd152 : 8'd167;
        natural_tone_rom[109]=RESTORE_BASE19 ? 8'd153 : 8'd168;
        natural_tone_rom[110]=RESTORE_BASE19 ? 8'd154 : 8'd169;
        natural_tone_rom[111]=RESTORE_BASE19 ? 8'd155 : 8'd170;
        natural_tone_rom[112]=RESTORE_BASE19 ? 8'd156 : 8'd171;
        natural_tone_rom[113]=RESTORE_BASE19 ? 8'd157 : 8'd172;
        natural_tone_rom[114]=RESTORE_BASE19 ? 8'd158 : 8'd173;
        natural_tone_rom[115]=RESTORE_BASE19 ? 8'd159 : 8'd174;
        natural_tone_rom[116]=RESTORE_BASE19 ? 8'd160 : 8'd175;
        natural_tone_rom[117]=RESTORE_BASE19 ? 8'd161 : 8'd176;
        natural_tone_rom[118]=RESTORE_BASE19 ? 8'd162 : 8'd177;
        natural_tone_rom[119]=RESTORE_BASE19 ? 8'd163 : 8'd178;
        natural_tone_rom[120]=RESTORE_BASE19 ? 8'd165 : 8'd179;
        natural_tone_rom[121]=RESTORE_BASE19 ? 8'd166 : 8'd179;
        natural_tone_rom[122]=RESTORE_BASE19 ? 8'd167 : 8'd180;
        natural_tone_rom[123]=RESTORE_BASE19 ? 8'd168 : 8'd181;
        natural_tone_rom[124]=RESTORE_BASE19 ? 8'd169 : 8'd182;
        natural_tone_rom[125]=RESTORE_BASE19 ? 8'd170 : 8'd183;
        natural_tone_rom[126]=RESTORE_BASE19 ? 8'd171 : 8'd184;
        natural_tone_rom[127]=RESTORE_BASE19 ? 8'd172 : 8'd185;
        natural_tone_rom[128]=RESTORE_BASE19 ? 8'd173 : 8'd186;
        natural_tone_rom[129]=RESTORE_BASE19 ? 8'd174 : 8'd187;
        natural_tone_rom[130]=RESTORE_BASE19 ? 8'd175 : 8'd188;
        natural_tone_rom[131]=RESTORE_BASE19 ? 8'd176 : 8'd188;
        natural_tone_rom[132]=RESTORE_BASE19 ? 8'd177 : 8'd189;
        natural_tone_rom[133]=RESTORE_BASE19 ? 8'd178 : 8'd190;
        natural_tone_rom[134]=RESTORE_BASE19 ? 8'd178 : 8'd191;
        natural_tone_rom[135]=RESTORE_BASE19 ? 8'd179 : 8'd191;
        natural_tone_rom[136]=RESTORE_BASE19 ? 8'd180 : 8'd192;
        natural_tone_rom[137]=RESTORE_BASE19 ? 8'd181 : 8'd193;
        natural_tone_rom[138]=RESTORE_BASE19 ? 8'd182 : 8'd194;
        natural_tone_rom[139]=RESTORE_BASE19 ? 8'd183 : 8'd194;
        natural_tone_rom[140]=RESTORE_BASE19 ? 8'd184 : 8'd195;
        natural_tone_rom[141]=RESTORE_BASE19 ? 8'd185 : 8'd196;
        natural_tone_rom[142]=RESTORE_BASE19 ? 8'd186 : 8'd197;
        natural_tone_rom[143]=RESTORE_BASE19 ? 8'd187 : 8'd197;
        natural_tone_rom[144]=RESTORE_BASE19 ? 8'd188 : 8'd198;
        natural_tone_rom[145]=RESTORE_BASE19 ? 8'd188 : 8'd199;
        natural_tone_rom[146]=RESTORE_BASE19 ? 8'd189 : 8'd200;
        natural_tone_rom[147]=RESTORE_BASE19 ? 8'd190 : 8'd200;
        natural_tone_rom[148]=RESTORE_BASE19 ? 8'd191 : 8'd201;
        natural_tone_rom[149]=RESTORE_BASE19 ? 8'd192 : 8'd202;
        natural_tone_rom[150]=RESTORE_BASE19 ? 8'd193 : 8'd203;
        natural_tone_rom[151]=RESTORE_BASE19 ? 8'd194 : 8'd203;
        natural_tone_rom[152]=RESTORE_BASE19 ? 8'd195 : 8'd204;
        natural_tone_rom[153]=RESTORE_BASE19 ? 8'd196 : 8'd205;
        natural_tone_rom[154]=RESTORE_BASE19 ? 8'd197 : 8'd206;
        natural_tone_rom[155]=RESTORE_BASE19 ? 8'd197 : 8'd206;
        natural_tone_rom[156]=RESTORE_BASE19 ? 8'd198 : 8'd207;
        natural_tone_rom[157]=RESTORE_BASE19 ? 8'd199 : 8'd208;
        natural_tone_rom[158]=RESTORE_BASE19 ? 8'd200 : 8'd209;
        natural_tone_rom[159]=RESTORE_BASE19 ? 8'd201 : 8'd209;
        natural_tone_rom[160]=RESTORE_BASE19 ? 8'd202 : 8'd210;
        natural_tone_rom[161]=RESTORE_BASE19 ? 8'd203 : 8'd211;
        natural_tone_rom[162]=RESTORE_BASE19 ? 8'd203 : 8'd211;
        natural_tone_rom[163]=RESTORE_BASE19 ? 8'd204 : 8'd212;
        natural_tone_rom[164]=RESTORE_BASE19 ? 8'd205 : 8'd212;
        natural_tone_rom[165]=RESTORE_BASE19 ? 8'd206 : 8'd213;
        natural_tone_rom[166]=RESTORE_BASE19 ? 8'd206 : 8'd214;
        natural_tone_rom[167]=RESTORE_BASE19 ? 8'd207 : 8'd214;
        natural_tone_rom[168]=RESTORE_BASE19 ? 8'd208 : 8'd215;
        natural_tone_rom[169]=RESTORE_BASE19 ? 8'd208 : 8'd215;
        natural_tone_rom[170]=RESTORE_BASE19 ? 8'd209 : 8'd216;
        natural_tone_rom[171]=RESTORE_BASE19 ? 8'd210 : 8'd217;
        natural_tone_rom[172]=RESTORE_BASE19 ? 8'd211 : 8'd217;
        natural_tone_rom[173]=RESTORE_BASE19 ? 8'd211 : 8'd218;
        natural_tone_rom[174]=RESTORE_BASE19 ? 8'd212 : 8'd218;
        natural_tone_rom[175]=RESTORE_BASE19 ? 8'd213 : 8'd219;
        natural_tone_rom[176]=RESTORE_BASE19 ? 8'd214 : 8'd220;
        natural_tone_rom[177]=RESTORE_BASE19 ? 8'd214 : 8'd220;
        natural_tone_rom[178]=RESTORE_BASE19 ? 8'd215 : 8'd221;
        natural_tone_rom[179]=RESTORE_BASE19 ? 8'd216 : 8'd221;
        natural_tone_rom[180]=RESTORE_BASE19 ? 8'd216 : 8'd222;
        natural_tone_rom[181]=RESTORE_BASE19 ? 8'd217 : 8'd222;
        natural_tone_rom[182]=RESTORE_BASE19 ? 8'd218 : 8'd223;
        natural_tone_rom[183]=RESTORE_BASE19 ? 8'd219 : 8'd224;
        natural_tone_rom[184]=RESTORE_BASE19 ? 8'd219 : 8'd224;
        natural_tone_rom[185]=RESTORE_BASE19 ? 8'd220 : 8'd225;
        natural_tone_rom[186]=RESTORE_BASE19 ? 8'd221 : 8'd225;
        natural_tone_rom[187]=RESTORE_BASE19 ? 8'd221 : 8'd226;
        natural_tone_rom[188]=RESTORE_BASE19 ? 8'd222 : 8'd227;
        natural_tone_rom[189]=RESTORE_BASE19 ? 8'd223 : 8'd227;
        natural_tone_rom[190]=RESTORE_BASE19 ? 8'd224 : 8'd228;
        natural_tone_rom[191]=RESTORE_BASE19 ? 8'd224 : 8'd228;
        natural_tone_rom[192]=RESTORE_BASE19 ? 8'd225 : 8'd229;
        natural_tone_rom[193]=RESTORE_BASE19 ? 8'd226 : 8'd229;
        natural_tone_rom[194]=RESTORE_BASE19 ? 8'd226 : 8'd230;
        natural_tone_rom[195]=RESTORE_BASE19 ? 8'd227 : 8'd230;
        natural_tone_rom[196]=RESTORE_BASE19 ? 8'd227 : 8'd231;
        natural_tone_rom[197]=RESTORE_BASE19 ? 8'd228 : 8'd231;
        natural_tone_rom[198]=RESTORE_BASE19 ? 8'd228 : 8'd232;
        natural_tone_rom[199]=RESTORE_BASE19 ? 8'd229 : 8'd232;
        natural_tone_rom[200]=RESTORE_BASE19 ? 8'd230 : 8'd233;
        natural_tone_rom[201]=RESTORE_BASE19 ? 8'd230 : 8'd233;
        natural_tone_rom[202]=RESTORE_BASE19 ? 8'd231 : 8'd234;
        natural_tone_rom[203]=RESTORE_BASE19 ? 8'd231 : 8'd234;
        natural_tone_rom[204]=RESTORE_BASE19 ? 8'd232 : 8'd235;
        natural_tone_rom[205]=RESTORE_BASE19 ? 8'd232 : 8'd235;
        natural_tone_rom[206]=RESTORE_BASE19 ? 8'd233 : 8'd236;
        natural_tone_rom[207]=RESTORE_BASE19 ? 8'd233 : 8'd236;
        natural_tone_rom[208]=RESTORE_BASE19 ? 8'd234 : 8'd237;
        natural_tone_rom[209]=RESTORE_BASE19 ? 8'd235 : 8'd237;
        natural_tone_rom[210]=RESTORE_BASE19 ? 8'd235 : 8'd237;
        natural_tone_rom[211]=RESTORE_BASE19 ? 8'd236 : 8'd238;
        natural_tone_rom[212]=RESTORE_BASE19 ? 8'd236 : 8'd238;
        natural_tone_rom[213]=RESTORE_BASE19 ? 8'd237 : 8'd239;
        natural_tone_rom[214]=RESTORE_BASE19 ? 8'd237 : 8'd239;
        natural_tone_rom[215]=RESTORE_BASE19 ? 8'd238 : 8'd240;
        natural_tone_rom[216]=RESTORE_BASE19 ? 8'd239 : 8'd240;
        natural_tone_rom[217]=RESTORE_BASE19 ? 8'd239 : 8'd241;
        natural_tone_rom[218]=RESTORE_BASE19 ? 8'd240 : 8'd241;
        natural_tone_rom[219]=RESTORE_BASE19 ? 8'd240 : 8'd242;
        natural_tone_rom[220]=RESTORE_BASE19 ? 8'd241 : 8'd242;
        natural_tone_rom[221]=RESTORE_BASE19 ? 8'd241 : 8'd243;
        natural_tone_rom[222]=RESTORE_BASE19 ? 8'd242 : 8'd243;
        natural_tone_rom[223]=RESTORE_BASE19 ? 8'd242 : 8'd244;
        natural_tone_rom[224]=RESTORE_BASE19 ? 8'd243 : 8'd244;
        natural_tone_rom[225]=RESTORE_BASE19 ? 8'd243 : 8'd244;
        natural_tone_rom[226]=RESTORE_BASE19 ? 8'd244 : 8'd245;
        natural_tone_rom[227]=RESTORE_BASE19 ? 8'd244 : 8'd245;
        natural_tone_rom[228]=RESTORE_BASE19 ? 8'd245 : 8'd245;
        natural_tone_rom[229]=RESTORE_BASE19 ? 8'd245 : 8'd246;
        natural_tone_rom[230]=RESTORE_BASE19 ? 8'd245 : 8'd246;
        natural_tone_rom[231]=RESTORE_BASE19 ? 8'd246 : 8'd246;
        natural_tone_rom[232]=RESTORE_BASE19 ? 8'd246 : 8'd247;
        natural_tone_rom[233]=RESTORE_BASE19 ? 8'd246 : 8'd247;
        natural_tone_rom[234]=RESTORE_BASE19 ? 8'd247 : 8'd248;
        natural_tone_rom[235]=RESTORE_BASE19 ? 8'd247 : 8'd248;
        natural_tone_rom[236]=RESTORE_BASE19 ? 8'd248 : 8'd248;
        natural_tone_rom[237]=RESTORE_BASE19 ? 8'd248 : 8'd249;
        natural_tone_rom[238]=RESTORE_BASE19 ? 8'd248 : 8'd249;
        natural_tone_rom[239]=RESTORE_BASE19 ? 8'd249 : 8'd249;
        natural_tone_rom[240]=RESTORE_BASE19 ? 8'd249 : 8'd250;
        natural_tone_rom[241]=RESTORE_BASE19 ? 8'd250 : 8'd250;
        natural_tone_rom[242]=RESTORE_BASE19 ? 8'd250 : 8'd250;
        natural_tone_rom[243]=RESTORE_BASE19 ? 8'd250 : 8'd251;
        natural_tone_rom[244]=RESTORE_BASE19 ? 8'd251 : 8'd251;
        natural_tone_rom[245]=RESTORE_BASE19 ? 8'd251 : 8'd251;
        natural_tone_rom[246]=RESTORE_BASE19 ? 8'd252 : 8'd252;
        natural_tone_rom[247]=RESTORE_BASE19 ? 8'd252 : 8'd252;
        natural_tone_rom[248]=RESTORE_BASE19 ? 8'd252 : 8'd253;
        natural_tone_rom[249]=RESTORE_BASE19 ? 8'd253 : 8'd253;
        natural_tone_rom[250]=RESTORE_BASE19 ? 8'd253 : 8'd253;
        natural_tone_rom[251]=RESTORE_BASE19 ? 8'd253 : 8'd254;
        natural_tone_rom[252]=RESTORE_BASE19 ? 8'd254 : 8'd254;
        natural_tone_rom[253]=RESTORE_BASE19 ? 8'd254 : 8'd254;
        natural_tone_rom[254]=RESTORE_BASE19 ? 8'd255 : 8'd255;
        natural_tone_rom[255]=RESTORE_BASE19 ? 8'd255 : 8'd255;
    end

    function [7:0] natural_warm_red;
        input [7:0] c;
        reg [2:0] step;
        begin
            step = c[7] ? ~c[6:4] : c[6:4];
            natural_warm_red = c + {5'b00000,step};
        end
    endfunction

    function [7:0] natural_warm_blue;
        input [7:0] c;
        reg [2:0] step;
        begin
            step = c[7] ? ~c[6:4] : c[6:4];
            natural_warm_blue = c - {5'b00000,step};
        end
    endfunction

    function [7:0] natural_clip;
        input signed [10:0] v;
        begin
            if (v < 0) natural_clip = 8'd0;
            else if (v > 11'sd255) natural_clip = 8'd255;
            else natural_clip = v[7:0];
        end
    endfunction

    function [7:0] natural_chroma;
        input [7:0] c;
        input signed [10:0] y;
        input signed [10:0] budget;
        reg signed [10:0] delta, magnitude, pull, adjusted;
        begin
            delta = $signed({3'b000,c}) - y;
            magnitude = (delta < 0) ? -delta : delta;
            pull = (magnitude >>> 1);
            if (pull > budget) pull = budget;
            adjusted = $signed({3'b000,c}) + (delta >>> 2);
            if (delta < 0) adjusted = adjusted + pull;
            else adjusted = adjusted - pull;
            natural_chroma = natural_clip(adjusted);
        end
    endfunction

    // E0: the LUT, luminance and shadow-chroma budget describe one input pixel.
    wire [23:0] natural_base_now={natural_tone_rom[I_video_rd_data[23:16]],
                                  natural_tone_rom[I_video_rd_data[15:8]],
                                  natural_tone_rom[I_video_rd_data[7:0]]};
    wire [9:0] natural_y_sum_now={2'b00,natural_base_now[23:16]} +
                                ({2'b00,natural_base_now[15:8]} << 1) +
                                {2'b00,natural_base_now[7:0]} + 10'd2;
    wire [7:0] natural_y_now=natural_y_sum_now[9:2];
    wire [4:0] natural_budget_now=RESTORE_BASE19 ? 5'd0 : (natural_y_now < 8'd96) ?
                                  ((8'd96-natural_y_now) >> 2) : 5'd0;
    reg [23:0] natural_base_1d,natural_chroma_2d;
    reg [7:0] natural_y_1d;
    reg [4:0] natural_budget_1d;
    // E1 holds chroma; the short warm trim feeds the existing E2 denoise.
    wire [23:0] natural_rgb_2d=RESTORE_BASE19 ? natural_chroma_2d : {natural_warm_red(natural_chroma_2d[23:16]),
                               natural_chroma_2d[15:8],
                               natural_warm_blue(natural_chroma_2d[7:0])};
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            natural_base_1d<=0;natural_y_1d<=0;natural_budget_1d<=0;
            natural_chroma_2d<=0;
        end else begin
            natural_base_1d<=natural_base_now;
            natural_y_1d<=natural_y_now;
            natural_budget_1d<=natural_budget_now;
            natural_chroma_2d<={
                natural_chroma(natural_base_1d[23:16],$signed({3'b000,natural_y_1d}),$signed({6'b000000,natural_budget_1d})),
                natural_chroma(natural_base_1d[15:8],$signed({3'b000,natural_y_1d}),$signed({6'b000000,natural_budget_1d})),
                natural_chroma(natural_base_1d[7:0],$signed({3'b000,natural_y_1d}),$signed({6'b000000,natural_budget_1d}))};
        end
    end
    // V21.20 NATURAL COLOUR END

    // Evaluate the unchanged brightness LUT beside the existing second
    // input register, leaving the final cycle for neighbour selection/blend.
    // Retain this register across reset just like S_video_data_2d; the video
    // outputs and control enables retain their original reset behaviour.
    reg [23:0] tone_rgb_2d;
    wire [23:0] tone_rgb = tone_rgb_2d;
    // K3 night processing consumes raw pixels before its common-gain curve.
    // In demo controls, tone_enabled already includes the same first-DE
    // mode0/3 SW4 qualification plus optional mode2 default. Select directly
    // so synthesis can remove the unreachable legacy LUT in that parameter.
    // DEMO_CONTROLS=0 retains its original brightness LUT and control.
    // SW4-off/night and raw O_scene_data keep their original sources.
    wire [23:0] selected_tone_rgb = (DEMO_CONTROLS != 0) ? natural_rgb_2d : tone_rgb;
    wire [23:0] dn_base_rgb = I_night_active ? S_video_data_2d :
                            (tone_enabled ? selected_tone_rgb : S_video_data_2d);

    // V21.4 display-only, non-recursive spatial denoise. The line store
    // contains original selected display pixels, never the blended output.
    // Each neighbour contributes only if all RGB differences are <=16.
    // Centre weight 5/8 limits the change to 6 codes per channel.
    function dn_close_channel;
        input [7:0] a,b;
        reg signed [8:0] delta;
        begin
            delta = $signed({1'b0,a}) - $signed({1'b0,b});
            dn_close_channel = (delta >= -9'sd16) && (delta <= 9'sd16);
        end
    endfunction
    function dn_close_rgb;
        input [23:0] a,b;
        begin
            dn_close_rgb = dn_close_channel(a[23:16],b[23:16]) &&
                           dn_close_channel(a[15:8],b[15:8]) &&
                           dn_close_channel(a[7:0],b[7:0]);
        end
    endfunction
    function [7:0] dn_blend;
        input [7:0] c,l,u,ul;
        reg [10:0] sum;
        begin
            sum = ({3'b000,c} << 2) + {3'b000,c} + {3'b000,l} +
                  {3'b000,u} + {3'b000,ul} + 11'd4;
            dn_blend = sum[10:3];
        end
    endfunction
    reg [23:0] dn_line [0:IMG_WIDTH-1];
    reg [23:0] dn_upper, dn_upper_left, dn_left;
    // Synchronous RAM prefetch is one input-pipeline cycle ahead of use.
    // Do not reset the array: first-row/column masks exclude stale contents.
    always @(posedge I_clk) begin
        if(I_rst_n && S_video_de_1d && (S_x_1d < IMG_WIDTH))
            dn_upper <= dn_line[S_x_1d];
        if(I_rst_n && S_video_de_2d && (S_x_2d < IMG_WIDTH))
            dn_line[S_x_2d] <= dn_base_rgb;
    end
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            dn_left <= 24'd0;
            dn_upper_left <= 24'd0;
        end else if(S_video_de_2d) begin
            dn_left <= dn_base_rgb;
            dn_upper_left <= dn_upper;
        end
    end
    wire dn_valid = S_video_de_2d && (S_x_2d < IMG_WIDTH) && (S_y_2d < IMG_HEIGHT);
    wire dn_use_l = dn_valid && (S_x_2d != 0) && dn_close_rgb(dn_base_rgb,dn_left);
    wire dn_use_u = dn_valid && (S_y_2d != 0) && dn_close_rgb(dn_base_rgb,dn_upper);
    wire dn_use_ul = dn_valid && (S_x_2d != 0) && (S_y_2d != 0) && dn_close_rgb(dn_base_rgb,dn_upper_left);
    wire [23:0] dn_l = dn_use_l ? dn_left : dn_base_rgb;
    wire [23:0] dn_u = dn_use_u ? dn_upper : dn_base_rgb;
    wire [23:0] dn_ul = dn_use_ul ? dn_upper_left : dn_base_rgb;
    wire [23:0] denoised_rgb = {
        dn_blend(dn_base_rgb[23:16],dn_l[23:16],dn_u[23:16],dn_ul[23:16]),
        dn_blend(dn_base_rgb[15:8],dn_l[15:8],dn_u[15:8],dn_ul[15:8]),
        dn_blend(dn_base_rgb[7:0],dn_l[7:0],dn_u[7:0],dn_ul[7:0])};

    // V21.17 NIGHT DENOISE BEGIN
    // Causal 3x3 RGB range-filtered binomial; no temporal history. Current
    // pixel is the range anchor. Invalid or >6-code RGB-difference taps are
    // replaced by current. Weights [1 2 1;2 4 2;1 2 1] total sixteen, and
    // the integer weighted sum is retained as Q4 (no 8-bit rounding).
    // In a flat region the spatial weight centroid is one pixel up/left.
    // Reuse dn_line/dn_upper as the first unfiltered selected-RGB row.
    // This additional row stores old dn_upper, NEVER a filtered result.
    reg [23:0] night_line2 [0:IMG_WIDTH-1];
    reg [23:0] night_upper2;
    reg [23:0] night_left2,night_upper_left2;
    reg [23:0] night_far_left,night_far_left2;
    always @(posedge I_clk) begin
        // Prefetch precedes the overwrite by one pipeline stage, so old-row
        // readback does not depend on same-address read-during-write mode.
        if(I_rst_n && S_video_de_1d && S_x_1d<IMG_WIDTH)
            night_upper2 <= night_line2[S_x_1d];
        if(I_rst_n && S_video_de_2d && S_x_2d<IMG_WIDTH)
            night_line2[S_x_2d] <= dn_upper;
    end
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            night_left2<=0;night_upper_left2<=0;
            night_far_left<=0;night_far_left2<=0;
        end else if(S_video_de_2d) begin
            night_left2<=dn_left;night_upper_left2<=dn_upper_left;
            night_far_left<=night_upper2;night_far_left2<=night_far_left;
        end
    end
    function night_close_channel;
        input [7:0] a,b;
        reg signed [8:0] delta;
        begin
            delta=$signed({1'b0,a})-$signed({1'b0,b});
            night_close_channel=(delta>=-9'sd6 && delta<=9'sd6);
        end
    endfunction
    function night_close_rgb;
        input [23:0] a,b;
        begin
            night_close_rgb=night_close_channel(a[23:16],b[23:16]) &&
                            night_close_channel(a[15:8],b[15:8]) &&
                            night_close_channel(a[7:0],b[7:0]);
        end
    endfunction
    function [9:0] night_row_sum;
        input [7:0] a,b,c;
        begin night_row_sum={2'b00,a}+{1'b0,b,1'b0}+{2'b00,c};end
    endfunction
    // Causal 3x3 RGB window shared with the existing night line stores.
    // Clamp missing top/left samples; old night range filtering is unchanged.
    wire [23:0] filter_p22=dn_base_rgb;
    wire [23:0] filter_p21=S_x_2d>=1 ? dn_left:dn_base_rgb;
    wire [23:0] filter_p20=S_x_2d>=2 ? night_left2:filter_p21;
    wire [23:0] filter_p12=S_y_2d>=1 ? dn_upper:dn_base_rgb;
    wire [23:0] filter_p11=S_y_2d>=1 ? (S_x_2d>=1 ? dn_upper_left:dn_upper):filter_p21;
    wire [23:0] filter_p10=S_y_2d>=1 ? (S_x_2d>=2 ? night_upper_left2:filter_p11):filter_p20;
    wire [23:0] filter_p02=S_y_2d>=2 ? night_upper2:filter_p12;
    wire [23:0] filter_p01=S_y_2d>=2 ? (S_x_2d>=1 ? night_far_left:night_upper2):filter_p11;
    wire [23:0] filter_p00=S_y_2d>=2 ? (S_x_2d>=2 ? night_far_left2:filter_p01):filter_p10;
    wire [11:0] gaussian_r=O_night_source_q4[35:24]+12'd8;
    wire [11:0] gaussian_g=O_night_source_q4[23:12]+12'd8;
    wire [11:0] gaussian_b=O_night_source_q4[11:0]+12'd8;
    assign O_gaussian_rgb={gaussian_r[11:4],gaussian_g[11:4],gaussian_b[11:4]};

    // V21.39: 3x detail-gain unsharp masking with a +/-4-code noise deadband.
    // Match the CENTER of the same causal Gaussian window, not p22. Both
    // outputs therefore use center (max(x-1,0), max(y-1,0)); no extra row RAM
    // or pixel stage is needed. O_scene_data remains the original raster.
    reg [23:0] sharpen_center_b,sharpen_center_c;
    function [7:0] sharpen_channel;
        input [7:0] center,blur;
        reg signed [8:0] detail;
        reg signed [10:0] enhanced;
        begin
            detail=$signed({1'b0,center})-$signed({1'b0,blur});
            // center + 3*(center-blur) = 4*center - 3*blur.
            // Signed 11 bits cover [-765,1020]; shifts/adds need no DSP.
            enhanced=$signed({1'b0,center,2'b00})-
                     ($signed({3'b000,blur})+$signed({2'b00,blur,1'b0}));
            if(detail>=-9'sd4 && detail<=9'sd4)sharpen_channel=center;
            else if(enhanced<0)sharpen_channel=8'd0;
            else if(enhanced>11'sd255)sharpen_channel=8'd255;
            else sharpen_channel=enhanced[7:0];
        end
    endfunction
    assign O_sharpen_rgb={
        sharpen_channel(sharpen_center_c[23:16],O_gaussian_rgb[23:16]),
        sharpen_channel(sharpen_center_c[15:8],O_gaussian_rgb[15:8]),
        sharpen_channel(sharpen_center_c[7:0],O_gaussian_rgb[7:0])};

    reg [23:0] night_p00,night_p01,night_p02;
    reg [23:0] night_p10,night_p11,night_p12;
    reg [23:0] night_p20,night_p21,night_p22;
    reg [9:0] night_r0,night_r1,night_r2;
    reg [9:0] night_g0,night_g1,night_g2;
    reg [9:0] night_b0,night_b1,night_b2;
    reg [1:0] night_de_pipe,night_vs_pipe;
    wire [11:0] night_sum_r={2'd0,night_r0}+{1'b0,night_r1,1'b0}+{2'd0,night_r2};
    wire [11:0] night_sum_g={2'd0,night_g0}+{1'b0,night_g1,1'b0}+{2'd0,night_g2};
    wire [11:0] night_sum_b={2'd0,night_b0}+{1'b0,night_b1,1'b0}+{2'd0,night_b2};
    always @(posedge I_clk) begin
        // Stage A: validate/select all taps. Masks also exclude stale RAM
        // on the first two rows and horizontal history on first columns.
        night_p00 <= filter_window ? filter_p00 : (S_x_2d>=2 && S_y_2d>=2 && night_close_rgb(dn_base_rgb,night_far_left2) ? night_far_left2:dn_base_rgb);
        night_p01 <= filter_window ? filter_p01 : (S_x_2d>=1 && S_y_2d>=2 && night_close_rgb(dn_base_rgb,night_far_left) ? night_far_left:dn_base_rgb);
        night_p02 <= filter_window ? filter_p02 : (S_y_2d>=2 && night_close_rgb(dn_base_rgb,night_upper2) ? night_upper2:dn_base_rgb);
        night_p10 <= filter_window ? filter_p10 : (S_x_2d>=2 && S_y_2d>=1 && night_close_rgb(dn_base_rgb,night_upper_left2) ? night_upper_left2:dn_base_rgb);
        night_p11 <= filter_window ? filter_p11 : (S_x_2d>=1 && S_y_2d>=1 && night_close_rgb(dn_base_rgb,dn_upper_left) ? dn_upper_left:dn_base_rgb);
        night_p12 <= filter_window ? filter_p12 : (S_y_2d>=1 && night_close_rgb(dn_base_rgb,dn_upper) ? dn_upper:dn_base_rgb);
        night_p20 <= filter_window ? filter_p20 : (S_x_2d>=2 && night_close_rgb(dn_base_rgb,night_left2) ? night_left2:dn_base_rgb);
        night_p21 <= filter_window ? filter_p21 : (S_x_2d>=1 && night_close_rgb(dn_base_rgb,dn_left) ? dn_left:dn_base_rgb);
        night_p22 <= filter_window ? filter_p22 : (dn_base_rgb);
        // Stage B: three short horizontal adders per channel.
        sharpen_center_b<=night_p11;
        night_r0<=night_row_sum(night_p00[23:16],night_p01[23:16],night_p02[23:16]);
        night_r1<=night_row_sum(night_p10[23:16],night_p11[23:16],night_p12[23:16]);
        night_r2<=night_row_sum(night_p20[23:16],night_p21[23:16],night_p22[23:16]);
        night_g0<=night_row_sum(night_p00[15:8],night_p01[15:8],night_p02[15:8]);
        night_g1<=night_row_sum(night_p10[15:8],night_p11[15:8],night_p12[15:8]);
        night_g2<=night_row_sum(night_p20[15:8],night_p21[15:8],night_p22[15:8]);
        night_b0<=night_row_sum(night_p00[7:0],night_p01[7:0],night_p02[7:0]);
        night_b1<=night_row_sum(night_p10[7:0],night_p11[7:0],night_p12[7:0]);
        night_b2<=night_row_sum(night_p20[7:0],night_p21[7:0],night_p22[7:0]);
    end
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            night_de_pipe<=0;night_vs_pipe<=0;
            O_night_de<=0;O_night_vs<=0;O_night_source_q4<=0;sharpen_center_c<=0;
        end else begin
            night_de_pipe<={night_de_pipe[0],S_video_de_2d};
            night_vs_pipe<={night_vs_pipe[0],S_video_vsync_2d};
            // Stage C: vertical sum and output valid/sync. Raw I_video E0
            // reaches this output at E4, independently of normal E2 path.
            O_night_de<=night_de_pipe[1];O_night_vs<=night_vs_pipe[1];
            O_night_source_q4<=night_de_pipe[1] ? {night_sum_r,night_sum_g,night_sum_b}:36'd0;
            sharpen_center_c<=night_de_pipe[1] ? sharpen_center_b:24'd0;
        end
    end
    // V21.17 NIGHT DENOISE END

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_video_vsync_1d <= 1'b0;
            S_video_vsync_2d <= 1'b0;
            S_video_hsync_1d <= 1'b0;
            S_video_hsync_2d <= 1'b0;
            S_video_de_1d    <= 1'b0;
            S_video_de_2d    <= 1'b0;
            O_hdmi_vsync     <= 1'b0;
            O_hdmi_hsync     <= 1'b0;
            O_hdmi_de        <= 1'b0;
            O_hdmi_data      <= 24'd0;
            O_scene_data     <= 24'd0;
        end
        else begin
            S_video_vsync_1d <= I_video_vsync;
            S_video_vsync_2d <= S_video_vsync_1d;
            O_hdmi_vsync     <= S_video_vsync_2d;

            S_video_hsync_1d <= I_video_hsync;
            S_video_hsync_2d <= S_video_hsync_1d;
            O_hdmi_hsync     <= S_video_hsync_2d;

            S_video_de_1d    <= I_video_de;
            S_video_de_2d    <= S_video_de_1d;
            O_hdmi_de        <= S_video_de_2d;
            S_video_data_1d  <= I_video_rd_data;
            S_video_data_2d  <= S_video_data_1d;
            if(DEMO_CONTROLS == 0)
                tone_rgb_2d <= {display_tone(S_video_data_1d[23:16]),
                               display_tone(S_video_data_1d[15:8]),
                               display_tone(S_video_data_1d[7:0])};
            else
                tone_rgb_2d <= 24'd0;
            O_scene_data     <= S_video_data_2d;

            if(DEBUG_MODE == 1) begin
                if(S_video_de_2d) begin
                    if(S_x < 12'd128)
                        O_hdmi_data <= 24'hff0000;
                    else if(S_x < 12'd256)
                        O_hdmi_data <= 24'h00ff00;
                    else if(S_x < 12'd384)
                        O_hdmi_data <= 24'h0000ff;
                    else if(S_x < 12'd512)
                        O_hdmi_data <= 24'hffff00;
                    else if(S_x < 12'd640)
                        O_hdmi_data <= 24'h00ffff;
                    else if(S_x < 12'd768)
                        O_hdmi_data <= 24'hff00ff;
                    else if(S_x < 12'd896)
                        O_hdmi_data <= 24'hffffff;
                    else
                        O_hdmi_data <= 24'h202020;
                end
                else begin
                    O_hdmi_data <= 24'd0;
                end
            end
            else if(DEBUG_MODE == 2) begin
                if(S_video_de_2d) begin
                    case (I_debug_status)
                        4'b0000: O_hdmi_data <= 24'h000000;
                        4'b0001: O_hdmi_data <= 24'hff0000;
                        4'b0011: O_hdmi_data <= 24'hffff00;
                        4'b0111: O_hdmi_data <= 24'h00ff00;
                        4'b1111: O_hdmi_data <= I_video_rd_data;
                        default: O_hdmi_data <= 24'h0000ff;
                    endcase
                end
                else begin
                    O_hdmi_data <= 24'd0;
                end
            end
            else if(DEBUG_MODE == 3) begin
                if(S_video_de_2d) begin
                    if(S_x < 12'd256)
                        O_hdmi_data <= I_debug_status[0] ? 24'hff8000 : 24'h201000;
                    else if(S_x < 12'd512)
                        O_hdmi_data <= I_debug_status[1] ? 24'hffff00 : 24'h202000;
                    else if(S_x < 12'd768)
                        O_hdmi_data <= I_debug_status[2] ? 24'hff0000 : 24'h200000;
                    else
                        O_hdmi_data <= I_debug_status[3] ? 24'h00ffff : 24'h002020;
                end
                else begin
                    O_hdmi_data <= 24'd0;
                end
            end
            else begin
                if(S_osd_hit)
                    O_hdmi_data <= S_osd_color;
                else
                    O_hdmi_data <= (dn_color_enabled && !(RESTORE_BASE19 && !I_night_active)) ? denoised_rgb : dn_base_rgb;
            end
        end
    end

endmodule
