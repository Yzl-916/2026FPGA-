// One long-press event per stable release/press. Mode changes disarm the key.
module inspection_key_control #(
    parameter integer DEBOUNCE_CYCLES=750000,
    parameter integer HOLD_CYCLES=75000000
)(
    input wire clk,rst_n,enable,key_n,
    output reg teach_pulse
);
    localparam DBW=DEBOUNCE_CYCLES<2?1:$clog2(DEBOUNCE_CYCLES);
    localparam HW=HOLD_CYCLES<2?1:$clog2(HOLD_CYCLES);
    reg meta,sync,level,armed,fired;
    reg [DBW-1:0] debounce;
    reg [HW-1:0] held;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            meta<=0;sync<=0;level<=0;armed<=0;fired<=0;
            debounce<=0;held<=0;teach_pulse<=0;
        end else begin
            meta<=key_n;sync<=meta;teach_pulse<=0;
            if(!enable) begin
                level<=0;armed<=0;fired<=0;debounce<=0;held<=0;
            end else begin
                if(sync==level) debounce<=0;
                else if(debounce==DEBOUNCE_CYCLES-1) begin
                    debounce<=0;level<=sync;
                    if(sync) begin armed<=1;fired<=0;end
                end else debounce<=debounce+1'b1;
                // A release must settle before another operation can be armed.
                if(level || sync || !armed || fired) held<=0;
                else if(held==HOLD_CYCLES-1) begin
                    teach_pulse<=1;fired<=1;armed<=0;held<=0;
                end else held<=held+1'b1;
            end
        end
    end
endmodule
