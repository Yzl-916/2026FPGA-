// Three pixel stages; inspection graphics never enter the detector input.
// Chinese 16x16 glyphs use one 1024x16 synchronous ROM; no frame buffer.
// Regenerate marked regions with tools/generate_inspection_font.py.
module inspection_overlay #(
    parameter integer IMG_WIDTH=1280,POSITION_TOL=48,
    parameter integer PANEL_X=800,PANEL_Y=592,
    // 120 display frames at 75 MHz / (1650 * 750) are approximately 1.98 s.
    // Zero retains direct frame snapshots for diagnostics and pixel tests.
    parameter integer RESULT_HOLD_FRAMES=120
)(
    input wire clk,rst_n,vs,hs,de,enable,
    input wire [23:0] rgb,
    input wire template_valid,teaching,cycle_armed,
    input wire [1:0] reference_count,
    input wire [8:0] reference_colors,
    input wire [32:0] reference_x,
    input wire [29:0] reference_y,
    input wire [5:0] reference_errors,
    input wire [3:0] status,live_count,
    input wire [15:0] pass_bcd,
    output reg out_vs,out_hs,out_de,
    output reg [23:0] out_rgb
);
    reg [10:0] x;reg [9:0] y;
    reg v_valid,v_armed;reg [1:0] v_count;reg [8:0] v_colors;
    reg [32:0] v_x;reg [29:0] v_y;reg [5:0] v_errors;
    reg [3:0] v_status,v_live;reg [15:0] v_pass;
    localparam HOLD_WIDTH=RESULT_HOLD_FRAMES<2?1:$clog2(RESULT_HOLD_FRAMES);
    reg [HOLD_WIDTH-1:0] hold_left,uncertain_frames;
    reg vs_old;
    wire frame_start=vs && !vs_old;
    wire confirmed=template_valid && !teaching && status>=3 && status<=8;
    wire shown_confirmed=v_valid && v_status>=3 && v_status<=8;
    // Keep one coherent display snapshot. The inspection engine and batch
    // counter continue at full rate and never consume these held outputs.
    wire refresh=RESULT_HOLD_FRAMES==0 || !template_valid || teaching || !v_valid ||
        (confirmed ? (!shown_confirmed || hold_left==0) :
                     (!shown_confirmed || uncertain_frames>=RESULT_HOLD_FRAMES-1));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            x<=0;y<=0;v_valid<=0;v_armed<=0;v_count<=0;v_colors<=0;v_x<=0;v_y<=0;
            v_errors<=0;v_status<=0;v_live<=0;v_pass<=0;
            hold_left<=0;uncertain_frames<=0;vs_old<=0;
        end else begin
            vs_old<=vs;
            if(vs)begin x<=0;y<=0;end
            else if(de)begin
                if(x==IMG_WIDTH-1)begin x<=0;y<=y+1'b1;end else x<=x+1'b1;
            end
            if(!enable)begin
                // Mode exit or invalid display metadata cancels the old view.
                // RGB/sync bypass latency is unchanged.
                v_valid<=0;v_status<=0;v_count<=0;v_armed<=0;v_errors<=0;
                hold_left<=0;uncertain_frames<=0;
            end else if(frame_start)begin
                v_valid<=template_valid;v_count<=reference_count;
                v_colors<=reference_colors;v_x<=reference_x;v_y<=reference_y;
                if(refresh)begin
                    v_armed<=cycle_armed;v_errors<=reference_errors;v_status<=status;
                    v_live<=live_count;v_pass<=pass_bcd;
                    hold_left<=RESULT_HOLD_FRAMES>0 && confirmed?RESULT_HOLD_FRAMES-1:0;
                    uncertain_frames<=0;
                end else begin
                    if(hold_left!=0)hold_left<=hold_left-1'b1;
                    // A brief WAIT never replaces a confirmed result. A
                    // continuous WAIT expires after the same bounded 2 s;
                    // stale PASS is not retained indefinitely.
                    if(confirmed)uncertain_frames<=0;
                    else uncertain_frames<=uncertain_frames+1'b1;
                end
            end
        end
    end
    // BEGIN GENERATED TEXT
    localparam [167:0] TXT_TITLE = 168'h2cc34e000000000000000000000000000000000000; // 配件检查
    localparam [167:0] TXT_STATUS_0 = 168'h3d0445493000000000000000000000000000000000; // 长按键4示教
    localparam [167:0] TXT_STATUS_1 = 168'h4935005565d8640000000000000000000000000000; // 示教中 请保持静止
    localparam [167:0] TXT_STATUS_2 = 168'h69b71d015597619000000000000000000000000000; // 等待稳定 请保持静止
    localparam [167:0] TXT_STATUS_3 = 168'h34e79f000000000000000000000000000000000000; // 检查通过
    localparam [167:0] TXT_STATUS_4 = 168'h34e80c000000000000000000000000000000000000; // 检查缺件
    localparam [167:0] TXT_STATUS_5 = 168'h34e84c000000000000000000000000000000000000; // 检查多件
    localparam [167:0] TXT_STATUS_6 = 168'h34e8a3000000000000000000000000000000000000; // 检查错色
    localparam [167:0] TXT_STATUS_7 = 168'h34e8a4000000000000000000000000000000000000; // 检查错位
    localparam [167:0] TXT_STATUS_8 = 168'h5659a7a29000000000000000000000000000000000; // 请放入下一组
    localparam [167:0] TXT_STATUS_9 = 168'h4930aa12bb2d000000000000000000000000000000; // 示教1至3个目标
    localparam [167:0] TXT_STATUS_10 = 168'h56ebecb40000000000000000000000000000000000; // 请分开目标
    localparam [167:0] TXT_COUNTS = 168'hc31040cb304079f041041000000000000000000000; // 模板0 当前0 通过0000
    localparam [167:0] TXT_HINT = 168'h3d0445a34493000000000000000000000000000000; // 长按键4一秒示教
    localparam [167:0] TXT_READY = 168'hd659a7a29000000000000000000000000000000000; // 可放入下一组
    localparam [167:0] TXT_REARM = 168'h576df8e7aecd380000000000000000000000000000; // 请取走全部后再检查
    localparam [11:0] TXT_REF_NORMAL = 12'hf3d; // 正常
    localparam [11:0] TXT_REF_MISSING = 12'h80c; // 缺件
    localparam [11:0] TXT_REF_COLOR = 12'h8a3; // 错色
    localparam [11:0] TXT_REF_POSITION = 12'h8a4; // 错位
    localparam [11:0] TXT_REF_PENDING = 12'h6dd; // 待定
    // END GENERATED TEXT
    function [5:0] letter;
        input [167:0] line;input [4:0] column;
        begin letter=column<28?line[(27-column)*6+:6]:6'd0;end
    endfunction
    function [11:0] error_word;
        input [1:0] error;input pending;
        begin
            if(pending)error_word=TXT_REF_PENDING;
            else case(error)
                0:error_word=TXT_REF_NORMAL;
                1:error_word=TXT_REF_MISSING;
                2:error_word=TXT_REF_COLOR;
                default:error_word=TXT_REF_POSITION;
            endcase
        end
    endfunction
    // BEGIN GENERATED ROM
    reg [15:0] font_rom [0:1023];
    initial begin
        // Glyph 0:  
        font_rom[0] = 16'h0000;
        font_rom[1] = 16'h0000;
        font_rom[2] = 16'h0000;
        font_rom[3] = 16'h0000;
        font_rom[4] = 16'h0000;
        font_rom[5] = 16'h0000;
        font_rom[6] = 16'h0000;
        font_rom[7] = 16'h0000;
        font_rom[8] = 16'h0000;
        font_rom[9] = 16'h0000;
        font_rom[10] = 16'h0000;
        font_rom[11] = 16'h0000;
        font_rom[12] = 16'h0000;
        font_rom[13] = 16'h0000;
        font_rom[14] = 16'h0000;
        font_rom[15] = 16'h0000;
        // Glyph 1: 0
        font_rom[16] = 16'h0000;
        font_rom[17] = 16'h0000;
        font_rom[18] = 16'h03c0;
        font_rom[19] = 16'h0640;
        font_rom[20] = 16'h0420;
        font_rom[21] = 16'h0420;
        font_rom[22] = 16'h0420;
        font_rom[23] = 16'h0420;
        font_rom[24] = 16'h0420;
        font_rom[25] = 16'h0420;
        font_rom[26] = 16'h0460;
        font_rom[27] = 16'h02c0;
        font_rom[28] = 16'h0180;
        font_rom[29] = 16'h0000;
        font_rom[30] = 16'h0000;
        font_rom[31] = 16'h0000;
        // Glyph 2: 1
        font_rom[32] = 16'h0000;
        font_rom[33] = 16'h0000;
        font_rom[34] = 16'h0080;
        font_rom[35] = 16'h0180;
        font_rom[36] = 16'h0780;
        font_rom[37] = 16'h0580;
        font_rom[38] = 16'h0180;
        font_rom[39] = 16'h0180;
        font_rom[40] = 16'h0180;
        font_rom[41] = 16'h0180;
        font_rom[42] = 16'h0180;
        font_rom[43] = 16'h0180;
        font_rom[44] = 16'h0180;
        font_rom[45] = 16'h0000;
        font_rom[46] = 16'h0000;
        font_rom[47] = 16'h0000;
        // Glyph 3: 2
        font_rom[48] = 16'h0000;
        font_rom[49] = 16'h0000;
        font_rom[50] = 16'h03c0;
        font_rom[51] = 16'h0660;
        font_rom[52] = 16'h0420;
        font_rom[53] = 16'h0060;
        font_rom[54] = 16'h0040;
        font_rom[55] = 16'h00c0;
        font_rom[56] = 16'h0080;
        font_rom[57] = 16'h0100;
        font_rom[58] = 16'h0200;
        font_rom[59] = 16'h07e0;
        font_rom[60] = 16'h07e0;
        font_rom[61] = 16'h0000;
        font_rom[62] = 16'h0000;
        font_rom[63] = 16'h0000;
        // Glyph 4: 3
        font_rom[64] = 16'h0000;
        font_rom[65] = 16'h0000;
        font_rom[66] = 16'h03c0;
        font_rom[67] = 16'h0660;
        font_rom[68] = 16'h0420;
        font_rom[69] = 16'h0060;
        font_rom[70] = 16'h00c0;
        font_rom[71] = 16'h00c0;
        font_rom[72] = 16'h0060;
        font_rom[73] = 16'h0020;
        font_rom[74] = 16'h0420;
        font_rom[75] = 16'h0640;
        font_rom[76] = 16'h0180;
        font_rom[77] = 16'h0000;
        font_rom[78] = 16'h0000;
        font_rom[79] = 16'h0000;
        // Glyph 5: 4
        font_rom[80] = 16'h0000;
        font_rom[81] = 16'h0000;
        font_rom[82] = 16'h0040;
        font_rom[83] = 16'h00c0;
        font_rom[84] = 16'h01c0;
        font_rom[85] = 16'h0140;
        font_rom[86] = 16'h0240;
        font_rom[87] = 16'h0640;
        font_rom[88] = 16'h0440;
        font_rom[89] = 16'h0ff0;
        font_rom[90] = 16'h0040;
        font_rom[91] = 16'h0040;
        font_rom[92] = 16'h0040;
        font_rom[93] = 16'h0000;
        font_rom[94] = 16'h0000;
        font_rom[95] = 16'h0000;
        // Glyph 6: 5
        font_rom[96] = 16'h0000;
        font_rom[97] = 16'h0000;
        font_rom[98] = 16'h0000;
        font_rom[99] = 16'h03e0;
        font_rom[100] = 16'h0600;
        font_rom[101] = 16'h0400;
        font_rom[102] = 16'h0500;
        font_rom[103] = 16'h07c0;
        font_rom[104] = 16'h0460;
        font_rom[105] = 16'h0020;
        font_rom[106] = 16'h0020;
        font_rom[107] = 16'h0c60;
        font_rom[108] = 16'h06c0;
        font_rom[109] = 16'h0380;
        font_rom[110] = 16'h0000;
        font_rom[111] = 16'h0000;
        // Glyph 7: 6
        font_rom[112] = 16'h0000;
        font_rom[113] = 16'h0000;
        font_rom[114] = 16'h0080;
        font_rom[115] = 16'h0180;
        font_rom[116] = 16'h0100;
        font_rom[117] = 16'h0300;
        font_rom[118] = 16'h07c0;
        font_rom[119] = 16'h0620;
        font_rom[120] = 16'h0430;
        font_rom[121] = 16'h0430;
        font_rom[122] = 16'h0420;
        font_rom[123] = 16'h0660;
        font_rom[124] = 16'h03c0;
        font_rom[125] = 16'h0000;
        font_rom[126] = 16'h0000;
        font_rom[127] = 16'h0000;
        // Glyph 8: 7
        font_rom[128] = 16'h0000;
        font_rom[129] = 16'h0000;
        font_rom[130] = 16'h0000;
        font_rom[131] = 16'h07e0;
        font_rom[132] = 16'h0020;
        font_rom[133] = 16'h0060;
        font_rom[134] = 16'h0040;
        font_rom[135] = 16'h00c0;
        font_rom[136] = 16'h0080;
        font_rom[137] = 16'h0180;
        font_rom[138] = 16'h0100;
        font_rom[139] = 16'h0100;
        font_rom[140] = 16'h0300;
        font_rom[141] = 16'h0300;
        font_rom[142] = 16'h0000;
        font_rom[143] = 16'h0000;
        // Glyph 9: 8
        font_rom[144] = 16'h0000;
        font_rom[145] = 16'h0000;
        font_rom[146] = 16'h03c0;
        font_rom[147] = 16'h0460;
        font_rom[148] = 16'h0420;
        font_rom[149] = 16'h0460;
        font_rom[150] = 16'h07c0;
        font_rom[151] = 16'h07c0;
        font_rom[152] = 16'h0420;
        font_rom[153] = 16'h0c20;
        font_rom[154] = 16'h0420;
        font_rom[155] = 16'h0660;
        font_rom[156] = 16'h03c0;
        font_rom[157] = 16'h0000;
        font_rom[158] = 16'h0000;
        font_rom[159] = 16'h0000;
        // Glyph 10: 9
        font_rom[160] = 16'h0000;
        font_rom[161] = 16'h0000;
        font_rom[162] = 16'h03c0;
        font_rom[163] = 16'h0460;
        font_rom[164] = 16'h0c20;
        font_rom[165] = 16'h0c20;
        font_rom[166] = 16'h0c60;
        font_rom[167] = 16'h06c0;
        font_rom[168] = 16'h03c0;
        font_rom[169] = 16'h0080;
        font_rom[170] = 16'h0180;
        font_rom[171] = 16'h0100;
        font_rom[172] = 16'h0300;
        font_rom[173] = 16'h0000;
        font_rom[174] = 16'h0000;
        font_rom[175] = 16'h0000;
        // Glyph 11: 配
        font_rom[176] = 16'h0000;
        font_rom[177] = 16'h7f7c;
        font_rom[178] = 16'h7f7c;
        font_rom[179] = 16'h1404;
        font_rom[180] = 16'h7f04;
        font_rom[181] = 16'h5504;
        font_rom[182] = 16'h5504;
        font_rom[183] = 16'h557c;
        font_rom[184] = 16'h5540;
        font_rom[185] = 16'h6340;
        font_rom[186] = 16'h4140;
        font_rom[187] = 16'h7f40;
        font_rom[188] = 16'h4140;
        font_rom[189] = 16'h7f42;
        font_rom[190] = 16'h417e;
        font_rom[191] = 16'h0000;
        // Glyph 12: 件
        font_rom[192] = 16'h0820;
        font_rom[193] = 16'h0820;
        font_rom[194] = 16'h1320;
        font_rom[195] = 16'h3220;
        font_rom[196] = 16'h33fc;
        font_rom[197] = 16'h7620;
        font_rom[198] = 16'h5420;
        font_rom[199] = 16'h1020;
        font_rom[200] = 16'h17fe;
        font_rom[201] = 16'h1020;
        font_rom[202] = 16'h1020;
        font_rom[203] = 16'h1020;
        font_rom[204] = 16'h1020;
        font_rom[205] = 16'h1020;
        font_rom[206] = 16'h0000;
        font_rom[207] = 16'h0000;
        // Glyph 13: 检
        font_rom[208] = 16'h0000;
        font_rom[209] = 16'h1060;
        font_rom[210] = 16'h1060;
        font_rom[211] = 16'h10f0;
        font_rom[212] = 16'h7c90;
        font_rom[213] = 16'h110c;
        font_rom[214] = 16'h13f6;
        font_rom[215] = 16'h3200;
        font_rom[216] = 16'h3d44;
        font_rom[217] = 16'h776c;
        font_rom[218] = 16'h5128;
        font_rom[219] = 16'h51a8;
        font_rom[220] = 16'h1010;
        font_rom[221] = 16'h1410;
        font_rom[222] = 16'h17fe;
        font_rom[223] = 16'h1000;
        // Glyph 14: 查
        font_rom[224] = 16'h0000;
        font_rom[225] = 16'h0180;
        font_rom[226] = 16'h0180;
        font_rom[227] = 16'h7ffe;
        font_rom[228] = 16'h07c0;
        font_rom[229] = 16'h0db0;
        font_rom[230] = 16'h199c;
        font_rom[231] = 16'h7186;
        font_rom[232] = 16'h0ff0;
        font_rom[233] = 16'h0810;
        font_rom[234] = 16'h0ff0;
        font_rom[235] = 16'h0810;
        font_rom[236] = 16'h0ff0;
        font_rom[237] = 16'h0000;
        font_rom[238] = 16'h7ffe;
        font_rom[239] = 16'h0000;
        // Glyph 15: 长
        font_rom[240] = 16'h0000;
        font_rom[241] = 16'h0c00;
        font_rom[242] = 16'h0c30;
        font_rom[243] = 16'h0c60;
        font_rom[244] = 16'h0cc0;
        font_rom[245] = 16'h0d80;
        font_rom[246] = 16'h0d00;
        font_rom[247] = 16'h7ffe;
        font_rom[248] = 16'h0c80;
        font_rom[249] = 16'h0cc0;
        font_rom[250] = 16'h0c40;
        font_rom[251] = 16'h0c20;
        font_rom[252] = 16'h0db8;
        font_rom[253] = 16'h0e1e;
        font_rom[254] = 16'h0c04;
        font_rom[255] = 16'h0000;
        // Glyph 16: 按
        font_rom[256] = 16'h1060;
        font_rom[257] = 16'h1020;
        font_rom[258] = 16'h13fe;
        font_rom[259] = 16'h7b02;
        font_rom[260] = 16'h1362;
        font_rom[261] = 16'h1040;
        font_rom[262] = 16'h1040;
        font_rom[263] = 16'h1ffe;
        font_rom[264] = 16'h7088;
        font_rom[265] = 16'h5188;
        font_rom[266] = 16'h11d0;
        font_rom[267] = 16'h1070;
        font_rom[268] = 16'h107c;
        font_rom[269] = 16'h3786;
        font_rom[270] = 16'h0000;
        font_rom[271] = 16'h0000;
        // Glyph 17: 键
        font_rom[272] = 16'h0000;
        font_rom[273] = 16'h1010;
        font_rom[274] = 16'h377c;
        font_rom[275] = 16'h3f14;
        font_rom[276] = 16'h4114;
        font_rom[277] = 16'h42fe;
        font_rom[278] = 16'h3a14;
        font_rom[279] = 16'h377c;
        font_rom[280] = 16'h3110;
        font_rom[281] = 16'h797c;
        font_rom[282] = 16'h3710;
        font_rom[283] = 16'h337e;
        font_rom[284] = 16'h3f10;
        font_rom[285] = 16'h3390;
        font_rom[286] = 16'h26fe;
        font_rom[287] = 16'h0400;
        // Glyph 18: 示
        font_rom[288] = 16'h0000;
        font_rom[289] = 16'h0000;
        font_rom[290] = 16'h1ff8;
        font_rom[291] = 16'h0000;
        font_rom[292] = 16'h0000;
        font_rom[293] = 16'h0000;
        font_rom[294] = 16'h7ffe;
        font_rom[295] = 16'h0082;
        font_rom[296] = 16'h0080;
        font_rom[297] = 16'h0c90;
        font_rom[298] = 16'h1898;
        font_rom[299] = 16'h1088;
        font_rom[300] = 16'h3084;
        font_rom[301] = 16'h6084;
        font_rom[302] = 16'h0380;
        font_rom[303] = 16'h0200;
        // Glyph 19: 教
        font_rom[304] = 16'h0000;
        font_rom[305] = 16'h0820;
        font_rom[306] = 16'h08a0;
        font_rom[307] = 16'h3f20;
        font_rom[308] = 16'h093e;
        font_rom[309] = 16'h7fc4;
        font_rom[310] = 16'h7fc4;
        font_rom[311] = 16'h08cc;
        font_rom[312] = 16'h3fa8;
        font_rom[313] = 16'h6628;
        font_rom[314] = 16'h04a8;
        font_rom[315] = 16'h3f90;
        font_rom[316] = 16'h6438;
        font_rom[317] = 16'h046c;
        font_rom[318] = 16'h1d86;
        font_rom[319] = 16'h0100;
        // Glyph 20: 中
        font_rom[320] = 16'h0000;
        font_rom[321] = 16'h0180;
        font_rom[322] = 16'h0180;
        font_rom[323] = 16'h0180;
        font_rom[324] = 16'h3ffc;
        font_rom[325] = 16'h2184;
        font_rom[326] = 16'h2184;
        font_rom[327] = 16'h2184;
        font_rom[328] = 16'h2184;
        font_rom[329] = 16'h3ffc;
        font_rom[330] = 16'h2184;
        font_rom[331] = 16'h0180;
        font_rom[332] = 16'h0180;
        font_rom[333] = 16'h0180;
        font_rom[334] = 16'h0180;
        font_rom[335] = 16'h0180;
        // Glyph 21: 请
        font_rom[336] = 16'h0000;
        font_rom[337] = 16'h0020;
        font_rom[338] = 16'h33fe;
        font_rom[339] = 16'h1820;
        font_rom[340] = 16'h03fc;
        font_rom[341] = 16'h0020;
        font_rom[342] = 16'h77fe;
        font_rom[343] = 16'h1000;
        font_rom[344] = 16'h11fc;
        font_rom[345] = 16'h1104;
        font_rom[346] = 16'h11fc;
        font_rom[347] = 16'h1504;
        font_rom[348] = 16'h19fc;
        font_rom[349] = 16'h3104;
        font_rom[350] = 16'h010c;
        font_rom[351] = 16'h0000;
        // Glyph 22: 保
        font_rom[352] = 16'h0800;
        font_rom[353] = 16'h19fc;
        font_rom[354] = 16'h110c;
        font_rom[355] = 16'h110c;
        font_rom[356] = 16'h31fc;
        font_rom[357] = 16'h3060;
        font_rom[358] = 16'h5060;
        font_rom[359] = 16'h57fe;
        font_rom[360] = 16'h10f0;
        font_rom[361] = 16'h11f0;
        font_rom[362] = 16'h1178;
        font_rom[363] = 16'h126c;
        font_rom[364] = 16'h1666;
        font_rom[365] = 16'h1060;
        font_rom[366] = 16'h0000;
        font_rom[367] = 16'h0000;
        // Glyph 23: 持
        font_rom[368] = 16'h0000;
        font_rom[369] = 16'h1020;
        font_rom[370] = 16'h1020;
        font_rom[371] = 16'h11fc;
        font_rom[372] = 16'h7c20;
        font_rom[373] = 16'h7c20;
        font_rom[374] = 16'h1020;
        font_rom[375] = 16'h13fe;
        font_rom[376] = 16'h1c08;
        font_rom[377] = 16'h73fe;
        font_rom[378] = 16'h5008;
        font_rom[379] = 16'h1108;
        font_rom[380] = 16'h1188;
        font_rom[381] = 16'h1088;
        font_rom[382] = 16'h3038;
        font_rom[383] = 16'h0030;
        // Glyph 24: 静
        font_rom[384] = 16'h1860;
        font_rom[385] = 16'h1840;
        font_rom[386] = 16'h7ff8;
        font_rom[387] = 16'h7e98;
        font_rom[388] = 16'h19f0;
        font_rom[389] = 16'h7e3c;
        font_rom[390] = 16'h0034;
        font_rom[391] = 16'h7eff;
        font_rom[392] = 16'h4234;
        font_rom[393] = 16'h7e34;
        font_rom[394] = 16'h42fc;
        font_rom[395] = 16'h7e30;
        font_rom[396] = 16'h4230;
        font_rom[397] = 16'h4660;
        font_rom[398] = 16'h0000;
        font_rom[399] = 16'h0000;
        // Glyph 25: 止
        font_rom[400] = 16'h0000;
        font_rom[401] = 16'h0080;
        font_rom[402] = 16'h0080;
        font_rom[403] = 16'h0080;
        font_rom[404] = 16'h0080;
        font_rom[405] = 16'h1880;
        font_rom[406] = 16'h18fc;
        font_rom[407] = 16'h1880;
        font_rom[408] = 16'h1880;
        font_rom[409] = 16'h1880;
        font_rom[410] = 16'h1880;
        font_rom[411] = 16'h1880;
        font_rom[412] = 16'h1880;
        font_rom[413] = 16'h7ffe;
        font_rom[414] = 16'h7ffe;
        font_rom[415] = 16'h0000;
        // Glyph 26: 等
        font_rom[416] = 16'h1020;
        font_rom[417] = 16'h3f7e;
        font_rom[418] = 16'h64c8;
        font_rom[419] = 16'h458c;
        font_rom[420] = 16'h1ff8;
        font_rom[421] = 16'h0180;
        font_rom[422] = 16'h0180;
        font_rom[423] = 16'hfffe;
        font_rom[424] = 16'h0030;
        font_rom[425] = 16'h0030;
        font_rom[426] = 16'h3ffc;
        font_rom[427] = 16'h0830;
        font_rom[428] = 16'h0430;
        font_rom[429] = 16'h0070;
        font_rom[430] = 16'h0000;
        font_rom[431] = 16'h0000;
        // Glyph 27: 待
        font_rom[432] = 16'h0860;
        font_rom[433] = 16'h1860;
        font_rom[434] = 16'h13fc;
        font_rom[435] = 16'h2060;
        font_rom[436] = 16'h4c60;
        font_rom[437] = 16'h0bfe;
        font_rom[438] = 16'h1008;
        font_rom[439] = 16'h3008;
        font_rom[440] = 16'h77fe;
        font_rom[441] = 16'h5008;
        font_rom[442] = 16'h1188;
        font_rom[443] = 16'h1088;
        font_rom[444] = 16'h1018;
        font_rom[445] = 16'h1038;
        font_rom[446] = 16'h1000;
        font_rom[447] = 16'h0000;
        // Glyph 28: 稳
        font_rom[448] = 16'h00c0;
        font_rom[449] = 16'h7cf8;
        font_rom[450] = 16'h1118;
        font_rom[451] = 16'h1310;
        font_rom[452] = 16'h12fc;
        font_rom[453] = 16'h7c04;
        font_rom[454] = 16'h31fc;
        font_rom[455] = 16'h3804;
        font_rom[456] = 16'h35fc;
        font_rom[457] = 16'h5400;
        font_rom[458] = 16'h50a0;
        font_rom[459] = 16'h12a6;
        font_rom[460] = 16'h128a;
        font_rom[461] = 16'h10f8;
        font_rom[462] = 16'h1000;
        font_rom[463] = 16'h0000;
        // Glyph 29: 定
        font_rom[464] = 16'h0100;
        font_rom[465] = 16'h0180;
        font_rom[466] = 16'h3ffc;
        font_rom[467] = 16'h2004;
        font_rom[468] = 16'h2004;
        font_rom[469] = 16'h1ff8;
        font_rom[470] = 16'h0080;
        font_rom[471] = 16'h0080;
        font_rom[472] = 16'h0880;
        font_rom[473] = 16'h18f8;
        font_rom[474] = 16'h1880;
        font_rom[475] = 16'h3c80;
        font_rom[476] = 16'h2780;
        font_rom[477] = 16'h61fe;
        font_rom[478] = 16'h0000;
        font_rom[479] = 16'h0000;
        // Glyph 30: 通
        font_rom[480] = 16'h0000;
        font_rom[481] = 16'h27fc;
        font_rom[482] = 16'h2018;
        font_rom[483] = 16'h30b0;
        font_rom[484] = 16'h0060;
        font_rom[485] = 16'h07fc;
        font_rom[486] = 16'h7444;
        font_rom[487] = 16'h77fc;
        font_rom[488] = 16'h3444;
        font_rom[489] = 16'h3444;
        font_rom[490] = 16'h37fc;
        font_rom[491] = 16'h3444;
        font_rom[492] = 16'h344c;
        font_rom[493] = 16'h3800;
        font_rom[494] = 16'h47fe;
        font_rom[495] = 16'h0000;
        // Glyph 31: 过
        font_rom[496] = 16'h0000;
        font_rom[497] = 16'h0018;
        font_rom[498] = 16'h3018;
        font_rom[499] = 16'h1018;
        font_rom[500] = 16'h1bfe;
        font_rom[501] = 16'h0018;
        font_rom[502] = 16'h0118;
        font_rom[503] = 16'h7118;
        font_rom[504] = 16'h1198;
        font_rom[505] = 16'h1098;
        font_rom[506] = 16'h1018;
        font_rom[507] = 16'h1010;
        font_rom[508] = 16'h1070;
        font_rom[509] = 16'h3c00;
        font_rom[510] = 16'h67fe;
        font_rom[511] = 16'h0000;
        // Glyph 32: 缺
        font_rom[512] = 16'h0000;
        font_rom[513] = 16'h0020;
        font_rom[514] = 16'h3020;
        font_rom[515] = 16'h2020;
        font_rom[516] = 16'h7efc;
        font_rom[517] = 16'h4824;
        font_rom[518] = 16'h0824;
        font_rom[519] = 16'h7e24;
        font_rom[520] = 16'h0824;
        font_rom[521] = 16'h0bfe;
        font_rom[522] = 16'h4a70;
        font_rom[523] = 16'h4a50;
        font_rom[524] = 16'h4a58;
        font_rom[525] = 16'h7e8c;
        font_rom[526] = 16'h0186;
        font_rom[527] = 16'h0000;
        // Glyph 33: 多
        font_rom[528] = 16'h0200;
        font_rom[529] = 16'h0600;
        font_rom[530] = 16'h0ff8;
        font_rom[531] = 16'h1030;
        font_rom[532] = 16'h2260;
        font_rom[533] = 16'h0180;
        font_rom[534] = 16'h0760;
        font_rom[535] = 16'h38fe;
        font_rom[536] = 16'h0304;
        font_rom[537] = 16'h060c;
        font_rom[538] = 16'h1898;
        font_rom[539] = 16'h0070;
        font_rom[540] = 16'h00c0;
        font_rom[541] = 16'h3f00;
        font_rom[542] = 16'h3000;
        font_rom[543] = 16'h0000;
        // Glyph 34: 错
        font_rom[544] = 16'h0000;
        font_rom[545] = 16'h10c8;
        font_rom[546] = 16'h10c8;
        font_rom[547] = 16'h31fe;
        font_rom[548] = 16'h3cc8;
        font_rom[549] = 16'h40c8;
        font_rom[550] = 16'h3ffe;
        font_rom[551] = 16'h1000;
        font_rom[552] = 16'h1000;
        font_rom[553] = 16'h7dfc;
        font_rom[554] = 16'h1184;
        font_rom[555] = 16'h11fc;
        font_rom[556] = 16'h1584;
        font_rom[557] = 16'h1984;
        font_rom[558] = 16'h11fc;
        font_rom[559] = 16'h0180;
        // Glyph 35: 色
        font_rom[560] = 16'h0000;
        font_rom[561] = 16'h0600;
        font_rom[562] = 16'h0400;
        font_rom[563] = 16'h0fe0;
        font_rom[564] = 16'h1860;
        font_rom[565] = 16'h3040;
        font_rom[566] = 16'h7ff8;
        font_rom[567] = 16'h1088;
        font_rom[568] = 16'h1088;
        font_rom[569] = 16'h1ff8;
        font_rom[570] = 16'h1008;
        font_rom[571] = 16'h1000;
        font_rom[572] = 16'h1000;
        font_rom[573] = 16'h1806;
        font_rom[574] = 16'h1ffc;
        font_rom[575] = 16'h0000;
        // Glyph 36: 位
        font_rom[576] = 16'h0000;
        font_rom[577] = 16'h0840;
        font_rom[578] = 16'h1860;
        font_rom[579] = 16'h1000;
        font_rom[580] = 16'h13fe;
        font_rom[581] = 16'h3000;
        font_rom[582] = 16'h3108;
        font_rom[583] = 16'h5118;
        font_rom[584] = 16'h5118;
        font_rom[585] = 16'h1190;
        font_rom[586] = 16'h1090;
        font_rom[587] = 16'h1090;
        font_rom[588] = 16'h1030;
        font_rom[589] = 16'h17fe;
        font_rom[590] = 16'h1000;
        font_rom[591] = 16'h1000;
        // Glyph 37: 放
        font_rom[592] = 16'h1020;
        font_rom[593] = 16'h1820;
        font_rom[594] = 16'h0840;
        font_rom[595] = 16'h7f7e;
        font_rom[596] = 16'h104c;
        font_rom[597] = 16'h10cc;
        font_rom[598] = 16'h1ec8;
        font_rom[599] = 16'h1248;
        font_rom[600] = 16'h1228;
        font_rom[601] = 16'h1228;
        font_rom[602] = 16'h3230;
        font_rom[603] = 16'h2230;
        font_rom[604] = 16'h6268;
        font_rom[605] = 16'h4fc6;
        font_rom[606] = 16'h0002;
        font_rom[607] = 16'h0000;
        // Glyph 38: 入
        font_rom[608] = 16'h0000;
        font_rom[609] = 16'h0400;
        font_rom[610] = 16'h0600;
        font_rom[611] = 16'h0300;
        font_rom[612] = 16'h0180;
        font_rom[613] = 16'h0180;
        font_rom[614] = 16'h01c0;
        font_rom[615] = 16'h0340;
        font_rom[616] = 16'h0260;
        font_rom[617] = 16'h0620;
        font_rom[618] = 16'h0c30;
        font_rom[619] = 16'h0818;
        font_rom[620] = 16'h181c;
        font_rom[621] = 16'h700e;
        font_rom[622] = 16'h6000;
        font_rom[623] = 16'h0000;
        // Glyph 39: 下
        font_rom[624] = 16'h0000;
        font_rom[625] = 16'h0000;
        font_rom[626] = 16'h7ffe;
        font_rom[627] = 16'h0100;
        font_rom[628] = 16'h0100;
        font_rom[629] = 16'h0100;
        font_rom[630] = 16'h0100;
        font_rom[631] = 16'h0160;
        font_rom[632] = 16'h0130;
        font_rom[633] = 16'h0118;
        font_rom[634] = 16'h010c;
        font_rom[635] = 16'h0100;
        font_rom[636] = 16'h0100;
        font_rom[637] = 16'h0100;
        font_rom[638] = 16'h0100;
        font_rom[639] = 16'h0000;
        // Glyph 40: 一
        font_rom[640] = 16'h0000;
        font_rom[641] = 16'h0000;
        font_rom[642] = 16'h0000;
        font_rom[643] = 16'h0000;
        font_rom[644] = 16'h0000;
        font_rom[645] = 16'h0000;
        font_rom[646] = 16'h0000;
        font_rom[647] = 16'h7ffe;
        font_rom[648] = 16'h7ffe;
        font_rom[649] = 16'h0000;
        font_rom[650] = 16'h0000;
        font_rom[651] = 16'h0000;
        font_rom[652] = 16'h0000;
        font_rom[653] = 16'h0000;
        font_rom[654] = 16'h0000;
        font_rom[655] = 16'h0000;
        // Glyph 41: 组
        font_rom[656] = 16'h0000;
        font_rom[657] = 16'h0000;
        font_rom[658] = 16'h11fc;
        font_rom[659] = 16'h2184;
        font_rom[660] = 16'h2184;
        font_rom[661] = 16'h4d84;
        font_rom[662] = 16'h79fc;
        font_rom[663] = 16'h1184;
        font_rom[664] = 16'h1184;
        font_rom[665] = 16'h2184;
        font_rom[666] = 16'h7dfc;
        font_rom[667] = 16'h0184;
        font_rom[668] = 16'h0184;
        font_rom[669] = 16'h7d84;
        font_rom[670] = 16'h43fe;
        font_rom[671] = 16'h0000;
        // Glyph 42: 至
        font_rom[672] = 16'h0000;
        font_rom[673] = 16'h0000;
        font_rom[674] = 16'h3ffc;
        font_rom[675] = 16'h0200;
        font_rom[676] = 16'h0300;
        font_rom[677] = 16'h0620;
        font_rom[678] = 16'h0c10;
        font_rom[679] = 16'h1ff8;
        font_rom[680] = 16'h0180;
        font_rom[681] = 16'h0180;
        font_rom[682] = 16'h1ff8;
        font_rom[683] = 16'h0180;
        font_rom[684] = 16'h0180;
        font_rom[685] = 16'h0180;
        font_rom[686] = 16'h7ffe;
        font_rom[687] = 16'h0000;
        // Glyph 43: 个
        font_rom[688] = 16'h0180;
        font_rom[689] = 16'h0180;
        font_rom[690] = 16'h03c0;
        font_rom[691] = 16'h0660;
        font_rom[692] = 16'h0c30;
        font_rom[693] = 16'h199c;
        font_rom[694] = 16'h7186;
        font_rom[695] = 16'h0180;
        font_rom[696] = 16'h0180;
        font_rom[697] = 16'h0180;
        font_rom[698] = 16'h0180;
        font_rom[699] = 16'h0180;
        font_rom[700] = 16'h0180;
        font_rom[701] = 16'h0180;
        font_rom[702] = 16'h0180;
        font_rom[703] = 16'h0000;
        // Glyph 44: 目
        font_rom[704] = 16'h0000;
        font_rom[705] = 16'h1ff8;
        font_rom[706] = 16'h1008;
        font_rom[707] = 16'h1008;
        font_rom[708] = 16'h1ff8;
        font_rom[709] = 16'h1ff8;
        font_rom[710] = 16'h1008;
        font_rom[711] = 16'h1008;
        font_rom[712] = 16'h1ff8;
        font_rom[713] = 16'h1008;
        font_rom[714] = 16'h1008;
        font_rom[715] = 16'h1008;
        font_rom[716] = 16'h1ff8;
        font_rom[717] = 16'h1008;
        font_rom[718] = 16'h0000;
        font_rom[719] = 16'h0000;
        // Glyph 45: 标
        font_rom[720] = 16'h0000;
        font_rom[721] = 16'h1000;
        font_rom[722] = 16'h11fc;
        font_rom[723] = 16'h1000;
        font_rom[724] = 16'h7c00;
        font_rom[725] = 16'h7c00;
        font_rom[726] = 16'h13fe;
        font_rom[727] = 16'h3820;
        font_rom[728] = 16'h3420;
        font_rom[729] = 16'h37ac;
        font_rom[730] = 16'h51a4;
        font_rom[731] = 16'h5126;
        font_rom[732] = 16'h1322;
        font_rom[733] = 16'h1220;
        font_rom[734] = 16'h10e0;
        font_rom[735] = 16'h0000;
        // Glyph 46: 分
        font_rom[736] = 16'h0000;
        font_rom[737] = 16'h0440;
        font_rom[738] = 16'h0460;
        font_rom[739] = 16'h0c20;
        font_rom[740] = 16'h0830;
        font_rom[741] = 16'h1818;
        font_rom[742] = 16'h300e;
        font_rom[743] = 16'h6ffe;
        font_rom[744] = 16'h0210;
        font_rom[745] = 16'h0210;
        font_rom[746] = 16'h0210;
        font_rom[747] = 16'h0610;
        font_rom[748] = 16'h0410;
        font_rom[749] = 16'h1830;
        font_rom[750] = 16'h3060;
        font_rom[751] = 16'h2000;
        // Glyph 47: 开
        font_rom[752] = 16'h0000;
        font_rom[753] = 16'h3ffc;
        font_rom[754] = 16'h0620;
        font_rom[755] = 16'h0620;
        font_rom[756] = 16'h0620;
        font_rom[757] = 16'h0620;
        font_rom[758] = 16'h7ffe;
        font_rom[759] = 16'h7ffe;
        font_rom[760] = 16'h0620;
        font_rom[761] = 16'h0420;
        font_rom[762] = 16'h0420;
        font_rom[763] = 16'h0c20;
        font_rom[764] = 16'h1820;
        font_rom[765] = 16'h7020;
        font_rom[766] = 16'h0000;
        font_rom[767] = 16'h0000;
        // Glyph 48: 模
        font_rom[768] = 16'h10d8;
        font_rom[769] = 16'h13fe;
        font_rom[770] = 16'h10d8;
        font_rom[771] = 16'h7c00;
        font_rom[772] = 16'h11fc;
        font_rom[773] = 16'h1104;
        font_rom[774] = 16'h39fc;
        font_rom[775] = 16'h3504;
        font_rom[776] = 16'h75fc;
        font_rom[777] = 16'h5020;
        font_rom[778] = 16'h13fe;
        font_rom[779] = 16'h1050;
        font_rom[780] = 16'h10c8;
        font_rom[781] = 16'h1707;
        font_rom[782] = 16'h0002;
        font_rom[783] = 16'h0000;
        // Glyph 49: 板
        font_rom[784] = 16'h0000;
        font_rom[785] = 16'h1000;
        font_rom[786] = 16'h11fe;
        font_rom[787] = 16'h1100;
        font_rom[788] = 16'h1100;
        font_rom[789] = 16'h7dfc;
        font_rom[790] = 16'h1144;
        font_rom[791] = 16'h1144;
        font_rom[792] = 16'h3d4c;
        font_rom[793] = 16'h3568;
        font_rom[794] = 16'h5128;
        font_rom[795] = 16'h5130;
        font_rom[796] = 16'h1330;
        font_rom[797] = 16'h126c;
        font_rom[798] = 16'h16c6;
        font_rom[799] = 16'h1080;
        // Glyph 50: 当
        font_rom[800] = 16'h0000;
        font_rom[801] = 16'h0180;
        font_rom[802] = 16'h1184;
        font_rom[803] = 16'h198c;
        font_rom[804] = 16'h0998;
        font_rom[805] = 16'h0990;
        font_rom[806] = 16'h0180;
        font_rom[807] = 16'h3ffc;
        font_rom[808] = 16'h0004;
        font_rom[809] = 16'h0004;
        font_rom[810] = 16'h3ffc;
        font_rom[811] = 16'h0004;
        font_rom[812] = 16'h0004;
        font_rom[813] = 16'h3ffc;
        font_rom[814] = 16'h0004;
        font_rom[815] = 16'h0004;
        // Glyph 51: 前
        font_rom[816] = 16'h0c10;
        font_rom[817] = 16'h0620;
        font_rom[818] = 16'h7ffe;
        font_rom[819] = 16'h0000;
        font_rom[820] = 16'h0004;
        font_rom[821] = 16'h3f64;
        font_rom[822] = 16'h2164;
        font_rom[823] = 16'h3f64;
        font_rom[824] = 16'h2164;
        font_rom[825] = 16'h2164;
        font_rom[826] = 16'h3f64;
        font_rom[827] = 16'h2164;
        font_rom[828] = 16'h2104;
        font_rom[829] = 16'h271c;
        font_rom[830] = 16'h2010;
        font_rom[831] = 16'h0000;
        // Glyph 52: 秒
        font_rom[832] = 16'h0020;
        font_rom[833] = 16'h1e20;
        font_rom[834] = 16'h2820;
        font_rom[835] = 16'h08ac;
        font_rom[836] = 16'h08a6;
        font_rom[837] = 16'h7ea2;
        font_rom[838] = 16'h19a0;
        font_rom[839] = 16'h1d24;
        font_rom[840] = 16'h3a24;
        font_rom[841] = 16'h2a0c;
        font_rom[842] = 16'h6818;
        font_rom[843] = 16'h4830;
        font_rom[844] = 16'h0860;
        font_rom[845] = 16'h0b80;
        font_rom[846] = 16'h0800;
        font_rom[847] = 16'h0000;
        // Glyph 53: 可
        font_rom[848] = 16'h0000;
        font_rom[849] = 16'h0000;
        font_rom[850] = 16'h7ffe;
        font_rom[851] = 16'h0018;
        font_rom[852] = 16'h0018;
        font_rom[853] = 16'h1f98;
        font_rom[854] = 16'h1098;
        font_rom[855] = 16'h1098;
        font_rom[856] = 16'h1098;
        font_rom[857] = 16'h1098;
        font_rom[858] = 16'h1f98;
        font_rom[859] = 16'h1098;
        font_rom[860] = 16'h1018;
        font_rom[861] = 16'h0018;
        font_rom[862] = 16'h0078;
        font_rom[863] = 16'h0060;
        // Glyph 54: 取
        font_rom[864] = 16'h0000;
        font_rom[865] = 16'h7f7c;
        font_rom[866] = 16'h2244;
        font_rom[867] = 16'h2244;
        font_rom[868] = 16'h3e64;
        font_rom[869] = 16'h2224;
        font_rom[870] = 16'h2224;
        font_rom[871] = 16'h3e28;
        font_rom[872] = 16'h3e28;
        font_rom[873] = 16'h2218;
        font_rom[874] = 16'h2398;
        font_rom[875] = 16'h3e28;
        font_rom[876] = 16'h6266;
        font_rom[877] = 16'h02c2;
        font_rom[878] = 16'h0200;
        font_rom[879] = 16'h0000;
        // Glyph 55: 走
        font_rom[880] = 16'h0000;
        font_rom[881] = 16'h0180;
        font_rom[882] = 16'h0180;
        font_rom[883] = 16'h1ffc;
        font_rom[884] = 16'h0180;
        font_rom[885] = 16'h0180;
        font_rom[886] = 16'h0180;
        font_rom[887] = 16'h7ffe;
        font_rom[888] = 16'h0180;
        font_rom[889] = 16'h0980;
        font_rom[890] = 16'h09f8;
        font_rom[891] = 16'h0980;
        font_rom[892] = 16'h1d80;
        font_rom[893] = 16'h1780;
        font_rom[894] = 16'h61fe;
        font_rom[895] = 16'h0000;
        // Glyph 56: 全
        font_rom[896] = 16'h0000;
        font_rom[897] = 16'h0180;
        font_rom[898] = 16'h0180;
        font_rom[899] = 16'h02c0;
        font_rom[900] = 16'h0660;
        font_rom[901] = 16'h1c38;
        font_rom[902] = 16'h300e;
        font_rom[903] = 16'h6ff2;
        font_rom[904] = 16'h0180;
        font_rom[905] = 16'h0180;
        font_rom[906] = 16'h1ff8;
        font_rom[907] = 16'h0180;
        font_rom[908] = 16'h0180;
        font_rom[909] = 16'h0180;
        font_rom[910] = 16'h3ffc;
        font_rom[911] = 16'h0000;
        // Glyph 57: 部
        font_rom[912] = 16'h0800;
        font_rom[913] = 16'h043e;
        font_rom[914] = 16'h7fa6;
        font_rom[915] = 16'h0124;
        font_rom[916] = 16'h1324;
        font_rom[917] = 16'h1a2c;
        font_rom[918] = 16'h7fa8;
        font_rom[919] = 16'h0024;
        font_rom[920] = 16'h0026;
        font_rom[921] = 16'h3f22;
        font_rom[922] = 16'h2122;
        font_rom[923] = 16'h212e;
        font_rom[924] = 16'h3f28;
        font_rom[925] = 16'h2120;
        font_rom[926] = 16'h0020;
        font_rom[927] = 16'h0000;
        // Glyph 58: 后
        font_rom[928] = 16'h0000;
        font_rom[929] = 16'h0008;
        font_rom[930] = 16'h0ffc;
        font_rom[931] = 16'h1800;
        font_rom[932] = 16'h1000;
        font_rom[933] = 16'h1000;
        font_rom[934] = 16'h1ffe;
        font_rom[935] = 16'h1000;
        font_rom[936] = 16'h1000;
        font_rom[937] = 16'h37fc;
        font_rom[938] = 16'h340c;
        font_rom[939] = 16'h240c;
        font_rom[940] = 16'h240c;
        font_rom[941] = 16'h67fc;
        font_rom[942] = 16'h440c;
        font_rom[943] = 16'h0400;
        // Glyph 59: 再
        font_rom[944] = 16'h0000;
        font_rom[945] = 16'h7ffc;
        font_rom[946] = 16'h0180;
        font_rom[947] = 16'h0180;
        font_rom[948] = 16'h1ff8;
        font_rom[949] = 16'h1188;
        font_rom[950] = 16'h1188;
        font_rom[951] = 16'h1ff8;
        font_rom[952] = 16'h1188;
        font_rom[953] = 16'h1188;
        font_rom[954] = 16'h7fff;
        font_rom[955] = 16'h1008;
        font_rom[956] = 16'h1008;
        font_rom[957] = 16'h1038;
        font_rom[958] = 16'h1010;
        font_rom[959] = 16'h0000;
        // Glyph 60: 正
        font_rom[960] = 16'h0000;
        font_rom[961] = 16'h0000;
        font_rom[962] = 16'h3ffc;
        font_rom[963] = 16'h3ffc;
        font_rom[964] = 16'h0080;
        font_rom[965] = 16'h0080;
        font_rom[966] = 16'h1880;
        font_rom[967] = 16'h18fc;
        font_rom[968] = 16'h18fc;
        font_rom[969] = 16'h1880;
        font_rom[970] = 16'h1880;
        font_rom[971] = 16'h1880;
        font_rom[972] = 16'h1880;
        font_rom[973] = 16'h1880;
        font_rom[974] = 16'h7ffe;
        font_rom[975] = 16'h0000;
        // Glyph 61: 常
        font_rom[976] = 16'h0000;
        font_rom[977] = 16'h0180;
        font_rom[978] = 16'h0990;
        font_rom[979] = 16'h0990;
        font_rom[980] = 16'h7ffe;
        font_rom[981] = 16'h6002;
        font_rom[982] = 16'h6ff2;
        font_rom[983] = 16'h0810;
        font_rom[984] = 16'h0ff0;
        font_rom[985] = 16'h0180;
        font_rom[986] = 16'h3ffc;
        font_rom[987] = 16'h3ffc;
        font_rom[988] = 16'h3184;
        font_rom[989] = 16'h318c;
        font_rom[990] = 16'h3198;
        font_rom[991] = 16'h0180;
        font_rom[992] = 16'h0000;
        font_rom[993] = 16'h0000;
        font_rom[994] = 16'h0000;
        font_rom[995] = 16'h0000;
        font_rom[996] = 16'h0000;
        font_rom[997] = 16'h0000;
        font_rom[998] = 16'h0000;
        font_rom[999] = 16'h0000;
        font_rom[1000] = 16'h0000;
        font_rom[1001] = 16'h0000;
        font_rom[1002] = 16'h0000;
        font_rom[1003] = 16'h0000;
        font_rom[1004] = 16'h0000;
        font_rom[1005] = 16'h0000;
        font_rom[1006] = 16'h0000;
        font_rom[1007] = 16'h0000;
        font_rom[1008] = 16'h0000;
        font_rom[1009] = 16'h0000;
        font_rom[1010] = 16'h0000;
        font_rom[1011] = 16'h0000;
        font_rom[1012] = 16'h0000;
        font_rom[1013] = 16'h0000;
        font_rom[1014] = 16'h0000;
        font_rom[1015] = 16'h0000;
        font_rom[1016] = 16'h0000;
        font_rom[1017] = 16'h0000;
        font_rom[1018] = 16'h0000;
        font_rom[1019] = 16'h0000;
        font_rom[1020] = 16'h0000;
        font_rom[1021] = 16'h0000;
        font_rom[1022] = 16'h0000;
        font_rom[1023] = 16'h0000;
    end
    // END GENERATED ROM
    wire panel=enable && x>=PANEL_X && x<PANEL_X+464 && y>=PANEL_Y && y<PANEL_Y+112;
    wire text_area=panel && x>=PANEL_X+8 && x<PANEL_X+456 && y>=PANEL_Y+8 && y<PANEL_Y+104;
    wire [10:0] tx=x-(PANEL_X+8);wire [9:0] ty=y-(PANEL_Y+8);
    wire [4:0] column=tx[8:4];wire [2:0] line_index=ty[6:4];
    reg [5:0] character;reg [167:0] text_line;reg [11:0] ref_word;
    reg [23:0] paint;reg hit;integer i;
    reg [10:0] bx;reg [9:0] by;
    wire [23:0] state_color=v_status==3?24'h30ff60:
        (v_status>=4 && v_status<=7)?24'hff5050:24'hffd040;
    always @* begin
        text_line=TXT_TITLE;ref_word=0;
        case(line_index)
        1:case(v_status)
            0:text_line=TXT_STATUS_0;
            1:text_line=TXT_STATUS_1;
            2:text_line=TXT_STATUS_2;
            3:text_line=TXT_STATUS_3;
            4:text_line=TXT_STATUS_4;
            5:text_line=TXT_STATUS_5;
            6:text_line=TXT_STATUS_6;
            7:text_line=TXT_STATUS_7;
            8:text_line=TXT_STATUS_8;
            9:text_line=TXT_STATUS_9;
            10:text_line=TXT_STATUS_10;
            default:text_line=TXT_STATUS_2;
        endcase
        2:text_line=TXT_COUNTS;
        3:text_line=0;
        4:text_line=TXT_HINT;
        5:text_line=v_armed?TXT_READY:TXT_REARM;
        default:text_line=TXT_TITLE;
        endcase
        character=letter(text_line,column);
        if(line_index==2)begin
            if(column==2)character=6'd1+v_count;
            if(column==6)character=6'd1+v_live;
            if(column>=10 && column<=13)character=6'd1+((v_pass>>((13-column)*4))&4'hf);
        end
        if(line_index==3)begin
            // Three reference slots: number, space, two Chinese status glyphs.
            // Hide absent slots, including pending markers before any template.
            if(v_count>=1 && column<4)begin
                ref_word=error_word(v_errors[1:0],!v_valid || v_status==2);
                case(column)0:character=6'd2;2:character=ref_word[11:6];3:character=ref_word[5:0];default:character=0;endcase
            end
            if(v_count>=2 && column>=7 && column<11)begin
                ref_word=error_word(v_errors[3:2],!v_valid || v_status==2);
                case(column)7:character=6'd3;9:character=ref_word[11:6];10:character=ref_word[5:0];default:character=0;endcase
            end
            if(v_count>=3 && column>=14 && column<18)begin
                ref_word=error_word(v_errors[5:4],!v_valid || v_status==2);
                case(column)14:character=6'd4;16:character=ref_word[11:6];17:character=ref_word[5:0];default:character=0;endcase
            end
        end
        paint=rgb;hit=0;bx=0;by=0;
        for(i=0;i<3;i=i+1)begin
            bx=v_x[i*11+:11];by=v_y[i*10+:10];
            // Symmetric comparisons avoid unsigned underflow near image edges.
            if(enable && v_valid && i<v_count &&
               {1'b0,x}+POSITION_TOL>=bx && x<={1'b0,bx}+POSITION_TOL &&
               {1'b0,y}+POSITION_TOL>=by && y<={1'b0,by}+POSITION_TOL &&
               (({1'b0,x}+POSITION_TOL<bx+2 || x+2>={1'b0,bx}+POSITION_TOL ||
                 {1'b0,y}+POSITION_TOL<by+2 || y+2>={1'b0,by}+POSITION_TOL) && (x[3]^y[3]))) begin
                hit=1;paint=(v_status==2)?24'hffd040:(v_errors[i*2+:2]!=0)?24'hff5050:24'h30ffff;
            end
        end
        if(panel)begin hit=1;paint=24'h142437;end
    end
    reg [2:0] sync0,sync1;
    reg [23:0] rgb0,rgb1,ink0,ink1;
    reg text0,text1;reg [5:0] char0;reg [3:0] col0,col1,row0;
    reg [15:0] bits1;
    // No reset on the ROM output register, allowing block ROM inference.
    always @(posedge clk) bits1<=font_rom[{char0,row0}];
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            sync0<=0;sync1<=0;out_vs<=0;out_hs<=0;out_de<=0;rgb0<=0;rgb1<=0;out_rgb<=0;
            ink0<=0;ink1<=0;text0<=0;text1<=0;char0<=0;col0<=0;col1<=0;row0<=0;
        end else begin
            sync0<={vs,hs,de};sync1<=sync0;{out_vs,out_hs,out_de}<=sync1;
            rgb0<=hit?paint:rgb;rgb1<=rgb0;
            char0<=character;
            text0<=text_area;text1<=text0;col0<=tx[3:0];col1<=col0;row0<=ty[3:0];
            ink0<=line_index==1?state_color:24'hffffff;ink1<=ink0;
            if(text1 && bits1[15-col1])out_rgb<=ink1;
            else out_rgb<=rgb1;
        end
    end
endmodule
