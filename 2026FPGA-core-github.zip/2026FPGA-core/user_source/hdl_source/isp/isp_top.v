module isp_top (
    input wire I_meter_ack,
    output wire [7:0] O_meter_mean,
    output wire O_meter_clipped, O_meter_toggle,
    output wire [1:0] O_frame_mode,
    input 			axi4s_video_aclk,
    input 			I_rst_n			,
    input 			I_edge_mode		,
    input 			I_enhance_mode		,
    input 			I_tlast			,
    input 			I_tuser			,
    input [39:0] 	I_tdata			,
    input 			I_tvalid		,
    input [9:0] 	I_tdest			,
    input 			O_tready		,
    output [127:0] 	O_tdata			,
    output 			O_tlast			,
    output 			O_tuser			,
    output 			O_tvalid		,
    output 			I_tready
);
 
wire         m_aixs_tvalid;  //synthesis keep 
  wire [127:0] m_aixs_tdata;  //synthesis keep 
  wire         m_aixs_tuser;  //synthesis keep 
  wire         m_aixs_tlast;  //synthesis keep 
  wire         m_aixs_tready;  //synthesis keep 
  
  wire [ 95:0] m_aixs_tdata_96;  //synthesis keep 


  wire         awb_O_tlast;  //synthesis keep 
  wire         awb_O_tuser;  //synthesis keep 
  wire [ 95:0] awb_O_tdata;  //synthesis keep 
  wire         awb_O_tvalid;  //synthesis keep 
  wire         awb_O_tready;  //synthesis keep 

  wire         awb_O_tuser_128;  //synthesis keep 
  wire         awb_O_tvalid_128;  //synthesis keep 
  wire [127:0] awb_O_tdata_128;  //synthesis keep 

  wire         enh_O_tlast;   //synthesis keep
  wire         enh_O_tuser;   //synthesis keep
  wire [ 95:0] enh_O_tdata;   //synthesis keep
  wire [ 95:0] edge_tdata;    //synthesis keep
  wire         enh_O_tvalid;  //synthesis keep
  wire         enh_O_tready;  //synthesis keep

  wire         isp_mux_tlast;
  wire         isp_mux_tuser;
  wire         isp_mux_tvalid;
  wire [ 95:0] isp_mux_tdata;

  reg          edge_mode_meta;
  reg          edge_mode_sync;
  reg          edge_mode_sel;
  reg          enh_mode_meta;
  reg          enh_mode_sync;
  reg          enh_mode_sel;

  // Mode of the selected pixel stream, latched at the AWB frame boundary.
  // 0=color, 1=edge, 2=visual enhancement, 3=detection (normal RGB).
  assign O_frame_mode = {enh_mode_sel, edge_mode_sel};

  // The enhancement filter has one pipeline stage.  Delay the original AWB stream
  // by the same amount so both mux inputs stay aligned when the user changes
  // I_enhance_mode.
  reg          awb_dly_tlast;
  reg          awb_dly_tuser;
  reg [95:0]   awb_dly_tdata;
  reg          awb_dly_tvalid;

  always @(posedge axi4s_video_aclk or negedge I_rst_n) begin
      if (!I_rst_n) begin
          awb_dly_tlast  <= 1'b0;
          awb_dly_tuser  <= 1'b0;
          awb_dly_tdata  <= 96'd0;
          awb_dly_tvalid <= 1'b0;
      end else begin
          awb_dly_tlast  <= awb_O_tlast;
          awb_dly_tuser  <= awb_O_tuser;
          awb_dly_tdata  <= awb_O_tdata;
          awb_dly_tvalid <= awb_O_tvalid;
      end
  end

  always @(posedge axi4s_video_aclk or negedge I_rst_n) begin
      if (!I_rst_n) begin
          edge_mode_meta <= 1'b0;
          edge_mode_sync <= 1'b0;
          edge_mode_sel  <= 1'b0;
          enh_mode_meta  <= 1'b0;
          enh_mode_sync  <= 1'b0;
          enh_mode_sel   <= 1'b0;
      end
      else begin
          // HX1P35A SW1/SW2 are active-low: the up position is logical 1.
          edge_mode_meta <= ~I_edge_mode;
          edge_mode_sync <= edge_mode_meta;
          enh_mode_meta  <= ~I_enhance_mode;
          enh_mode_sync  <= enh_mode_meta;

          if (awb_O_tuser) begin
              edge_mode_sel <= edge_mode_sync;
              enh_mode_sel  <= enh_mode_sync;
          end
      end
  end

  assign awb_O_tready = enh_O_tready;
  assign enh_O_tready = O_tready;

  assign isp_mux_tlast  = enh_mode_sel ? enh_O_tlast  : (edge_mode_sel ? enh_O_tlast  : awb_dly_tlast);
  assign isp_mux_tuser  = enh_mode_sel ? enh_O_tuser  : (edge_mode_sel ? enh_O_tuser  : awb_dly_tuser);
  assign isp_mux_tvalid = enh_mode_sel ? enh_O_tvalid : (edge_mode_sel ? enh_O_tvalid : awb_dly_tvalid);
  // SW1+SW2 both active selects the new detection view using normal AWB RGB.
  assign isp_mux_tdata  = (enh_mode_sel && edge_mode_sel) ? awb_dly_tdata :
                         (enh_mode_sel ? enh_O_tdata : (edge_mode_sel ? edge_tdata : awb_dly_tdata));
  assign O_tdata  = awb_O_tdata_128;
  assign O_tlast  = awb_O_tlast    ;
  assign O_tuser  = awb_O_tuser_128    ;
  assign O_tvalid = awb_O_tvalid_128   ;
  
  //assign m_aixs_tready = O_tready;
  //assign O_tdata  = m_aixs_tdata;
  //assign O_tlast  = m_aixs_tlast    ;
  //assign O_tuser  = m_aixs_tuser    ;
  //assign O_tvalid = m_aixs_tvalid   ;
 
 
demosaic #(
    .IMG_HEIGHT          (720 ), // 图像高度
    .IMG_WIDTH           (1280), // 图像宽度
    .data_complete_delay (50  ),
    .BAYER_MODE          ("BGGR")
)
u_demosaic
(
    .I_clk   			(axi4s_video_aclk)	,   // 时钟信号
    .I_rst_n 			(I_rst_n)	,   // 复位信号，低有效
    .axi4s_video_tdata 	(I_tdata)	,  // AXI4-Stream视频数据
    .axi4s_video_tdest 	(I_tdest)	,
    .axi4s_video_tlast 	(I_tlast)	,  // 行结束信号
    .axi4s_video_tvalid	(I_tvalid)	,  // 数据有效信号
    .axi4s_video_tuser 	(I_tuser)	,  // 帧开始信号
    .axi4s_video_tready	(I_tready)	,  // 从模块准备好接受数据
    .O_tlast  			(m_aixs_tlast)	,  // 输出行结束信号
    .O_tuser  			(m_aixs_tuser)	,  // 输出帧开始信号
    .O_tdata  			(m_aixs_tdata)	,  // 输出数据
    .O_tvalid 			(m_aixs_tvalid)	,  // 输出数据有效信号
    .O_tready   		(m_aixs_tready)	   // 输出数据准备好信号
);
 
data128_96 u_data128_96 (
    .I_tdata(m_aixs_tdata),
    .O_tdata(m_aixs_tdata_96)
);

sensor_ae_stats u_meter (
    .clk(axi4s_video_aclk), .rst_n(I_rst_n), .frame_start(m_aixs_tuser),
    .valid(m_aixs_tvalid), .rgb(m_aixs_tdata_96), .ack(I_meter_ack),
    .mean(O_meter_mean), .clipped(O_meter_clipped), .toggle(O_meter_toggle)
);

awb #(
    .IMG_HEIGHT(720 ),
    .IMG_WIDTH (1280)
) u_awb (
    .I_clk   (axi4s_video_aclk),
    .I_rst_n (I_rst_n),
    .I_tlast (m_aixs_tlast),
    .I_tuser (m_aixs_tuser),
    .I_tdata (m_aixs_tdata_96),
    .I_tvalid(m_aixs_tvalid),
    .I_tready(m_aixs_tready),
    .O_tlast (awb_O_tlast ),
    .O_tuser (awb_O_tuser ),
    .O_tdata (awb_O_tdata ),
    .O_tvalid(awb_O_tvalid),
    .O_tready(awb_O_tready)
);

visual_enhance_96 #(
    .IMG_WIDTH (1280),
    .IMG_HEIGHT(720),
    .EDGE_TH   (11'd320),
    .EDGE_BW_TH(11'd80)
) u_visual_enhance_96 (
    .I_clk   (axi4s_video_aclk),
    .I_rst_n (I_rst_n),
    .I_tlast (awb_O_tlast),
    .I_tuser (awb_O_tuser),
    .I_tdata (awb_O_tdata),
    .I_tvalid(awb_O_tvalid),
    .I_tready(awb_O_tready),
    .O_tlast (enh_O_tlast),
    .O_tuser (enh_O_tuser),
    .O_tdata (enh_O_tdata),
    .O_edge_tdata(edge_tdata),
    .O_tvalid(enh_O_tvalid),
    .O_tready(enh_O_tready)
);

    data_96bit_to_128bit u_data_96bit_to_128bit(
        .I_clk              ( axi4s_video_aclk  ),
        .I_rst_n            ( I_rst_n           ),
	
        .I_96b_frame_start  ( isp_mux_tuser     ),
        .I_96b_valid        ( isp_mux_tvalid    ),
        .I_96b_data         ( isp_mux_tdata     ),
	
        .O_128b_frame_start ( awb_O_tuser_128  	),
        .O_128b_valid       ( awb_O_tvalid_128 	),
        .O_128b_data        ( awb_O_tdata_128  	)
    );



//data96_128 u_data96_128 (
//    .I_tdata(awb_O_tdata),
//    .O_tdata(awb_O_tdata_128)
//);
	
endmodule
