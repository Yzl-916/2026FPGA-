module visual_enhance_96 #(
    parameter IMG_WIDTH  = 1280,
    parameter IMG_HEIGHT = 720,
    parameter EDGE_TH    = 11'd320,
    parameter EDGE_BW_TH = 11'd80,
    parameter INK_DIFF_TH = 8'd64
)(
    input               I_clk,
    input               I_rst_n,
    input               I_tlast,
    input               I_tuser,
    input      [95:0]   I_tdata,
    input               I_tvalid,
    input               I_tready,
    output reg          O_tlast,
    output reg          O_tuser,
    output reg [95:0]   O_tdata,
    output reg [95:0]   O_edge_tdata,
    output reg          O_tvalid,
    output              O_tready
);

// V21 cartoon: edge-aware horizontal smoothing, eight shared luminance
// bands blended with the original luminance, and black causal contours.  Four pixels and
// all stream controls still traverse exactly one register stage.  The V20
// Independent coherent Sobel contours drive the black/white edge mode.
assign O_tready = I_tready;

wire [23:0] pix0 = I_tdata[95:72];
wire [23:0] pix1 = I_tdata[71:48];
wire [23:0] pix2 = I_tdata[47:24];
wire [23:0] pix3 = I_tdata[23:0];

// Low-cost luminance approximation: R/4 + G/2 + B/4.
wire [7:0] gray0 = {2'b0,pix0[23:18]} + {1'b0,pix0[15:9]} + {2'b0,pix0[7:2]};
wire [7:0] gray1 = {2'b0,pix1[23:18]} + {1'b0,pix1[15:9]} + {2'b0,pix1[7:2]};
wire [7:0] gray2 = {2'b0,pix2[23:18]} + {1'b0,pix2[15:9]} + {2'b0,pix2[7:2]};
wire [7:0] gray3 = {2'b0,pix3[23:18]} + {1'b0,pix3[15:9]} + {2'b0,pix3[7:2]};

localparam IMG_WIDTH_GRP = (IMG_WIDTH >> 2);
localparam [10:0] X_LAST = IMG_WIDTH_GRP - 1;
localparam [10:0] Y_LAST = IMG_HEIGHT - 1;

// Two line buffers keep two previous rows of paired luminance samples.
wire [8:0] pair_sum0 = {1'b0,gray0} + {1'b0,gray1};
wire [8:0] pair_sum1 = {1'b0,gray2} + {1'b0,gray3};
wire [7:0] pair0 = pair_sum0[8:1];
wire [7:0] pair1 = pair_sum1[8:1];

(* ram_style = "block" *) reg [15:0] line1_mem [0:IMG_WIDTH_GRP-1];
(* ram_style = "block" *) reg [15:0] line2_mem [0:IMG_WIDTH_GRP-1];

reg [10:0] x_grp;
reg [10:0] y_pos;

// A SOF coincident with valid addresses column zero immediately.
wire [10:0] sample_x = I_tuser ? 11'd0 : x_grp;
wire [15:0] top_word = line2_mem[sample_x];
wire [15:0] mid_word = line1_mem[sample_x];
wire [15:0] bot_word = {pair0,pair1};

wire [7:0] top0 = top_word[15:8];
wire [7:0] top1 = top_word[7:0];
wire [7:0] mid0 = mid_word[15:8];
wire [7:0] mid1 = mid_word[7:0];

reg [7:0] top_prev2, top_prev1;
reg [7:0] mid_prev2, mid_prev1;
reg [7:0] bot_prev2, bot_prev1;

// V21.35: coherent Sobel contours, with the original visible stroke width.
// Keep weak consistent boundaries; reject isolated pixels and opposed texture.
// No erosion or half-window thinning is applied to the default edge view.
localparam EDGE_WEAK_TH=(EDGE_BW_TH>16) ? EDGE_BW_TH-16:EDGE_BW_TH;
function [1:0] coherent;
    input [7:0] a0,b0,a1,b1,a2,b2;
    input positive,strong_edge;
    reg signed [8:0] d0,d1,d2;
    reg hi0,hi1,hi2,lo0,lo1,lo2,quiet0,quiet1,quiet2;
    begin
        d0=$signed({1'b0,b0})-$signed({1'b0,a0});
        d1=$signed({1'b0,b1})-$signed({1'b0,a1});
        d2=$signed({1'b0,b2})-$signed({1'b0,a2});
        hi0=positive ? d0>=9'sd16:d0<=-9'sd16;
        hi1=positive ? d1>=9'sd16:d1<=-9'sd16;
        hi2=positive ? d2>=9'sd16:d2<=-9'sd16;
        lo0=positive ? d0>=9'sd8:d0<=-9'sd8;
        lo1=positive ? d1>=9'sd8:d1<=-9'sd8;
        lo2=positive ? d2>=9'sd8:d2<=-9'sd8;
        quiet0=positive ? d0>=-9'sd4:d0<=9'sd4;
        quiet1=positive ? d1>=-9'sd4:d1<=9'sd4;
        quiet2=positive ? d2>=-9'sd4:d2<=9'sd4;
        coherent[0]=((hi0&&hi1)||(hi1&&hi2)||(hi0&&hi2)||(lo0&&lo1&&lo2)) &&
                    (strong_edge||(quiet0&&quiet1&&quiet2));
        // Strong agreement in all three parallel differences can rescue a
        // low-contrast (16-gray-level) boundary below the normal threshold.
        coherent[1]=hi0&&hi1&&hi2;
    end
endfunction

function contour;
    input [7:0] a00,a01,a02,a10,a11,a12,a20,a21,a22;
    reg [9:0] left_sum,right_sum,top_sum,bottom_sum;
    reg [9:0] gx,gy;
    reg [10:0] magnitude;
    reg xp,yp;
    reg [1:0] x_support,y_support,support;
    begin
        left_sum={2'b0,a00}+{1'b0,a10,1'b0}+{2'b0,a20};
        right_sum={2'b0,a02}+{1'b0,a12,1'b0}+{2'b0,a22};
        top_sum={2'b0,a00}+{1'b0,a01,1'b0}+{2'b0,a02};
        bottom_sum={2'b0,a20}+{1'b0,a21,1'b0}+{2'b0,a22};
        xp=right_sum>=left_sum;yp=bottom_sum>=top_sum;
        gx=xp ? right_sum-left_sum:left_sum-right_sum;
        gy=yp ? bottom_sum-top_sum:top_sum-bottom_sum;
        magnitude={1'b0,gx}+{1'b0,gy};
        x_support=coherent(a00,a02,a10,a12,a20,a22,xp,magnitude>=11'd160);
        y_support=coherent(a00,a20,a01,a21,a02,a22,yp,magnitude>=11'd160);
        support=(gx>=gy) ? x_support:y_support;
        contour=((magnitude>=EDGE_BW_TH) && support[0]) ||
                ((magnitude>=EDGE_WEAK_TH) && support[1]);
    end
endfunction

wire window_valid = (y_pos >= 11'd2) && (x_grp != 11'd0) && !I_tuser;
wire edge_bw0 = window_valid && contour(top_prev2,top_prev1,top0,
    mid_prev2,mid_prev1,mid0,bot_prev2,bot_prev1,pair0);
wire edge_bw1 = window_valid && contour(top_prev1,top0,top1,
    mid_prev1,mid0,mid1,bot_prev1,pair0,pair1);

// The Sobel center is one row and one pixel pair behind the current color.
// Use differences at the current pair boundary for the cartoon ink instead
// of painting the delayed Sobel result onto an unrelated current RGB pixel.
// Pair averaging suppresses sub-pair sensor texture without another buffer.
function [7:0] abs_diff8;
    input [7:0] a, b;
    begin
        abs_diff8 = (a >= b) ? (a - b) : (b - a);
    end
endfunction

wire row_start = (x_grp == 11'd0) || I_tuser;
wire previous_row_valid = (y_pos >= 11'd1) && !I_tuser;
wire ink0 = (!row_start && (abs_diff8(pair0,bot_prev1) >= INK_DIFF_TH)) ||
            (previous_row_valid && (abs_diff8(pair0,mid0) >= INK_DIFF_TH));
wire ink1 = (abs_diff8(pair1,pair0) >= INK_DIFF_TH) ||
            (previous_row_valid && (abs_diff8(pair1,mid1) >= INK_DIFF_TH));

// Raw-pixel history, not recursively smoothed history.  A valid gap leaves
// history unchanged.  Row/frame starts replicate the first available pixel,
// so the preceding line or frame cannot bleed into the smoothing stencil.
reg [23:0] previous_pixel1, previous_pixel2;
always @(posedge I_clk or negedge I_rst_n) begin
    if (!I_rst_n) begin
        previous_pixel1 <= 24'd0;
        previous_pixel2 <= 24'd0;
    end else if (I_tvalid) begin
        previous_pixel1 <= pix3;
        previous_pixel2 <= pix2;
    end
end

function near_channel;
    input [7:0] a,b;
    reg [8:0] delta;
    begin
        // Nine-bit subtraction wraps negative differences into 488..511.
        delta = {1'b0,a} - {1'b0,b};
        near_channel = (delta <= 9'd24) || (delta >= 9'd488);
    end
endfunction

function [23:0] smooth_pixel;
    input [23:0] center, left1, left2;
    reg near1, near2;
    reg [9:0] sum_r, sum_g, sum_b;
    begin
        near1 = near_channel(center[23:16],left1[23:16]) &&
                near_channel(center[15:8],left1[15:8]) &&
                near_channel(center[7:0],left1[7:0]);
        near2 = near_channel(center[23:16],left2[23:16]) &&
                near_channel(center[15:8],left2[15:8]) &&
                near_channel(center[7:0],left2[7:0]);
        sum_r = {1'b0,center[23:16],1'b0} + {2'b0,left1[23:16]} + {2'b0,left2[23:16]} + 10'd2;
        sum_g = {1'b0,center[15:8],1'b0}   + {2'b0,left1[15:8]}  + {2'b0,left2[15:8]}  + 10'd2;
        sum_b = {1'b0,center[7:0],1'b0}    + {2'b0,left1[7:0]}   + {2'b0,left2[7:0]}   + 10'd2;
        smooth_pixel = (near1 && near2) ? {sum_r[9:2],sum_g[9:2],sum_b[9:2]} : center;
    end
endfunction

function [23:0] smooth_border_pixel;
    input [23:0] center,left1;
    reg near1;
    reg [8:0] sum_r,sum_g,sum_b;
    begin
        near1=near_channel(center[23:16],left1[23:16]) && near_channel(center[15:8],left1[15:8]) && near_channel(center[7:0],left1[7:0]);
        sum_r={1'b0,center[23:16]}+{1'b0,left1[23:16]}+9'd1;
        sum_g={1'b0,center[15:8]}+{1'b0,left1[15:8]}+9'd1;
        sum_b={1'b0,center[7:0]}+{1'b0,left1[7:0]}+9'd1;
        smooth_border_pixel=near1 ? {sum_r[8:1],sum_g[8:1],sum_b[8:1]} : center;
    end
endfunction

wire [23:0] smooth0 = row_start ? pix0 : smooth_pixel(pix0, previous_pixel1, previous_pixel2);
wire [23:0] smooth1 = row_start ? smooth_border_pixel(pix1,pix0) : smooth_pixel(pix1,pix0,previous_pixel1);
wire [23:0] smooth2 = smooth_pixel(pix2, pix1, pix0);
wire [23:0] smooth3 = smooth_pixel(pix3, pix2, pix1);

// K: quantize shared luminance, blend its band at 50 percent, then restore
// softly quantized color differences with gain 2.  Independent channel tone
// or palette thresholds are avoided so hue does not change at a band edge.
function [7:0] restore_chroma;
    input [7:0] c,y,qy;
    reg signed [10:0] delta,rounded,s;
    begin
        delta=$signed({3'b000,c})-$signed({3'b000,y});
        rounded=(delta+11'sd2)>>>2;
        s=$signed({3'b000,qy})+(rounded<<<3);
        if(s<0) restore_chroma=8'd0;
        else if(s>255) restore_chroma=8'd255;
        else restore_chroma=s[7:0];
    end
endfunction

// Exact fused map: Q(Y) = 0,36,72,108,144,180,216,252 at thresholds
// 18,54,90,126,162,198,234; result = (Q(Y)+Y+1)>>1.
// This combinational map removes the quantize/add carry chain, not a stage.
function [7:0] soft_luma_lut;
    input [7:0] v;
    begin
        case(v)
            8'd0: soft_luma_lut=8'd0;
            8'd1: soft_luma_lut=8'd1;
            8'd2: soft_luma_lut=8'd1;
            8'd3: soft_luma_lut=8'd2;
            8'd4: soft_luma_lut=8'd2;
            8'd5: soft_luma_lut=8'd3;
            8'd6: soft_luma_lut=8'd3;
            8'd7: soft_luma_lut=8'd4;
            8'd8: soft_luma_lut=8'd4;
            8'd9: soft_luma_lut=8'd5;
            8'd10: soft_luma_lut=8'd5;
            8'd11: soft_luma_lut=8'd6;
            8'd12: soft_luma_lut=8'd6;
            8'd13: soft_luma_lut=8'd7;
            8'd14: soft_luma_lut=8'd7;
            8'd15: soft_luma_lut=8'd8;
            8'd16: soft_luma_lut=8'd8;
            8'd17: soft_luma_lut=8'd9;
            8'd18: soft_luma_lut=8'd27;
            8'd19: soft_luma_lut=8'd28;
            8'd20: soft_luma_lut=8'd28;
            8'd21: soft_luma_lut=8'd29;
            8'd22: soft_luma_lut=8'd29;
            8'd23: soft_luma_lut=8'd30;
            8'd24: soft_luma_lut=8'd30;
            8'd25: soft_luma_lut=8'd31;
            8'd26: soft_luma_lut=8'd31;
            8'd27: soft_luma_lut=8'd32;
            8'd28: soft_luma_lut=8'd32;
            8'd29: soft_luma_lut=8'd33;
            8'd30: soft_luma_lut=8'd33;
            8'd31: soft_luma_lut=8'd34;
            8'd32: soft_luma_lut=8'd34;
            8'd33: soft_luma_lut=8'd35;
            8'd34: soft_luma_lut=8'd35;
            8'd35: soft_luma_lut=8'd36;
            8'd36: soft_luma_lut=8'd36;
            8'd37: soft_luma_lut=8'd37;
            8'd38: soft_luma_lut=8'd37;
            8'd39: soft_luma_lut=8'd38;
            8'd40: soft_luma_lut=8'd38;
            8'd41: soft_luma_lut=8'd39;
            8'd42: soft_luma_lut=8'd39;
            8'd43: soft_luma_lut=8'd40;
            8'd44: soft_luma_lut=8'd40;
            8'd45: soft_luma_lut=8'd41;
            8'd46: soft_luma_lut=8'd41;
            8'd47: soft_luma_lut=8'd42;
            8'd48: soft_luma_lut=8'd42;
            8'd49: soft_luma_lut=8'd43;
            8'd50: soft_luma_lut=8'd43;
            8'd51: soft_luma_lut=8'd44;
            8'd52: soft_luma_lut=8'd44;
            8'd53: soft_luma_lut=8'd45;
            8'd54: soft_luma_lut=8'd63;
            8'd55: soft_luma_lut=8'd64;
            8'd56: soft_luma_lut=8'd64;
            8'd57: soft_luma_lut=8'd65;
            8'd58: soft_luma_lut=8'd65;
            8'd59: soft_luma_lut=8'd66;
            8'd60: soft_luma_lut=8'd66;
            8'd61: soft_luma_lut=8'd67;
            8'd62: soft_luma_lut=8'd67;
            8'd63: soft_luma_lut=8'd68;
            8'd64: soft_luma_lut=8'd68;
            8'd65: soft_luma_lut=8'd69;
            8'd66: soft_luma_lut=8'd69;
            8'd67: soft_luma_lut=8'd70;
            8'd68: soft_luma_lut=8'd70;
            8'd69: soft_luma_lut=8'd71;
            8'd70: soft_luma_lut=8'd71;
            8'd71: soft_luma_lut=8'd72;
            8'd72: soft_luma_lut=8'd72;
            8'd73: soft_luma_lut=8'd73;
            8'd74: soft_luma_lut=8'd73;
            8'd75: soft_luma_lut=8'd74;
            8'd76: soft_luma_lut=8'd74;
            8'd77: soft_luma_lut=8'd75;
            8'd78: soft_luma_lut=8'd75;
            8'd79: soft_luma_lut=8'd76;
            8'd80: soft_luma_lut=8'd76;
            8'd81: soft_luma_lut=8'd77;
            8'd82: soft_luma_lut=8'd77;
            8'd83: soft_luma_lut=8'd78;
            8'd84: soft_luma_lut=8'd78;
            8'd85: soft_luma_lut=8'd79;
            8'd86: soft_luma_lut=8'd79;
            8'd87: soft_luma_lut=8'd80;
            8'd88: soft_luma_lut=8'd80;
            8'd89: soft_luma_lut=8'd81;
            8'd90: soft_luma_lut=8'd99;
            8'd91: soft_luma_lut=8'd100;
            8'd92: soft_luma_lut=8'd100;
            8'd93: soft_luma_lut=8'd101;
            8'd94: soft_luma_lut=8'd101;
            8'd95: soft_luma_lut=8'd102;
            8'd96: soft_luma_lut=8'd102;
            8'd97: soft_luma_lut=8'd103;
            8'd98: soft_luma_lut=8'd103;
            8'd99: soft_luma_lut=8'd104;
            8'd100: soft_luma_lut=8'd104;
            8'd101: soft_luma_lut=8'd105;
            8'd102: soft_luma_lut=8'd105;
            8'd103: soft_luma_lut=8'd106;
            8'd104: soft_luma_lut=8'd106;
            8'd105: soft_luma_lut=8'd107;
            8'd106: soft_luma_lut=8'd107;
            8'd107: soft_luma_lut=8'd108;
            8'd108: soft_luma_lut=8'd108;
            8'd109: soft_luma_lut=8'd109;
            8'd110: soft_luma_lut=8'd109;
            8'd111: soft_luma_lut=8'd110;
            8'd112: soft_luma_lut=8'd110;
            8'd113: soft_luma_lut=8'd111;
            8'd114: soft_luma_lut=8'd111;
            8'd115: soft_luma_lut=8'd112;
            8'd116: soft_luma_lut=8'd112;
            8'd117: soft_luma_lut=8'd113;
            8'd118: soft_luma_lut=8'd113;
            8'd119: soft_luma_lut=8'd114;
            8'd120: soft_luma_lut=8'd114;
            8'd121: soft_luma_lut=8'd115;
            8'd122: soft_luma_lut=8'd115;
            8'd123: soft_luma_lut=8'd116;
            8'd124: soft_luma_lut=8'd116;
            8'd125: soft_luma_lut=8'd117;
            8'd126: soft_luma_lut=8'd135;
            8'd127: soft_luma_lut=8'd136;
            8'd128: soft_luma_lut=8'd136;
            8'd129: soft_luma_lut=8'd137;
            8'd130: soft_luma_lut=8'd137;
            8'd131: soft_luma_lut=8'd138;
            8'd132: soft_luma_lut=8'd138;
            8'd133: soft_luma_lut=8'd139;
            8'd134: soft_luma_lut=8'd139;
            8'd135: soft_luma_lut=8'd140;
            8'd136: soft_luma_lut=8'd140;
            8'd137: soft_luma_lut=8'd141;
            8'd138: soft_luma_lut=8'd141;
            8'd139: soft_luma_lut=8'd142;
            8'd140: soft_luma_lut=8'd142;
            8'd141: soft_luma_lut=8'd143;
            8'd142: soft_luma_lut=8'd143;
            8'd143: soft_luma_lut=8'd144;
            8'd144: soft_luma_lut=8'd144;
            8'd145: soft_luma_lut=8'd145;
            8'd146: soft_luma_lut=8'd145;
            8'd147: soft_luma_lut=8'd146;
            8'd148: soft_luma_lut=8'd146;
            8'd149: soft_luma_lut=8'd147;
            8'd150: soft_luma_lut=8'd147;
            8'd151: soft_luma_lut=8'd148;
            8'd152: soft_luma_lut=8'd148;
            8'd153: soft_luma_lut=8'd149;
            8'd154: soft_luma_lut=8'd149;
            8'd155: soft_luma_lut=8'd150;
            8'd156: soft_luma_lut=8'd150;
            8'd157: soft_luma_lut=8'd151;
            8'd158: soft_luma_lut=8'd151;
            8'd159: soft_luma_lut=8'd152;
            8'd160: soft_luma_lut=8'd152;
            8'd161: soft_luma_lut=8'd153;
            8'd162: soft_luma_lut=8'd171;
            8'd163: soft_luma_lut=8'd172;
            8'd164: soft_luma_lut=8'd172;
            8'd165: soft_luma_lut=8'd173;
            8'd166: soft_luma_lut=8'd173;
            8'd167: soft_luma_lut=8'd174;
            8'd168: soft_luma_lut=8'd174;
            8'd169: soft_luma_lut=8'd175;
            8'd170: soft_luma_lut=8'd175;
            8'd171: soft_luma_lut=8'd176;
            8'd172: soft_luma_lut=8'd176;
            8'd173: soft_luma_lut=8'd177;
            8'd174: soft_luma_lut=8'd177;
            8'd175: soft_luma_lut=8'd178;
            8'd176: soft_luma_lut=8'd178;
            8'd177: soft_luma_lut=8'd179;
            8'd178: soft_luma_lut=8'd179;
            8'd179: soft_luma_lut=8'd180;
            8'd180: soft_luma_lut=8'd180;
            8'd181: soft_luma_lut=8'd181;
            8'd182: soft_luma_lut=8'd181;
            8'd183: soft_luma_lut=8'd182;
            8'd184: soft_luma_lut=8'd182;
            8'd185: soft_luma_lut=8'd183;
            8'd186: soft_luma_lut=8'd183;
            8'd187: soft_luma_lut=8'd184;
            8'd188: soft_luma_lut=8'd184;
            8'd189: soft_luma_lut=8'd185;
            8'd190: soft_luma_lut=8'd185;
            8'd191: soft_luma_lut=8'd186;
            8'd192: soft_luma_lut=8'd186;
            8'd193: soft_luma_lut=8'd187;
            8'd194: soft_luma_lut=8'd187;
            8'd195: soft_luma_lut=8'd188;
            8'd196: soft_luma_lut=8'd188;
            8'd197: soft_luma_lut=8'd189;
            8'd198: soft_luma_lut=8'd207;
            8'd199: soft_luma_lut=8'd208;
            8'd200: soft_luma_lut=8'd208;
            8'd201: soft_luma_lut=8'd209;
            8'd202: soft_luma_lut=8'd209;
            8'd203: soft_luma_lut=8'd210;
            8'd204: soft_luma_lut=8'd210;
            8'd205: soft_luma_lut=8'd211;
            8'd206: soft_luma_lut=8'd211;
            8'd207: soft_luma_lut=8'd212;
            8'd208: soft_luma_lut=8'd212;
            8'd209: soft_luma_lut=8'd213;
            8'd210: soft_luma_lut=8'd213;
            8'd211: soft_luma_lut=8'd214;
            8'd212: soft_luma_lut=8'd214;
            8'd213: soft_luma_lut=8'd215;
            8'd214: soft_luma_lut=8'd215;
            8'd215: soft_luma_lut=8'd216;
            8'd216: soft_luma_lut=8'd216;
            8'd217: soft_luma_lut=8'd217;
            8'd218: soft_luma_lut=8'd217;
            8'd219: soft_luma_lut=8'd218;
            8'd220: soft_luma_lut=8'd218;
            8'd221: soft_luma_lut=8'd219;
            8'd222: soft_luma_lut=8'd219;
            8'd223: soft_luma_lut=8'd220;
            8'd224: soft_luma_lut=8'd220;
            8'd225: soft_luma_lut=8'd221;
            8'd226: soft_luma_lut=8'd221;
            8'd227: soft_luma_lut=8'd222;
            8'd228: soft_luma_lut=8'd222;
            8'd229: soft_luma_lut=8'd223;
            8'd230: soft_luma_lut=8'd223;
            8'd231: soft_luma_lut=8'd224;
            8'd232: soft_luma_lut=8'd224;
            8'd233: soft_luma_lut=8'd225;
            8'd234: soft_luma_lut=8'd243;
            8'd235: soft_luma_lut=8'd244;
            8'd236: soft_luma_lut=8'd244;
            8'd237: soft_luma_lut=8'd245;
            8'd238: soft_luma_lut=8'd245;
            8'd239: soft_luma_lut=8'd246;
            8'd240: soft_luma_lut=8'd246;
            8'd241: soft_luma_lut=8'd247;
            8'd242: soft_luma_lut=8'd247;
            8'd243: soft_luma_lut=8'd248;
            8'd244: soft_luma_lut=8'd248;
            8'd245: soft_luma_lut=8'd249;
            8'd246: soft_luma_lut=8'd249;
            8'd247: soft_luma_lut=8'd250;
            8'd248: soft_luma_lut=8'd250;
            8'd249: soft_luma_lut=8'd251;
            8'd250: soft_luma_lut=8'd251;
            8'd251: soft_luma_lut=8'd252;
            8'd252: soft_luma_lut=8'd252;
            8'd253: soft_luma_lut=8'd253;
            8'd254: soft_luma_lut=8'd253;
            8'd255: soft_luma_lut=8'd254;
            default: soft_luma_lut=8'd0;
        endcase
    end
endfunction

function [23:0] cartoon_pixel;
    input [23:0] rgb;
    reg [7:0] r,g,b,maximum,minimum,y,soft_y;
    reg [9:0] y_sum;
    begin
        r=rgb[23:16];g=rgb[15:8];b=rgb[7:0];
        y_sum={2'b0,r}+{1'b0,g,1'b0}+{2'b0,b};
        y=y_sum[9:2];
        soft_y=soft_luma_lut(y);
        maximum=(r>g)?((r>b)?r:b):((g>b)?g:b);
        minimum=(r<g)?((r<b)?r:b):((g<b)?g:b);
        if((maximum-minimum)<=8'd8) cartoon_pixel={soft_y,soft_y,soft_y};
        else cartoon_pixel={restore_chroma(r,y,soft_y),restore_chroma(g,y,soft_y),restore_chroma(b,y,soft_y)};
    end
endfunction

wire [23:0] edge_pix0 = edge_bw0 ? 24'hffffff : 24'h000000;
wire [23:0] edge_pix1 = edge_bw1 ? 24'hffffff : 24'h000000;

wire [23:0] enh0 = ink0 ? 24'h000000 : cartoon_pixel(smooth0);
wire [23:0] enh1 = ink0 ? 24'h000000 : cartoon_pixel(smooth1);
wire [23:0] enh2 = ink1 ? 24'h000000 : cartoon_pixel(smooth2);
wire [23:0] enh3 = ink1 ? 24'h000000 : cartoon_pixel(smooth3);

always @(posedge I_clk or negedge I_rst_n) begin
    if(!I_rst_n) begin
        O_tlast  <= 1'b0;
        O_tuser  <= 1'b0;
        O_tdata  <= 96'd0;
        O_edge_tdata <= 96'd0;
        O_tvalid <= 1'b0;
        x_grp    <= 11'd0;
        y_pos    <= 11'd0;
        top_prev2 <= 8'd0; top_prev1 <= 8'd0;
        mid_prev2 <= 8'd0; mid_prev1 <= 8'd0;
        bot_prev2 <= 8'd0; bot_prev1 <= 8'd0;
        // Keep line memories out of reset to avoid per-bit reset logic.
        // TD 6.2.1 maps these inherited asynchronous-read arrays to DRAM LUTs.
    end else begin
        O_tlast  <= I_tlast;
        O_tuser  <= I_tuser;
        O_tvalid <= I_tvalid;

        if(I_tvalid) begin
            O_tdata <= {enh0,enh1,enh2,enh3};
            O_edge_tdata <= {edge_pix0,edge_pix0,edge_pix1,edge_pix1};

            line2_mem[sample_x] <= mid_word;
            line1_mem[sample_x] <= bot_word;

            top_prev2 <= top0; top_prev1 <= top1;
            mid_prev2 <= mid0; mid_prev1 <= mid1;
            bot_prev2 <= pair0; bot_prev1 <= pair1;

            if(I_tuser) begin
                x_grp <= 11'd1;
                y_pos <= 11'd0;
            end else if(I_tlast || x_grp == X_LAST) begin
                x_grp <= 11'd0;
                if(y_pos == Y_LAST)
                    y_pos <= 11'd0;
                else
                    y_pos <= y_pos + 1'b1;
                top_prev2 <= 8'd0; top_prev1 <= 8'd0;
                mid_prev2 <= 8'd0; mid_prev1 <= 8'd0;
                bot_prev2 <= 8'd0; bot_prev1 <= 8'd0;
            end else begin
                x_grp <= x_grp + 1'b1;
            end
        end else begin
            O_tdata <= 96'd0;
            O_edge_tdata <= 96'd0;
            // SOF is a stream event, including during blanking or after an
            // interrupted frame. Never let a missed SOF rotate border masks
            // into an internal vertical/horizontal black seam.
            if(I_tuser) begin
                x_grp<=0;y_pos<=0;
                top_prev2<=0;top_prev1<=0;mid_prev2<=0;mid_prev1<=0;
                bot_prev2<=0;bot_prev1<=0;
            end else if(I_tlast && x_grp!=0) begin
                x_grp<=0;
                y_pos<=(y_pos==Y_LAST) ? 11'd0:y_pos+1'b1;
                top_prev2<=0;top_prev1<=0;mid_prev2<=0;mid_prev1<=0;
                bot_prev2<=0;bot_prev1<=0;
            end
        end
    end
end

endmodule
