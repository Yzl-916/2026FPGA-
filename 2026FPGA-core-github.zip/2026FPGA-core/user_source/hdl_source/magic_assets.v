// One 2048x8 ERAM: 1024 polar-angle cells + 32 16x16 font glyphs.
// Screen text and the circle are mutually exclusive at each pixel.
module magic_assets #(
    parameter ASSET_FILE="magic_assets.hex"
)(input wire clk,input wire [10:0] address,output reg [7:0] data);
    (* ram_style="bram" *) reg [7:0] rom[0:2047];
    initial $readmemh(ASSET_FILE,rom);
    always @(posedge clk)data<=rom[address];
endmodule
