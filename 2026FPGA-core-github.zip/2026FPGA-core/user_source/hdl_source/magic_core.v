// Frame-atomic green-marker magic. Tracking and key debounce are shared.
// Charge requires fresh observations inside a fixed hover neighbourhood.
module magic_core #(
    parameter CHARGE_SAMPLES=48,
    parameter STALE_FRAMES=8
)(
    input wire clk,rst_n,frame_tick,allowed,key_press,
    input wire observation_update,observation_valid,
    input wire [10:0] observation_x,
    input wire [9:0] observation_y,
    input wire [7:0] observation_id,
    output reg requested,cursor_valid,
    output reg [8:0] cursor_x,wave_x,
    output reg [7:0] cursor_y,wave_y,
    output reg [6:0] phase,
    output reg [5:0] charge,
    output wire armed,
    output reg wave_active,
    output reg [5:0] wave_age
);
    reg pending,key_pending,packet_valid;
    reg [8:0] packet_x,anchor_x;
    reg [7:0] packet_y,packet_id,active_id,anchor_y;
    reg [3:0] stale;
    reg phase_div;
    assign armed=charge==CHARGE_SAMPLES;
    wire [8:0] dx=packet_x>=cursor_x?packet_x-cursor_x:cursor_x-packet_x;
    wire [7:0] dy=packet_y>=cursor_y?packet_y-cursor_y:cursor_y-packet_y;
    wire [8:0] ax=packet_x>=anchor_x?packet_x-anchor_x:anchor_x-packet_x;
    wire [7:0] ay=packet_y>=anchor_y?packet_y-anchor_y:anchor_y-packet_y;
    wire continuous=cursor_valid && packet_id==active_id && dx<=96 && dy<=96;
    wire cast=continuous && armed && (dx>=12 || dy>=12) && !wave_active;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin pending<=0;packet_valid<=0;packet_x<=0;packet_y<=0;packet_id<=0;key_pending<=0;end
        else begin
            if(frame_tick)begin pending<=0;key_pending<=0;end
            if(key_press && allowed && !frame_tick)key_pending<=1;
            if(!allowed)key_pending<=0;
            if(!requested)begin pending<=0;packet_valid<=0;end
            else if(observation_update)begin
                pending<=1;packet_valid<=observation_valid && observation_x<1280 && observation_y<720;
                packet_x<=observation_x[10:2];packet_y<=observation_y[9:2];packet_id<=observation_id;
            end
        end
    end
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            requested<=0;cursor_valid<=0;cursor_x<=0;cursor_y<=0;phase<=0;phase_div<=0;
            charge<=0;wave_active<=0;wave_age<=0;wave_x<=0;wave_y<=0;
            stale<=0;active_id<=0;anchor_x<=0;anchor_y<=0;
        end else if(frame_tick)begin
            if(!allowed || key_pending || key_press)begin
                requested<=allowed && !requested;cursor_valid<=0;charge<=0;stale<=0;
                wave_active<=0;wave_age<=0;phase<=0;phase_div<=0;
            end else if(requested)begin
                phase_div<=!phase_div;if(phase_div)phase<=phase+1'b1;
                if(wave_active)begin
                    if(wave_age==31)begin wave_active<=0;wave_age<=0;end
                    else wave_age<=wave_age+1'b1;
                end
                if(pending)begin
                    stale<=0;
                    if(packet_valid)begin
                        cursor_valid<=1;cursor_x<=packet_x;cursor_y<=packet_y;active_id<=packet_id;
                        if(!continuous || wave_active)begin charge<=0;anchor_x<=packet_x;anchor_y<=packet_y;end
                        else if(cast)begin
                            charge<=0;wave_active<=1;wave_age<=0;wave_x<=packet_x;wave_y<=packet_y;
                            anchor_x<=packet_x;anchor_y<=packet_y;
                        end else if(!armed)begin
                            if(ax<=6 && ay<=6)charge<=charge+1'b1;
                            else begin charge<=0;anchor_x<=packet_x;anchor_y<=packet_y;end
                        end
                    end else begin cursor_valid<=0;charge<=0;end
                end else begin
                    if(stale<STALE_FRAMES)stale<=stale+1'b1;
                    if(stale>=STALE_FRAMES-1)begin cursor_valid<=0;charge<=0;end
                end
            end
        end
    end
endmodule
