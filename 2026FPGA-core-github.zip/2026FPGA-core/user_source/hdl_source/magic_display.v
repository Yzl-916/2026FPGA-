// Three-clock video pipeline, including one synchronous packed asset read.
// Quarter-pixel geometry uses small LUT squares; no multipliers/frame buffer.
module magic_display #(parameter IMG_WIDTH=1280)(
    input wire clk,rst_n,vs,de,
    input wire [23:0] rgb,
    input wire requested,cursor_valid,armed,wave_active,
    input wire [8:0] cursor_x,wave_x,
    input wire [7:0] cursor_y,wave_y,
    input wire [6:0] phase,
    input wire [5:0] charge,wave_age,
    output reg out_vs,out_de,
    output reg [23:0] out_rgb
);
    reg [10:0] x;reg [9:0] y;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin x<=0;y<=0;end
        else if(vs)begin x<=0;y<=0;end
        else if(de)begin if(x==IMG_WIDTH-1)begin x<=0;y<=y+1'b1;end else x<=x+1'b1;end
    end
    wire [8:0] qx=x[10:2];wire [7:0] qy=y[9:2];
    wire sx=qx<cursor_x,sy=qy<cursor_y;
    wire [8:0] dx=sx?cursor_x-qx:qx-cursor_x;
    wire [7:0] dy=sy?cursor_y-qy:qy-cursor_y;
    wire [8:0] wx=qx<wave_x?wave_x-qx:qx-wave_x;
    wire [7:0] wy=qy<wave_y?wave_y-qy:qy-wave_y;
    // HUD occupies a fixed rectangle; no circle lookup is needed there.
    reg panel,text_hit,bar,bar_fill;reg [4:0] glyph;
    reg [10:0] tx;reg [9:0] ty;reg [4:0] col;
    always @*begin
        panel=0;text_hit=0;bar=0;bar_fill=0;glyph=0;tx=0;ty=0;col=0;
        if(requested && x>=640 && x<1264 && y>=16 && y<144)begin
            panel=1;tx=x-656;ty=y-24;col=tx[9:5];
            if(x>=656 && x<1232 && y>=24 && y<56)begin
                text_hit=1;
                case(col)
                    0:glyph=1;1:glyph=2;2:glyph=3;3:glyph=4;4:glyph=5;
                    12:glyph=28;13:glyph=29;15:glyph=27;16:glyph=17;
                    default:glyph=0;
                endcase
            end
            if(x>=656 && x<1232 && y>=64 && y<96)begin
                text_hit=1;ty=y-64;
                if(!cursor_valid)case(col)
                    0:glyph=16;1:glyph=17;2:glyph=18;3:glyph=19;4:glyph=20;5:glyph=21;6:glyph=22;
                    default:glyph=0;
                endcase
                else if(wave_active)case(col)
                    0:glyph=14;1:glyph=15;2:glyph=12;3:glyph=13;
                    default:glyph=0;
                endcase
                else if(armed)case(col)
                    0:glyph=8;1:glyph=9;2:glyph=30;3:glyph=31;
                    5:glyph=10;6:glyph=11;7:glyph=12;8:glyph=13;
                    default:glyph=0;
                endcase
                else case(col)
                    0:glyph=6;1:glyph=7;2:glyph=8;3:glyph=9;
                    default:glyph=0;
                endcase
            end
            if(x>=656 && x<1040 && y>=112 && y<128)begin
                bar=1;bar_fill=(x-656)<{charge,3'b000};
            end
        end
    end
    wire [10:0] asset_addr=panel?{1'b1,glyph,ty[4:1],tx[4]}:{1'b0,dy[5:1],dx[5:1]};
    wire [7:0] asset_data;
    magic_assets assets(.clk(clk),.address(asset_addr),.data(asset_data));
    // BEGIN GENERATED LUTS
function [11:0] square6; input [5:0] a; begin case(a)
6'd0:square6=12'd0;
6'd1:square6=12'd1;
6'd2:square6=12'd4;
6'd3:square6=12'd9;
6'd4:square6=12'd16;
6'd5:square6=12'd25;
6'd6:square6=12'd36;
6'd7:square6=12'd49;
6'd8:square6=12'd64;
6'd9:square6=12'd81;
6'd10:square6=12'd100;
6'd11:square6=12'd121;
6'd12:square6=12'd144;
6'd13:square6=12'd169;
6'd14:square6=12'd196;
6'd15:square6=12'd225;
6'd16:square6=12'd256;
6'd17:square6=12'd289;
6'd18:square6=12'd324;
6'd19:square6=12'd361;
6'd20:square6=12'd400;
6'd21:square6=12'd441;
6'd22:square6=12'd484;
6'd23:square6=12'd529;
6'd24:square6=12'd576;
6'd25:square6=12'd625;
6'd26:square6=12'd676;
6'd27:square6=12'd729;
6'd28:square6=12'd784;
6'd29:square6=12'd841;
6'd30:square6=12'd900;
6'd31:square6=12'd961;
6'd32:square6=12'd1024;
6'd33:square6=12'd1089;
6'd34:square6=12'd1156;
6'd35:square6=12'd1225;
6'd36:square6=12'd1296;
6'd37:square6=12'd1369;
6'd38:square6=12'd1444;
6'd39:square6=12'd1521;
6'd40:square6=12'd1600;
6'd41:square6=12'd1681;
6'd42:square6=12'd1764;
6'd43:square6=12'd1849;
6'd44:square6=12'd1936;
6'd45:square6=12'd2025;
6'd46:square6=12'd2116;
6'd47:square6=12'd2209;
6'd48:square6=12'd2304;
6'd49:square6=12'd2401;
6'd50:square6=12'd2500;
6'd51:square6=12'd2601;
6'd52:square6=12'd2704;
6'd53:square6=12'd2809;
6'd54:square6=12'd2916;
6'd55:square6=12'd3025;
6'd56:square6=12'd3136;
6'd57:square6=12'd3249;
6'd58:square6=12'd3364;
6'd59:square6=12'd3481;
6'd60:square6=12'd3600;
6'd61:square6=12'd3721;
6'd62:square6=12'd3844;
6'd63:square6=12'd3969;
endcase end endfunction
function [11:0] star_low; input [4:0] a; begin case(a)
5'd0:star_low=12'd841;
5'd1:star_low=12'd707;
5'd2:star_low=12'd605;
5'd3:star_low=12'd525;
5'd4:star_low=12'd461;
5'd5:star_low=12'd410;
5'd6:star_low=12'd369;
5'd7:star_low=12'd335;
5'd8:star_low=12'd306;
5'd9:star_low=12'd283;
5'd10:star_low=12'd263;
5'd11:star_low=12'd246;
5'd12:star_low=12'd232;
5'd13:star_low=12'd221;
5'd14:star_low=12'd211;
5'd15:star_low=12'd203;
5'd16:star_low=12'd196;
5'd17:star_low=12'd203;
5'd18:star_low=12'd211;
5'd19:star_low=12'd221;
5'd20:star_low=12'd232;
5'd21:star_low=12'd246;
5'd22:star_low=12'd263;
5'd23:star_low=12'd283;
5'd24:star_low=12'd306;
5'd25:star_low=12'd335;
5'd26:star_low=12'd369;
5'd27:star_low=12'd410;
5'd28:star_low=12'd461;
5'd29:star_low=12'd525;
5'd30:star_low=12'd605;
5'd31:star_low=12'd707;
endcase end endfunction
function [11:0] star_high; input [4:0] a; begin case(a)
5'd0:star_high=12'd1089;
5'd1:star_high=12'd936;
5'd2:star_high=12'd818;
5'd3:star_high=12'd724;
5'd4:star_high=12'd649;
5'd5:star_high=12'd588;
5'd6:star_high=12'd538;
5'd7:star_high=12'd497;
5'd8:star_high=12'd462;
5'd9:star_high=12'd433;
5'd10:star_high=12'd409;
5'd11:star_high=12'd388;
5'd12:star_high=12'd370;
5'd13:star_high=12'd355;
5'd14:star_high=12'd343;
5'd15:star_high=12'd333;
5'd16:star_high=12'd324;
5'd17:star_high=12'd333;
5'd18:star_high=12'd343;
5'd19:star_high=12'd355;
5'd20:star_high=12'd370;
5'd21:star_high=12'd388;
5'd22:star_high=12'd409;
5'd23:star_high=12'd433;
5'd24:star_high=12'd462;
5'd25:star_high=12'd497;
5'd26:star_high=12'd538;
5'd27:star_high=12'd588;
5'd28:star_high=12'd649;
5'd29:star_high=12'd724;
5'd30:star_high=12'd818;
5'd31:star_high=12'd936;
endcase end endfunction
    // END GENERATED LUTS
    reg vs0,de0,vs1,de1;reg [23:0] rgb0,rgb1;
    reg [5:0] dx0,dy0;reg [8:0] wx0,wy0;reg sx0,sy0,near0,near1;
    reg panel0,text0,bar0,fill0,panel1,font1,bar1,fill1;reg [2:0] bit0;
    reg armed0,armed1,wave0,wave1;
    reg [6:0] phase0;reg [7:0] progress0;reg [8:0] radius0,radius1;
    reg [12:0] r2;reg [9:0] wave_metric;
    reg [11:0] star_lo,star_hi;
    reg [6:0] forward1,reverse1;reg progress1;
    wire [6:0] angle=sy0?(sx0?(7'd64+asset_data[5:0]):(7'd0-asset_data[5:0])):
                          (sx0?(7'd64-asset_data[5:0]):{1'b0,asset_data[5:0]});
    wire [6:0] forward=angle-phase0,reverse=angle+phase0;
    // BEGIN final_work ERAM GEOMETRY
    // Exact lookup values, using two dual-read ROMs. Read positions keep
    // the original three-stage pixel transport and all original geometry.
    (* ram_style="bram" *) reg [11:0] square_rom[0:63];
    (* ram_style="bram" *) reg [11:0] star_rom[0:63];
    reg [11:0] square_x0,square_y0;
    initial begin
        square_rom[0]=12'd0;star_rom[0]=12'd841;
        square_rom[1]=12'd1;star_rom[1]=12'd707;
        square_rom[2]=12'd4;star_rom[2]=12'd605;
        square_rom[3]=12'd9;star_rom[3]=12'd525;
        square_rom[4]=12'd16;star_rom[4]=12'd461;
        square_rom[5]=12'd25;star_rom[5]=12'd410;
        square_rom[6]=12'd36;star_rom[6]=12'd369;
        square_rom[7]=12'd49;star_rom[7]=12'd335;
        square_rom[8]=12'd64;star_rom[8]=12'd306;
        square_rom[9]=12'd81;star_rom[9]=12'd283;
        square_rom[10]=12'd100;star_rom[10]=12'd263;
        square_rom[11]=12'd121;star_rom[11]=12'd246;
        square_rom[12]=12'd144;star_rom[12]=12'd232;
        square_rom[13]=12'd169;star_rom[13]=12'd221;
        square_rom[14]=12'd196;star_rom[14]=12'd211;
        square_rom[15]=12'd225;star_rom[15]=12'd203;
        square_rom[16]=12'd256;star_rom[16]=12'd196;
        square_rom[17]=12'd289;star_rom[17]=12'd203;
        square_rom[18]=12'd324;star_rom[18]=12'd211;
        square_rom[19]=12'd361;star_rom[19]=12'd221;
        square_rom[20]=12'd400;star_rom[20]=12'd232;
        square_rom[21]=12'd441;star_rom[21]=12'd246;
        square_rom[22]=12'd484;star_rom[22]=12'd263;
        square_rom[23]=12'd529;star_rom[23]=12'd283;
        square_rom[24]=12'd576;star_rom[24]=12'd306;
        square_rom[25]=12'd625;star_rom[25]=12'd335;
        square_rom[26]=12'd676;star_rom[26]=12'd369;
        square_rom[27]=12'd729;star_rom[27]=12'd410;
        square_rom[28]=12'd784;star_rom[28]=12'd461;
        square_rom[29]=12'd841;star_rom[29]=12'd525;
        square_rom[30]=12'd900;star_rom[30]=12'd605;
        square_rom[31]=12'd961;star_rom[31]=12'd707;
        square_rom[32]=12'd1024;star_rom[32]=12'd1089;
        square_rom[33]=12'd1089;star_rom[33]=12'd936;
        square_rom[34]=12'd1156;star_rom[34]=12'd818;
        square_rom[35]=12'd1225;star_rom[35]=12'd724;
        square_rom[36]=12'd1296;star_rom[36]=12'd649;
        square_rom[37]=12'd1369;star_rom[37]=12'd588;
        square_rom[38]=12'd1444;star_rom[38]=12'd538;
        square_rom[39]=12'd1521;star_rom[39]=12'd497;
        square_rom[40]=12'd1600;star_rom[40]=12'd462;
        square_rom[41]=12'd1681;star_rom[41]=12'd433;
        square_rom[42]=12'd1764;star_rom[42]=12'd409;
        square_rom[43]=12'd1849;star_rom[43]=12'd388;
        square_rom[44]=12'd1936;star_rom[44]=12'd370;
        square_rom[45]=12'd2025;star_rom[45]=12'd355;
        square_rom[46]=12'd2116;star_rom[46]=12'd343;
        square_rom[47]=12'd2209;star_rom[47]=12'd333;
        square_rom[48]=12'd2304;star_rom[48]=12'd324;
        square_rom[49]=12'd2401;star_rom[49]=12'd333;
        square_rom[50]=12'd2500;star_rom[50]=12'd343;
        square_rom[51]=12'd2601;star_rom[51]=12'd355;
        square_rom[52]=12'd2704;star_rom[52]=12'd370;
        square_rom[53]=12'd2809;star_rom[53]=12'd388;
        square_rom[54]=12'd2916;star_rom[54]=12'd409;
        square_rom[55]=12'd3025;star_rom[55]=12'd433;
        square_rom[56]=12'd3136;star_rom[56]=12'd462;
        square_rom[57]=12'd3249;star_rom[57]=12'd497;
        square_rom[58]=12'd3364;star_rom[58]=12'd538;
        square_rom[59]=12'd3481;star_rom[59]=12'd588;
        square_rom[60]=12'd3600;star_rom[60]=12'd649;
        square_rom[61]=12'd3721;star_rom[61]=12'd724;
        square_rom[62]=12'd3844;star_rom[62]=12'd818;
        square_rom[63]=12'd3969;star_rom[63]=12'd936;
    end
    always @(posedge clk)begin
        square_x0<=square_rom[dx[5:0]];square_y0<=square_rom[dy[5:0]];
        star_lo<=star_rom[{1'b0,reverse[4:0]}];star_hi<=star_rom[{1'b1,reverse[4:0]}];
    end
    // END final_work ERAM GEOMETRY
    wire [8:0] wave_diff=wave_metric-radius1+9'd1;
    wire [8:0] echo_diff=wave_metric-radius1+9'd13;
    reg [23:0] composed;
    reg ring,rune,star,core,glow,progress_ring;
    always @*begin
        ring=0;rune=0;star=0;core=0;glow=0;progress_ring=0;composed=rgb1;
        if(near1)begin
            ring=(r2>=2209 && r2<=2304) || (r2>=1849 && r2<=1936 && forward1[4:3]!=3) || (r2>=1024 && r2<=1089);
            rune=(r2>=1225 && r2<=1681) &&
                ((forward1[2:0]==1)||(forward1[2:0]==6)||
                 (r2>=1369 && r2<=1444 && forward1[2:0]>=2 && forward1[2:0]<=5)||
                 (r2<=1296 && forward1[4] && forward1[2:0]<=4));
            star=r2>=star_lo && r2<=star_hi;
            core=r2<=16 || (r2>=144 && r2<=169 && reverse1[3:2]!=3);
            glow=(r2>=2116 && r2<=2401)||(r2>=961 && r2<=1156)||r2<=64;
            progress_ring=r2>=2500 && r2<=2601 && progress1;
            if(glow)composed=armed1?{1'b0,rgb1[23:17],1'b0,rgb1[15:9],1'b0,rgb1[7:1]}+24'h604018:{1'b0,rgb1[23:17],1'b0,rgb1[15:9],1'b0,rgb1[7:1]}+24'h182f58;
            if(star)composed=armed1?24'hffb346:24'hac89ff;
            if(rune)composed=armed1?24'hffe0a0:24'h51eadc;
            if(ring)composed=armed1?24'hffc65d:24'h5bbfff;
            if(core || progress_ring)composed=armed1?24'hfff3bf:24'hc5fff4;
        end
        if(wave1 && wave_metric<512)begin
            if(wave_diff<=3)composed=24'hfff2b2;
            else if(echo_diff<=2)composed=24'h72eaff;
            else if(wave_diff<=6)composed={1'b0,rgb1[23:17],1'b0,rgb1[15:9],1'b0,rgb1[7:1]}+24'h384050;
        end
        if(panel1)begin
            composed=font1?24'hd4fff6:24'h102638;
            if(bar1)composed=fill1?(armed1?24'hffce64:24'h54dacd):24'h284657;
        end
    end
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            vs0<=0;de0<=0;vs1<=0;de1<=0;out_vs<=0;out_de<=0;rgb0<=0;rgb1<=0;out_rgb<=0;
            dx0<=0;dy0<=0;wx0<=0;wy0<=0;sx0<=0;sy0<=0;near0<=0;near1<=0;
            panel0<=0;text0<=0;bar0<=0;fill0<=0;panel1<=0;font1<=0;bar1<=0;fill1<=0;bit0<=0;
            armed0<=0;armed1<=0;wave0<=0;wave1<=0;phase0<=0;progress0<=0;radius0<=0;radius1<=0;
            r2<=0;wave_metric<=0;forward1<=0;reverse1<=0;progress1<=0;
        end else begin
            vs0<=vs;de0<=de;rgb0<=rgb;dx0<=dx[5:0];dy0<=dy[5:0];sx0<=sx;sy0<=sy;
            near0<=requested && cursor_valid && dx<64 && dy<64 && !panel;
            wx0<=wx;wy0<={1'b0,wy};wave0<=requested && wave_active;
            radius0<={wave_age,3'b000}+9'd16;
            panel0<=panel;text0<=text_hit;bar0<=bar;fill0<=bar_fill;bit0<=tx[3:1];
            armed0<=armed;phase0<=phase;progress0<=armed?8'd128:({2'b0,charge}<<1)+{3'b0,charge[5:1]}+{5'b0,charge[5:3]};
            vs1<=vs0;de1<=de0;rgb1<=rgb0;near1<=near0;
            r2<={1'b0,square_x0}+{1'b0,square_y0};
            wave_metric<=wx0>=wy0?{1'b0,wx0}+{2'b0,wy0[8:1]}:{1'b0,wy0}+{2'b0,wx0[8:1]};
            wave1<=wave0;radius1<=radius0;armed1<=armed0;
            forward1<=forward;reverse1<=reverse;
            progress1<={1'b0,angle}<progress0;
            panel1<=panel0;font1<=text0 && asset_data[7-bit0];bar1<=bar0;fill1<=fill0;
            out_vs<=vs1;out_de<=de1;out_rgb<=composed;
        end
    end
endmodule
