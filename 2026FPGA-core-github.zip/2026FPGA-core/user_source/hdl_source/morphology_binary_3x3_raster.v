// Centered, full-frame 3x3 square morphology, binary white foreground.
// Outside-frame samples are zero for BOTH operations. No cropped rows/columns.
// One pixel/clock, contiguous DE within a row, fixed LINE_TOTAL pixel clocks.
// At least one horizontal blank and one vertical padding line are required.
// Input center sampled at E0 -> result at E0+LINE_TOTAL+2.
module morphology_binary_3x3_raster #(
    parameter integer IMG_WIDTH=1280,
    parameter integer IMG_HEIGHT=720,
    parameter integer LINE_TOTAL=1650
)(
    input wire clk,rst_n,vs,de,pixel,
    output reg eroded,dilated,valid,
    output reg [10:0] out_x,
    output reg [9:0] out_y
);
    reg [10:0] x;
    reg [9:0] y;
    reg right_pending;
    reg [9:0] right_y;
    reg [1:0] flush_state;
    reg [11:0] bottom_wait;
    reg [10:0] bottom_x;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            x<=0;y<=0;right_pending<=0;right_y<=0;
            flush_state<=0;bottom_wait<=0;bottom_x<=0;
        end else begin
            right_pending<=0;
            if(vs) begin x<=0;y<=0;end
            else if(de) begin
                if(x==IMG_WIDTH-1) begin
                    x<=0;y<=y+1'b1;right_pending<=1;right_y<=y;
                end else x<=x+1'b1;
            end
            if(de && !vs && x==IMG_WIDTH-1 && y==IMG_HEIGHT-1) begin
                flush_state<=1;bottom_wait<=LINE_TOTAL-IMG_WIDTH;bottom_x<=0;
            end else if(flush_state==1) begin
                if(bottom_wait!=0) bottom_wait<=bottom_wait-1'b1;
                else begin flush_state<=2;bottom_x<=1;end
            end else if(flush_state==2) begin
                if(bottom_x==IMG_WIDTH) flush_state<=0;
                else bottom_x<=bottom_x+1'b1;
            end
        end
    end

    reg tick,real_pixel;
    reg [10:0] op_x;
    reg [9:0] op_y;
    reg op_pixel;
    always @* begin
        tick=0;real_pixel=0;op_x=0;op_y=0;op_pixel=0;
        if(de && !vs) begin
            tick=1;real_pixel=1;op_x=x;op_y=y;op_pixel=pixel;
        end else if(right_pending) begin
            tick=1;op_x=IMG_WIDTH;op_y=right_y;
        end else if(flush_state==1 && bottom_wait==0) begin
            tick=1;op_x=0;op_y=IMG_HEIGHT;
        end else if(flush_state==2) begin
            tick=1;op_x=bottom_x;op_y=IMG_HEIGHT;
        end
    end

    // Both previous rows are packed into ONE 2-bit-wide dual-port RAM.
    // Read x on E0, write the updated pair on E1. Distinct addresses are used
    // during a contiguous line; no vendor read-during-write mode is assumed.
    (* ram_style="bram" *) reg [1:0] history [0:IMG_WIDTH-1];
    reg [1:0] history_a;
    reg tick_a,real_a,pixel_a;
    reg [10:0] x_a;
    reg [9:0] y_a;
    always @(posedge clk) begin
        if(rst_n && tick && op_x<IMG_WIDTH) history_a<=history[op_x];
        if(rst_n && tick_a && real_a) history[x_a]<={history_a[0],pixel_a};
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin tick_a<=0;real_a<=0;pixel_a<=0;x_a<=0;y_a<=0;end
        else begin
            tick_a<=tick;real_a<=real_pixel;pixel_a<=op_pixel;x_a<=op_x;y_a<=op_y;
        end
    end
    wire top_a=(x_a<IMG_WIDTH && y_a>=2) ? history_a[1]:1'b0;
    wire mid_a=(x_a<IMG_WIDTH && y_a>=1) ? history_a[0]:1'b0;
    wire col_and=top_a & mid_a & pixel_a;
    wire col_or=top_a | mid_a | pixel_a;
    reg and_left2,and_left1,or_left2,or_left1;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            and_left2<=0;and_left1<=0;or_left2<=0;or_left1<=0;
            eroded<=0;dilated<=0;valid<=0;out_x<=0;out_y<=0;
        end else begin
            valid<=tick_a && x_a>=1 && y_a>=1;
            if(tick_a) begin
                if(x_a==0) begin
                    and_left2<=0;and_left1<=col_and;or_left2<=0;or_left1<=col_or;
                end else begin
                    and_left2<=and_left1;and_left1<=col_and;
                    or_left2<=or_left1;or_left1<=col_or;
                end
                eroded<=and_left2 & and_left1 & col_and;
                dilated<=or_left2 | or_left1 | col_or;
                out_x<=x_a-1'b1;out_y<=y_a-1'b1;
            end
        end
    end
endmodule
