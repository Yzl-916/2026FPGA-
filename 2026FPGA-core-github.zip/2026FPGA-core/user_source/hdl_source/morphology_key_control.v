// Active-low KEY4: one press advances BYPASS -> ERODE -> DILATE -> BYPASS.
// A stable release is required after reset; holding the key never repeats.
module morphology_key_control #(
    parameter integer DEBOUNCE_CYCLES=750000
)(
    input wire clk,rst_n,key_n,enable,
    output reg [1:0] selected_mode
);
    localparam integer DBW=DEBOUNCE_CYCLES<=1 ? 1:$clog2(DEBOUNCE_CYCLES);
    reg key_meta,key_sync,key_level,armed;
    reg [DBW-1:0] counter;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            key_meta<=0;key_sync<=0;key_level<=0;armed<=0;counter<=0;selected_mode<=0;
        end else begin
            key_meta<=key_n;key_sync<=key_meta;
            if(!enable) begin counter<=0;key_level<=0;armed<=0;end
            else if(key_sync==key_level) counter<=0;
            else if(counter==DEBOUNCE_CYCLES-1) begin
                counter<=0;key_level<=key_sync;
                if(key_sync) armed<=1;
                else if(armed) begin
                    selected_mode<=selected_mode==2 ? 0:selected_mode+1'b1;
                    armed<=0;
                end
            end else counter<=counter+1'b1;
        end
    end
endmodule
