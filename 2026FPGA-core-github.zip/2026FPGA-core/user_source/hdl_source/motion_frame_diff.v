// V17 fixed-camera motion: exact 8x8 luma means -> previous distinct-frame
// difference -> center-preserving 3x3 support filter -> double-buffered mask.
// No pixels from logos, text or detection overlays enter this module.
module motion_frame_diff #(
    parameter IMG_WIDTH=1280, IMG_HEIGHT=720,
    parameter DIFF_THRESHOLD=16, MIN_CELLS=6,
    parameter SCENE_PERCENT=45
)(
    input wire clk, rst_n, vs, de,
    input wire [7:0] luma,
    input wire [1:0] frame_mode_async,
    input wire [48:0] frame_tag_async,
    output reg [10:0] x,
    output reg [9:0] y,
    output wire display_enable,
    output wire motion_pixel,
    output reg [1:0] display_state, // 0=warming,1=still,2=motion,3=scene change
    output reg [14:0] motion_cells
);
    localparam GW=IMG_WIDTH/8, GH=IMG_HEIGHT/8, CELLS=GW*GH;
    localparam SCENE_LIMIT=CELLS*SCENE_PERCENT/100;
    reg [1:0] mode_meta,mode_sync;
    reg [48:0] tag_meta,tag_sync;
    reg vs_d,first_pending,frame_enabled,process_frame,frame_reference;
    reg bg_valid,last_tag_valid,frame_completed,frame_bad;
    reg [47:0] last_tag,working_tag;
    reg [13:0] tile_base;
    wire first_pixel=de && first_pending && !vs;
    wire eligible=tag_sync[48] && mode_sync==2'd3;
    wire fresh=eligible && (!last_tag_valid || tag_sync[47:0]!=last_tag);
    wire process_now=first_pending ? fresh:process_frame;
    assign display_enable=first_pending ? eligible:frame_enabled;

    // These arrays have synchronous read/write ports and no reset tree.
    // Validity/row guards prevent their uninitialized contents being consumed.
    reg [13:0] row_sums[0:GW-1];
    reg [7:0] previous_luma[0:CELLS-1];
    reg [1:0] history[0:GW-1];
    reg mask0[0:CELLS-1],mask1[0:CELLS-1];
    reg [13:0] row_read;
    reg [7:0] previous_read;
    reg [1:0] history_read;
    reg mask_read0,mask_read1;
    reg read_bank,write_bank;
    assign motion_pixel=read_bank ? mask_read1:mask_read0;
    wire [13:0] pixel_cell=tile_base+{6'd0,x[10:3]};

    reg [10:0] horizontal_sum,line_sum;
    reg line_pending,line_first,line_last;
    reg [7:0] line_col;
    reg [6:0] line_row;
    reg [13:0] line_addr;
    wire line_event=de && !vs && y<IMG_HEIGHT && process_now && x[2:0]==7;
    wire [13:0] accumulated=(line_first ? 14'd0:row_read)+{3'd0,line_sum};
    reg block_pending;
    reg [7:0] block_avg,block_col;
    reg [6:0] block_row;
    reg [13:0] block_addr;
    wire [7:0] abs_difference=(block_avg>=previous_read) ?
                              block_avg-previous_read:previous_read-block_avg;
    wire raw_bit=frame_reference && abs_difference>=DIFF_THRESHOLD;

    reg diff_pending,diff_bit;
    reg [7:0] diff_col;
    reg [6:0] diff_row;
    reg [13:0] diff_addr;
    reg [2:0] left_column,middle_column;
    wire [2:0] new_column={(diff_row>=2 ? history_read[1]:1'b0),
                           (diff_row>=1 ? history_read[0]:1'b0),diff_bit};
    function [3:0] pop3;
        input [2:0] bits;
        begin pop3={3'd0,bits[0]}+{3'd0,bits[1]}+{3'd0,bits[2]};end
    endfunction
    wire [3:0] neighbors=pop3(left_column)+pop3(middle_column)+pop3(new_column);
    wire supported=middle_column[1] && neighbors>=3;
    wire right_supported=middle_column[1] && (pop3(left_column)+pop3(middle_column))>=3;
    reg right_pending;
    reg [6:0] right_row;
    reg [13:0] right_addr;
    reg bottom_active,bottom_phase;
    reg [7:0] bottom_col;
    wire bottom_request=bottom_active && !bottom_phase;
    reg mask_we,mask_value,mask_bank;
    reg [13:0] mask_addr;
    reg [14:0] raw_count,filtered_count;
    reg finish_pending,result_ready;
    reg [1:0] pending_state;
    reg [14:0] pending_cells;

    always @(posedge clk) begin
        if(line_event) row_read<=row_sums[x[10:3]];
        if(line_pending) begin
            row_sums[line_col]<=accumulated;
            if(line_last) previous_read<=previous_luma[line_addr];
        end
        if(block_pending) begin
            previous_luma[block_addr]<=block_avg;
            history_read<=history[block_col];
        end else if(bottom_request) history_read<=history[bottom_col];
        if(diff_pending)
            history[diff_col]<={(diff_row==0 ? 1'b0:history_read[0]),diff_bit};
        if(mask_we) begin
            if(mask_bank) mask1[mask_addr]<=mask_value;
            else mask0[mask_addr]<=mask_value;
        end
        if(de && y<IMG_HEIGHT) begin
            mask_read0<=mask0[pixel_cell];mask_read1<=mask1[pixel_cell];
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            mode_meta<=0;mode_sync<=0;tag_meta<=0;tag_sync<=0;
            vs_d<=0;first_pending<=1;frame_enabled<=0;process_frame<=0;
            frame_reference<=0;bg_valid<=0;last_tag_valid<=0;last_tag<=0;working_tag<=0;
            frame_completed<=0;frame_bad<=0;x<=0;y<=0;tile_base<=0;
            horizontal_sum<=0;line_sum<=0;line_pending<=0;line_first<=0;line_last<=0;
            line_col<=0;line_row<=0;line_addr<=0;block_pending<=0;block_avg<=0;
            block_col<=0;block_row<=0;block_addr<=0;diff_pending<=0;diff_bit<=0;
            diff_col<=0;diff_row<=0;diff_addr<=0;left_column<=0;middle_column<=0;
            right_pending<=0;right_row<=0;right_addr<=0;bottom_active<=0;
            bottom_phase<=0;bottom_col<=0;mask_we<=0;mask_value<=0;mask_bank<=1;
            mask_addr<=0;raw_count<=0;filtered_count<=0;finish_pending<=0;
            result_ready<=0;pending_state<=0;pending_cells<=0;
            read_bank<=0;write_bank<=1;display_state<=0;motion_cells<=0;
        end else begin
            mode_meta<=frame_mode_async;mode_sync<=mode_meta;
            tag_meta<=frame_tag_async;tag_sync<=tag_meta;vs_d<=vs;
            line_pending<=line_event;
            block_pending<=line_pending && line_last;
            diff_pending<=block_pending || bottom_request;
            mask_we<=0;right_pending<=0;finish_pending<=0;
            if(vs) begin x<=0;y<=0;tile_base<=0;first_pending<=1;end
            else if(de) begin
                if(x==IMG_WIDTH-1) begin
                    x<=0;y<=y+1'b1;
                    if(y[2:0]==7) tile_base<=tile_base+GW;
                end else x<=x+1'b1;
                if(y>=IMG_HEIGHT && process_frame) frame_bad<=1;
                if(process_now && y<IMG_HEIGHT) begin
                    if(x[2:0]==0) horizontal_sum<={3'd0,luma};
                    else horizontal_sum<=horizontal_sum+{3'd0,luma};
                end
            end
            if(first_pixel) begin
                first_pending<=0;frame_enabled<=eligible;process_frame<=fresh;
                frame_reference<=bg_valid;working_tag<=tag_sync[47:0];
                frame_completed<=0;frame_bad<=0;
                if(!eligible) begin
                    bg_valid<=0;last_tag_valid<=0;display_state<=0;motion_cells<=0;
                end else if(fresh) begin
                    raw_count<=0;filtered_count<=0;
                    if(!bg_valid) begin display_state<=0;motion_cells<=0;end
                end
            end
            if(line_event) begin
                line_sum<=horizontal_sum+{3'd0,luma};
                line_first<=(y[2:0]==0);line_last<=(y[2:0]==7);
                line_col<=x[10:3];line_row<=y[9:3];line_addr<=pixel_cell;
            end
            if(line_pending && line_last) begin
                block_avg<=accumulated[13:6];block_col<=line_col;
                block_row<=line_row;block_addr<=line_addr;
            end
            if(block_pending) begin
                diff_bit<=raw_bit;diff_col<=block_col;diff_row<=block_row;diff_addr<=block_addr;
                if(raw_bit)raw_count<=raw_count+1'b1;
            end else if(bottom_request) begin
                diff_bit<=0;diff_col<=bottom_col;diff_row<=GH;diff_addr<=CELLS+bottom_col;
            end
            if(bottom_active) begin
                bottom_phase<=!bottom_phase;
                if(bottom_phase) begin
                    if(bottom_col==GW-1)bottom_active<=0;
                    else bottom_col<=bottom_col+1'b1;
                end
            end
            if(diff_pending) begin
                if(diff_col==0) begin left_column<=0;middle_column<=new_column;end
                else begin
                    left_column<=middle_column;middle_column<=new_column;
                    if(diff_row>=1) begin
                        mask_we<=1;mask_bank<=write_bank;mask_addr<=diff_addr-GW-1;
                        mask_value<=supported;
                        if(supported)filtered_count<=filtered_count+1'b1;
                    end
                end
                if(diff_col==GW-1) begin
                    right_pending<=1;right_row<=diff_row;right_addr<=diff_addr-GW;
                end
            end else if(right_pending) begin
                if(right_row>=1) begin
                    mask_we<=1;mask_bank<=write_bank;mask_addr<=right_addr;
                    mask_value<=right_supported;
                    if(right_supported)filtered_count<=filtered_count+1'b1;
                end
                if(right_row==GH-1) begin bottom_active<=1;bottom_phase<=0;bottom_col<=0;end
                else if(right_row==GH)finish_pending<=1;
            end
            if(finish_pending) begin
                result_ready<=1;pending_cells<=filtered_count;
                frame_completed<=1;bg_valid<=1;last_tag_valid<=1;last_tag<=working_tag;
                if(!frame_reference)pending_state<=0;
                else if(raw_count>=SCENE_LIMIT)pending_state<=3;
                else if(filtered_count>=MIN_CELLS)pending_state<=2;
                else pending_state<=1;
            end
            // Flush worker/metadata on VS. The real 720p blanking provides
            // >8000 clocks before VS; bottom/right padding needs <400 clocks.
            if(vs && !vs_d) begin
                line_pending<=0;block_pending<=0;diff_pending<=0;
                right_pending<=0;bottom_active<=0;finish_pending<=0;mask_we<=0;
                if(process_frame && (!frame_completed || frame_bad)) begin
                    bg_valid<=0;last_tag_valid<=0;display_state<=0;motion_cells<=0;
                    result_ready<=0;
                end else if(result_ready) begin
                    read_bank<=write_bank;write_bank<=!write_bank;
                    display_state<=pending_state;motion_cells<=pending_cells;result_ready<=0;
                end
            end
        end
    end
endmodule
