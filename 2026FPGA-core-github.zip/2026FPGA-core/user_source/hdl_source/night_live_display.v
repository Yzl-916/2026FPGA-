// Single-frame colour night display. No frame hold, duplicate-tag filtering,
// motion rejection, or temporal accumulation. Normal path is an exact bypass.
// Q4 scene E0 -> tone E8 -> registered OSD/sync E9. Switch only in settled blanking.
module night_live_display #(
    parameter DEBOUNCE_CYCLES=750000,
    parameter WARM_FRAMES=8
)(
    input wire clk,rst_n,night_key_n,raw_vs,
    input wire [1:0] frame_mode_async,
    input wire [48:0] frame_tag_async,
    input wire scene_vs,scene_de,
    input wire [35:0] scene_rgb_q4,
    input wire normal_vs,normal_de,
    input wire [23:0] normal_rgb,
    output wire force_color,out_vs,out_de,
    output wire [23:0] out_rgb
);
    localparam DBW=DEBOUNCE_CYCLES<=1 ? 1:$clog2(DEBOUNCE_CYCLES);
    reg key_meta,key_sync,key_level,key_armed,requested;
    reg [DBW-1:0] debounce_count;
    reg [1:0] mode_meta,mode_sync;
    reg tag_valid_meta,tag_valid_sync;
    reg raw_vs_d,settling,selected;
    reg [5:0] settle_count;
    reg [7:0] warm_count;
    reg [8:0] vs_pipe;
    wire tone_valid;
    wire [23:0] tone_rgb;
    reg night_vs,night_de;
    reg [23:0] night_rgb;
    reg [10:0] x;
    reg [9:0] y;
    assign force_color=requested;
    night_live_tone u_tone(.clk(clk),.rst_n(rst_n),.in_valid(scene_de),.in_rgb_q4(scene_rgb_q4),
        .out_valid(tone_valid),.out_rgb(tone_rgb));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            // Start unarmed: a stable release is required even if K3 is held at reset.
            key_meta<=0;key_sync<=0;key_level<=0;key_armed<=0;
            requested<=0;debounce_count<=0;
            mode_meta<=0;mode_sync<=0;tag_valid_meta<=0;tag_valid_sync<=0;
            raw_vs_d<=0;settling<=0;selected<=0;settle_count<=0;warm_count<=0;
            vs_pipe<=0;
        end else begin
            key_meta<=night_key_n;key_sync<=key_meta;
            mode_meta<=frame_mode_async;mode_sync<=mode_meta;
            tag_valid_meta<=frame_tag_async[48];tag_valid_sync<=tag_valid_meta;
            raw_vs_d<=raw_vs;
            vs_pipe<={vs_pipe[7:0],scene_vs};
            if(key_sync==key_level) debounce_count<=0;
            else if(debounce_count==DEBOUNCE_CYCLES-1) begin
                key_level<=key_sync;debounce_count<=0;
                if(key_sync) key_armed<=1;
                else if(key_armed) begin requested<=!requested;key_armed<=0;end
            end else debounce_count<=debounce_count+1'b1;
            if(!requested) warm_count<=0;
            if(raw_vs_d && !raw_vs) begin
                settling<=1;settle_count<=0;
                if(requested && warm_count<WARM_FRAMES) warm_count<=warm_count+1'b1;
            end else if(settling) begin
                if(settle_count==63 && !normal_de && !scene_de && !tone_valid && !night_de) begin
                    selected<=requested && warm_count>=WARM_FRAMES &&
                              mode_sync==0 && tag_valid_sync;
                    settling<=0;
                end else if(settle_count<63) settle_count<=settle_count+1'b1;
            end
        end
    end
    function [34:0] glyph;
        input [3:0] column;
        begin case(column)
            0:glyph=35'b10000_10000_10000_10000_10000_10000_11111; // L
            1,6:glyph=35'b11111_00100_00100_00100_00100_00100_11111; // I
            2:glyph=35'b10001_10001_10001_10001_10001_01010_00100; // V
            3:glyph=35'b11111_10000_10000_11110_10000_10000_11111; // E
            5:glyph=35'b10001_11001_11001_10101_10011_10011_10001; // N
            7:glyph=35'b01111_10000_10000_10111_10001_10001_01111; // G
            8:glyph=35'b10001_10001_10001_11111_10001_10001_10001; // H
            9:glyph=35'b11111_00100_00100_00100_00100_00100_00100; // T
            default:glyph=0;
        endcase end
    endfunction
    wire panel=x>=16 && x<192 && y>=16 && y<48;
    wire text_area=x>=24 && x<184 && y>=24 && y<40;
    wire [10:0] tx=x-11'd24;
    wire [9:0] ty=y-10'd24;
    wire [34:0] bits=glyph(tx[7:4]);
    wire ink=text_area && tx[3:1]<5 && ty[3:1]<7 && bits[34-(ty[3:1]*5+tx[3:1])];
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin x<=0;y<=0;night_vs<=0;night_de<=0;night_rgb<=0;end
        else begin
            if(vs_pipe[8]) begin x<=0;y<=0;end
            else if(tone_valid) begin
                if(x==1279) begin x<=0;y<=y+1'b1;end else x<=x+1'b1;
            end
            night_vs<=vs_pipe[8];night_de<=tone_valid;
            if(!tone_valid) night_rgb<=0;
            else if(panel) night_rgb<=ink ? 24'hc9f7da:24'h10202a;
            else night_rgb<=tone_rgb;
        end
    end
    assign out_vs=selected ? night_vs:normal_vs;
    assign out_de=selected ? night_de:normal_de;
    assign out_rgb=selected ? night_rgb:normal_rgb;
endmodule
