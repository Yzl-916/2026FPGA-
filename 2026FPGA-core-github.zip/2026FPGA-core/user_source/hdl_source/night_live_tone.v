`timescale 1ns/1ps
// Q4 RGB, one independent pixel/clock. E0 accepted -> E8 output (nine stages).
// Exact V21.15 common-gain curve; interpolation uses only shifts and adds.
module night_live_tone #(
 parameter GAIN_FILE="night_live_gain.hex",
 parameter CAP_FILE="night_live_cap.hex"
)(input wire clk,input wire rst_n,input wire in_valid,input wire [35:0] in_rgb_q4,
  output wire out_valid,output reg [23:0] out_rgb);
 (* rom_style="bram" *) reg [14:0] gain_rom[0:4095];
 // Packed base15bit + delta10bit: CAP[m], CAP[m]-CAP[min(m+1,255)].
 (* rom_style="bram" *) reg [24:0] cap_rom[0:255];
 initial begin $readmemh(GAIN_FILE,gain_rom);$readmemh(CAP_FILE,cap_rom);end
 reg [8:0] valid_pipe;
 reg [11:0] r0,g0,b0;
 reg [35:0] rgb1,rgb2,rgb3,rgb4,rgb5;
 reg [11:0] gain_addr;
 reg [7:0] cap_addr;
 reg [3:0] frac1,frac2;
 reg [14:0] gain2,gain3,gain4,gain5,base3,cap4;
 reg [24:0] cap2;
 reg [13:0] partial_lo3,partial_hi3;
 reg [26:0] product_r,product_g,product_b;
 reg [23:0] rounded7;
 wire [11:0] maximum_rg=r0>g0?r0:g0;
 wire [11:0] maximum_rgb=maximum_rg>b0?maximum_rg:b0;
 wire [13:0] weighted_y={2'b00,r0}+{1'b0,g0,1'b0}+{2'b00,b0}+14'd2;
 wire [9:0] delta2=cap2[9:0];
 wire [14:0] drop_rounded={1'b0,partial_lo3}+{1'b0,partial_hi3}+15'd15;
 wire [26:0] rounded_r=product_r+27'd8192;
 wire [26:0] rounded_g=product_g+27'd8192;
 wire [26:0] rounded_b=product_b+27'd8192;
 assign out_valid=valid_pipe[8];
 // No data or ROM reset is needed: valid reset flushes the pipeline.
 always @(posedge clk) begin
  r0<=in_rgb_q4[35:24]>12'd224 ? in_rgb_q4[35:24]-12'd224:12'd0;
  g0<=in_rgb_q4[23:12]>12'd224 ? in_rgb_q4[23:12]-12'd224:12'd0;
  b0<=in_rgb_q4[11:0]>12'd224 ? in_rgb_q4[11:0]-12'd224:12'd0;
  gain_addr<=weighted_y[13:2];cap_addr<=maximum_rgb[11:4];frac1<=maximum_rgb[3:0];rgb1<={r0,g0,b0};
  gain2<=gain_rom[gain_addr];cap2<=cap_rom[cap_addr];frac2<=frac1;rgb2<=rgb1;
  partial_lo3<=(frac2[0]?{4'b0,delta2}:14'd0)+(frac2[1]?{3'b0,delta2,1'b0}:14'd0);
  partial_hi3<=(frac2[2]?{2'b0,delta2,2'b0}:14'd0)+(frac2[3]?{1'b0,delta2,3'b0}:14'd0);
  base3<=cap2[24:10];gain3<=gain2;rgb3<=rgb2;
  // floor((16*base-delta*frac)/16)=base-ceil(delta*frac/16).
  cap4<=base3-{4'b0,drop_rounded[14:4]};gain4<=gain3;rgb4<=rgb3;
  gain5<=gain4<cap4?gain4:cap4;rgb5<=rgb4;
  product_r<=gain5*rgb5[35:24];product_g<=gain5*rgb5[23:12];product_b<=gain5*rgb5[11:0];
  rounded7<={(|rounded_r[26:22])?8'hff:rounded_r[21:14],
             (|rounded_g[26:22])?8'hff:rounded_g[21:14],
             (|rounded_b[26:22])?8'hff:rounded_b[21:14]};
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin valid_pipe<=9'd0;out_rgb<=24'd0;end
  else begin valid_pipe<={valid_pipe[7:0],in_valid};out_rgb<=valid_pipe[7]?rounded7:24'd0;end
 end
endmodule

