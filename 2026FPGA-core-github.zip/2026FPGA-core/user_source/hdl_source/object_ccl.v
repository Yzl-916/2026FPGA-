// V7: material evidence plus paired inside/outside boundaries for yellow/green.
// 8x8 RGB means, ping-pong masks in BRAM,
// a full-grid queue, and six largest qualified components. No label starvation.
// Capture/brightness pipeline is unchanged. Results publish only at VS.
module object_ccl #(
 parameter IMG_WIDTH=1280, IMG_HEIGHT=720,
 parameter MIN_PIXELS=12, MIN_SIDE=3, MAX_SIDE=160, DEMO_PROFILE=0,
 parameter [3:0] COLOR_ENABLE=4'b1111,
 parameter [7:0] COLOR_MIN=8'd16,COLOR_DIFF=8'd3
)(
 input wire clk,rst_n,vs,de,enable,input wire [23:0] rgb,
 output reg [3:0] count,output reg overflow,output reg [17:0] colors,
 output reg [11:0] shapes,output reg result_valid,
 output reg [65:0] xmin,xmax,cx,output reg [59:0] ymin,ymax,cy,
 output reg [95:0] cx_bcd,cy_bcd
);
localparam SW=IMG_WIDTH/8,SH=IMG_HEIGHT/8,CELLS=SW*SH;
reg [10:0] x;reg [9:0] y;
reg vs_d,capture_bank,captured;
wire frame_end=vs && !vs_d;
wire active_pixel=enable && de && !vs && y<IMG_HEIGHT;
reg [10:0] row_r,row_g,row_b;
// Allocate only the active 8x8 grid. Address widths stay unchanged so the
// worker, frame budget and all published results retain the original timing.
reg [41:0] column_sum[0:SW-1];reg [41:0] column_q;
wire [10:0] line_r=(x[2:0]==0?11'd0:row_r)+{3'd0,rgb[23:16]};
wire [10:0] line_g=(x[2:0]==0?11'd0:row_g)+{3'd0,rgb[15:8]};
wire [10:0] line_b=(x[2:0]==0?11'd0:row_b)+{3'd0,rgb[7:0]};
wire [13:0] total_r=(y[2:0]==0?14'd0:column_q[41:28])+{3'd0,line_r};
wire [13:0] total_g=(y[2:0]==0?14'd0:column_q[27:14])+{3'd0,line_g};
wire [13:0] total_b=(y[2:0]==0?14'd0:column_q[13:0])+{3'd0,line_b};
wire block_end=active_pixel && x[2:0]==7;
wire mask_we=block_end && y[2:0]==7;
wire [13:0] capture_addr=y[9:3]*SW+x[10:3];
always @(posedge clk) begin
 column_q<=column_sum[x[10:3]];
 if(block_end) column_sum[x[10:3]]<={total_r,total_g,total_b};
end
always @(posedge clk or negedge rst_n) begin
 if(!rst_n) begin x<=0;y<=0;vs_d<=0;row_r<=0;row_g<=0;row_b<=0;captured<=0;end
 else begin
  vs_d<=vs;
  if(vs) begin x<=0;y<=0;captured<=0;end
  else if(de) begin
   if(x==IMG_WIDTH-1) begin x<=0;y<=y+1'b1;end else x<=x+1'b1;
   if(enable && x==IMG_WIDTH-1 && y==IMG_HEIGHT-1) captured<=1;
  end
  if(active_pixel) begin row_r<=line_r;row_g<=line_g;row_b<=line_b;end
 end
end
// Break the BRAM-sum -> colour comparisons -> mask BRAM path. The delayed
// address/page travel with each block; display pixels and timing are untouched.
reg [8:0] r,g,b;
reg mask_we_d1,mask_we_d2,capture_bank_d1,capture_bank_d2;
reg [13:0] capture_addr_d1,capture_addr_d2;
reg [17:0] capture_mask_d2;
wire [8:0] hi=r>g?(r>b?r:b):(g>b?g:b);
wire [8:0] rg_min=r<g?r:g;
wire [8:0] weak_diff=(hi>>5)>COLOR_DIFF?(hi>>5):{1'b0,COLOR_DIFF};
wire [8:0] strong_diff=(hi>>3)>8?(hi>>3):9'd8;
// Weak red body predicate retains V3; physical seed qualification is below.
wire red=hi>=COLOR_MIN && r>=g+weak_diff && r+(b>>3)>=b &&
 (g<=b || (g-b)<=((r-g)>>1));
wire [8:0] rb=r>b?r-b:9'd0,gb=g>b?g-b:9'd0,gr=g>r?g-r:9'd0;
// Yellow sector: both R and G above B; G-B/R-B between 1/2 and 2.
// This includes pale warm yellow, but excludes the known brown-wood palette.
// The complementary G-dominant sector belongs to GREEN, never YELLOW.
wire yellow_legacy=hi>=COLOR_MIN && r>=b+weak_diff && g>=b+weak_diff &&
 ({1'b0,gb}<<1)>={1'b0,rb} && ({1'b0,rb}<<1)>={1'b0,gb};
// Pale green can have B close to G after AWB/reflections. Allow one code value
// of quantization tolerance, while requiring a normalized R deficit (5/64).
// Averaging precedes this test: isolated pixel noise cannot become a seed.
wire [14:0] green_chroma={gr,6'b0};
wire [11:0] green_floor=({3'b0,hi}<<2)+{3'b0,hi};
wire [9:0] green_excess={1'b0,gr}+{1'b0,gb};
// Two independent green cues: R deficit for a pale/cyan-shifted green, or
// balanced G dominance over BOTH R/B. The second prevents 8x8 rounding/noise
// from shredding pale green while the low-chroma desk still fails both cues.
// The dim weak-green target needs a small quantization allowance; a bright
// greenish desk still needs a stronger normalized excess to stay separate.
wire [12:0] green_required={4'd0,hi}+(hi<8'd112 ? 13'd0 : 13'd16);
wire green_colored=green_chroma>=green_floor ||
 ({green_excess,3'b0}+(hi<8'd96 ? 13'd13 : 13'd8)>=green_required);
wire green=hi>=COLOR_MIN && gr>=COLOR_DIFF && green_colored && g+9'd1>=b &&
 (!DEMO_PROFILE || {gr,2'b0}>{2'b0,gb});
wire yellow=DEMO_PROFILE ? (hi>=COLOR_MIN && (r>=g || {gr,2'b0}<={2'b0,gb}) &&
 r>=b+weak_diff && g>=b+weak_diff && ({2'b0,gb}<<2)>={2'b0,rb}) : yellow_legacy;
wire blue=hi>=COLOR_MIN && b>=r+weak_diff && b>=g+weak_diff;
wire [2:0] hue=red && COLOR_ENABLE[0]?1:yellow && COLOR_ENABLE[3]?4:
 green && COLOR_ENABLE[1]?2:blue && COLOR_ENABLE[2]?3:0;
wire [9:0] yellow_chroma={1'b0,rb}+{1'b0,gb};
wire [9:0] yellow_seed_floor=(hi>>3)>12?(hi>>3):10'd12;
wire yellow_core=yellow_chroma>=yellow_seed_floor &&
 (({yellow_chroma,1'b0}>={2'd0,hi}) ||
 (g>=r && {rb,3'b0}>={3'b0,hi} && {yellow_chroma,2'b0}>={3'b0,hi}) ||
 (r>=g+3 && ({rb,2'b0}>=({2'b0,gb}<<2)+gb) && {yellow_chroma,3'b0}>={4'd0,hi}));
// Keep the weak red body mask, but seed physical objects only with a
// substantial R-G difference and a restrained warm (G-B) component. This
// rejects common brown wood while retaining the camera's B>=R dark reds.
wire [8:0] rg=r>g?r-g:9'd0;
wire legacy_red_seed=r>=g+strong_diff;
wire red_material_seed=({rg,2'b0}>={2'b0,hi}) &&
 (g<=b || {gb,2'b0}<={2'b0,rg});
// Physical red body: normalized R-G contrast >=1/8. Reuse mask bit 17;
// green/yellow classification and warm-yellow support retain their rules.
wire physical_red_body={rg,3'b0}>={3'b0,hi};
// Red components are collected first. Newly rejected red/brown seeds must
// not silently re-enter as yellow; the bridge uses the original seed test.
// A weak red-labelled pixel can support warm yellow only if no red component
// claimed it. This bridges quantization at the red/yellow sector boundary.
wire warm_support=DEMO_PROFILE && hue==1 && !legacy_red_seed && yellow && yellow_core;
wire seed=(hue==1)?legacy_red_seed && (!DEMO_PROFILE || red_material_seed):(hue==4)?yellow_chroma>=yellow_seed_floor &&
 (!DEMO_PROFILE || ({yellow_chroma,1'b0}>={2'd0,hi}) ||
 (g>=r && {rb,3'b0}>={3'b0,hi} && {yellow_chroma,2'b0}>={3'b0,hi}) ||
 (r>=g+3 && ({rb,2'b0}>=({2'b0,gb}<<2)+gb) && {yellow_chroma,3'b0}>={4'd0,hi})):
 (hue==2)?gr>=(hi<8'd96 ? 9'd4 : 9'd5) && green_colored && g>=b:
 (hue==3)?b>=r+strong_diff && b>=g+strong_diff:1'b0;
// Keep original hue/luminance after erasing a queue label, for surrounding-ring
// measurements. 18 bits use the native BRAM width efficiently.
wire [9:0] chroma=hue==2 ? green_excess : yellow_chroma;
wire [13:0] chroma16={chroma,4'b0};
wire [3:0] strength=chroma16>=hi*15?15:chroma16>=hi*14?14:
 chroma16>=hi*13?13:chroma16>=hi*12?12:chroma16>=hi*11?11:
 chroma16>=hi*10?10:chroma16>=hi*9?9:chroma16>=hi*8?8:
 chroma16>=hi*7?7:chroma16>=hi*6?6:chroma16>=hi*5?5:
 chroma16>=hi*4?4:chroma16>=hi*3?3:chroma16>=hi*2?2:chroma16>=hi?1:0;
wire balanced_green=({2'b0,gb}*2>={2'b0,gr}) && ({2'b0,gr}*3>={2'b0,gb});
// Material evidence is separate from the accepted hue/seed classifier. Pale
// colour may still grow a region, but a cyan cast or warm grey cannot obtain
// material evidence solely because it was assigned a nonzero hue.
wire material_green=balanced_green &&
 ({green_excess,3'b0}+(hi<8'd112 ? 13'd8 : 13'd0)>={4'd0,hi});
wire material_yellow={yellow_chroma,2'b0}>={3'd0,hi} && {gb,4'b0}>={4'd0,hi};
// Original-hue codes 5/6 mean material green/yellow. Reuse the unused codes
// instead of widening the 18-bit mask RAM. Mutable flood-fill labels stay 0..4.
wire [2:0] stored_hue=warm_support?3'd4:
 (hue==2 && material_green)?3'd5:(hue==4 && material_yellow)?3'd6:hue;
wire [17:0] capture_mask={hue==2?balanced_green:(warm_support || (hue==1 && physical_red_body)),
 stored_hue,strength,hi[7:2],seed,hue};
always @(posedge clk or negedge rst_n) begin
 if(!rst_n) begin
  r<=0;g<=0;b<=0;mask_we_d1<=0;mask_we_d2<=0;
  capture_bank_d1<=0;capture_bank_d2<=0;capture_addr_d1<=0;capture_addr_d2<=0;capture_mask_d2<=0;
 end else begin
  mask_we_d1<=mask_we;mask_we_d2<=mask_we_d1;
  if(mask_we) begin
   r<={1'b0,total_r[13:6]};g<={1'b0,total_g[13:6]};b<={1'b0,total_b[13:6]};
   capture_addr_d1<=capture_addr;capture_bank_d1<=capture_bank;
  end
  if(mask_we_d1) begin capture_mask_d2<=capture_mask;capture_addr_d2<=capture_addr_d1;capture_bank_d2<=capture_bank_d1;end
 end
end
// TD rounds a large inferred RAM to a power-of-two depth. Explicit 1024-word
// banks avoid allocating the unused final 1984 cells in each 720p mask page.
// Every bank has one synchronous read and one write; the registered bank
// selector preserves the original one-clock mask read latency.
localparam MASK_BANK_WORDS=1024,MASK_BANKS=(CELLS+MASK_BANK_WORDS-1)/MASK_BANK_WORDS;
wire [MASK_BANKS*18-1:0] mask_words_a,mask_words_b;
reg [3:0] mask_read_bank;
wire [17:0] mask_qa=mask_words_a[mask_read_bank*18+:18];
wire [17:0] mask_qb=mask_words_b[mask_read_bank*18+:18];

reg work_bank;reg [13:0] read_addr;reg [5:0] state;
localparam IDLE=0,SCAN_REQ=1,SCAN_WAIT=2,SCAN_TEST=3,SEED_ADD=4,
 POP_REQ=5,POP_WAIT=6,POP_LOAD=7,NEIGHBOR=8,NEIGH_WAIT=9,NEIGH_TEST=10,
 NEIGH_ADD=11,COMP_SIZE=12,COMP_AREA=13,COMP_TEST=14,
 SELECT_INIT=15,SELECT_SLOT=16,STORE=17,NEXT_SCAN=18,
 PACK_INIT=19,PACK_SLOT=20,BCD=21,PACK_SAVE=22,DONE=23,
 CTX_INIT=24,CTX_REQ=25,CTX_WAIT=26,CTX_ADD=27,CTX_NEXT=28,
 DIV_INIT=29,DIV_STEP=30,DIV_SAVE=31,CTX_TEST=32,CLASSIFY=33,
  CTX_INNER=34,CTX_OUT_REQ=35,CTX_OUT_WAIT=36,
  SHAPE_INIT=37,SHAPE_REQ=38,SHAPE_WAIT=39,SHAPE_ADD=40,
  SHAPE_NEXT=41,SHAPE_DECIDE=42,
  CONTOUR_INIT=43,CONTOUR_REQ=44,CONTOUR_WAIT=45,CONTOUR_INNER=46,
  CONTOUR_OUT_REQ=47,CONTOUR_OUT_WAIT=48,CONTOUR_ADD=49,
  CONTOUR_NEXT=50,CONTOUR_TEST=51;
wire erase_we=state==SEED_ADD || state==NEIGH_ADD;
wire [17:0] mask_q=work_bank?mask_qb:mask_qa;
// Preserve capture-over-erase priority for the ENTIRE page, including the
// unlikely case where both writes address different banks on the same clock.
wire capture_a=mask_we_d2 && !capture_bank_d2;
wire capture_b=mask_we_d2 && capture_bank_d2;
wire write_a=capture_a || (erase_we && !work_bank);
wire write_b=capture_b || (erase_we && work_bank);
wire [13:0] write_addr_a=capture_a?capture_addr_d2:read_addr;
wire [13:0] write_addr_b=capture_b?capture_addr_d2:read_addr;
wire [17:0] write_data_a=capture_a?capture_mask_d2:{mask_q[17:4],4'd0};
wire [17:0] write_data_b=capture_b?capture_mask_d2:{mask_q[17:4],4'd0};
always @(posedge clk) mask_read_bank<=read_addr[13:10];
genvar mask_bank;
generate for(mask_bank=0;mask_bank<MASK_BANKS;mask_bank=mask_bank+1)begin:mask_banks
 localparam BANK_DEPTH=(CELLS-mask_bank*MASK_BANK_WORDS>=MASK_BANK_WORDS)?
                      MASK_BANK_WORDS:CELLS-mask_bank*MASK_BANK_WORDS;
 (* ram_style="bram" *) reg [17:0] a[0:BANK_DEPTH-1],b[0:BANK_DEPTH-1];
 reg [17:0] qa,qb;
 always @(posedge clk)begin
  if(write_a && write_addr_a[13:10]==mask_bank)a[write_addr_a[9:0]]<=write_data_a;
  if(write_b && write_addr_b[13:10]==mask_bank)b[write_addr_b[9:0]]<=write_data_b;
  qa<=a[read_addr[9:0]];qb<=b[read_addr[9:0]];
 end
 assign mask_words_a[mask_bank*18+:18]=qa;
 assign mask_words_b[mask_bank*18+:18]=qb;
end endgenerate
// Erase at enqueue (not dequeue): every cell can enter the queue only once.
// Erase-on-enqueue bounds total queue entries by CELLS, including a component
// occupying the entire frame. The final tail value is never a write address.
reg [14:0] queue[0:CELLS-1];reg [14:0] queue_q;reg [13:0] head,tail;
reg [7:0] scan_x,nx,px;reg [6:0] scan_y,ny,py;
wire [14:0] queue_in=state==SEED_ADD?{scan_y,scan_x}:{ny,nx};
always @(posedge clk) begin
 if(erase_we) queue[tail]<=queue_in;
 queue_q<=queue[head];
end
reg [13:0] scan_addr,paddr;reg [3:0] neighbor;reg [2:0] comp_color;
reg [7:0] left,right,width;reg [6:0] top,bottom,height;
reg [14:0] area,pixels,seeds;reg pixel_seed;reg [1:0] comp_shape;
// Three horizontal and three vertical cross sections of the original colour
// mask describe the image silhouette. The flood fill only clears bits [3:0],
// so these samples do not change detection, component bounds or tracking.
reg [2:0] shape_line;
reg [7:0] shape_pos,shape_hits;
reg [7:0] shape_profile[0:5];
// Sparse triangles need boundaries along the silhouette, rather than the
// mostly empty sides of their bounding rectangle. The existing horizontal
// shape scans provide three pairs of endpoints without another image pass.
reg [7:0] contour_first[0:2],contour_last[0:2];
reg [2:0] contour_rows;
reg [1:0] contour_row;
reg contour_right;
reg [2:0] contour_valid,contour_good;
reg [1:0] contour_left_good,contour_right_good;
wire [7:0] contour_first_x=contour_first[contour_row];
wire [7:0] contour_last_x=contour_last[contour_row];
wire [6:0] contour_y=contour_row==0?top+(height>>3):
 contour_row==1?top+(height>>1):bottom-(height>>3);
wire contour_pair_available=contour_rows[contour_row] &&
 (contour_right?contour_last_x<SW-2:contour_first_x>=2);
wire contour_has_inset=contour_last_x>contour_first_x+1'b1;
wire [7:0] contour_inner_x=contour_right?
 (contour_has_inset?contour_last_x-1'b1:contour_last_x):
 (contour_has_inset?contour_first_x+1'b1:contour_first_x);
wire [7:0] contour_outer_x=contour_right?
 contour_last_x+2'd2:contour_first_x-2'd2;
wire [7:0] shape_x=shape_line<3?shape_pos:
 shape_line==3?left+(width>>3):shape_line==4?left+(width>>1):right-(width>>3);
wire [6:0] shape_y=shape_line<3?
 (shape_line==0?top+(height>>3):shape_line==1?top+(height>>1):bottom-(height>>3)):
 shape_pos[6:0];
wire shape_cell=original_color(mask_q[16:14])==comp_color;
// A practical triangle often has a blunt apex after 8x8 colour averaging.
// Require monotonic widening at all three samples plus a substantial total
// taper; comparing both ends directly avoids rejecting that truncated tip.
wire shape_triangle_h=(shape_profile[0]+(width>>3)<=shape_profile[1] &&
 shape_profile[1]+(width>>3)<=shape_profile[2] &&
 {1'b0,shape_profile[0]}*3<={1'b0,shape_profile[2]}*2) ||
 (shape_profile[2]+(width>>3)<=shape_profile[1] &&
 shape_profile[1]+(width>>3)<=shape_profile[0] &&
 {1'b0,shape_profile[2]}*3<={1'b0,shape_profile[0]}*2);
wire shape_triangle_v=(shape_profile[3]+(height>>3)<=shape_profile[4] &&
 shape_profile[4]+(height>>3)<=shape_profile[5] &&
 {1'b0,shape_profile[3]}*3<={1'b0,shape_profile[5]}*2) ||
 (shape_profile[5]+(height>>3)<=shape_profile[4] &&
 shape_profile[4]+(height>>3)<=shape_profile[3] &&
 {1'b0,shape_profile[5]}*3<={1'b0,shape_profile[3]}*2);
wire shape_round_h=shape_profile[1]>=shape_profile[0]+(width>>3) &&
 shape_profile[1]>=shape_profile[2]+(width>>3);
wire shape_round_v=shape_profile[4]>=shape_profile[3]+(height>>3) &&
 shape_profile[4]>=shape_profile[5]+(height>>3);
wire shape_full_h=shape_profile[0]+(width>>3)>=shape_profile[1] &&
 shape_profile[2]+(width>>3)>=shape_profile[1];
wire shape_full_v=shape_profile[3]+(height>>3)>=shape_profile[4] &&
 shape_profile[5]+(height>>3)>=shape_profile[4];
reg [14:0] best_area[0:5];reg [7:0] best_l[0:5],best_r[0:5];
reg [6:0] best_t[0:5],best_b[0:5];reg [2:0] best_c[0:5];reg [1:0] best_s[0:5];
reg [3:0] found;reg [2:0] slot,smallest,pack_slot;reg [14:0] smallest_area;
reg work_overflow;reg [17:0] next_colors;reg [11:0] next_shapes;
reg [65:0] next_xmin,next_xmax,next_cx;reg [59:0] next_ymin,next_ymax,next_cy;
reg [95:0] next_bcdx,next_bcdy;reg [27:0] decx,decy;reg [3:0] bcd_step;
wire [8:0] sum_x={1'b0,best_l[pack_slot]}+{1'b0,best_r[pack_slot]};
wire [7:0] sum_y={1'b0,best_t[pack_slot]}+{1'b0,best_b[pack_slot]};
wire [10:0] center_x={sum_x,2'b00}+11'd3;
wire [9:0] center_y={sum_y,2'b00}+10'd3;
wire near_square=({2'b0,width}<<2)>=({3'b0,height}*3) &&
 ({3'b0,height}<<2)>=({2'b0,width}*3);
// Only physical yellow/green take this context path. Red keeps its weak body
// predicate/flood fill, with the stronger physical seed requirement above.
reg [3:0] scan_pass;
reg [5:0] anchor_luma;
reg [3:0] chroma_floor;
reg [20:0] body_luma,body_chroma;
reg [14:0] dark_pixels,balanced_pixels;
reg [14:0] material_pixels;
reg [2:0] ring_side;
reg [7:0] ring_pos;
reg [7:0] side_count,side_contrast,side_luma;
reg [2:0] good_sides,available_sides,luma_sides;
reg [7:0] probe_l,probe_r;
reg [6:0] probe_t,probe_b;
reg [17:0] inner_mask;
reg [3:0] body_strength;
reg [5:0] body_mean;
function [2:0] original_color;
 input [2:0] code;
 begin original_color=code==5?3'd2:code==6?3'd4:code;end
endfunction
wire inner_valid=original_color(inner_mask[16:14])==comp_color;
wire outside_other=original_color(mask_q[16:14])!=comp_color;
wire lighter_outside={1'b0,mask_q[9:4]}>={1'b0,inner_mask[9:4]}+7'd5;
wire darker_outside={1'b0,inner_mask[9:4]}>={1'b0,mask_q[9:4]}+7'd5;
// A pale cyan-shifted green needs a substantially darker surround (5/16 of
// its brightness), or a brighter surround. A small grey/cyan step is not enough.
wire pale_green_step={1'b0,inner_mask[9:4],4'b0}>={1'b0,mask_q[9:4],4'b0}+
 {inner_mask[9:4],2'b0}+inner_mask[9:4];
wire luma_boundary=inner_valid && (lighter_outside ||
 (comp_color==4 && darker_outside) || (comp_color==2 && darker_outside && pale_green_step));
// Test paired samples, not the component mean against an unrelated hue.
// Neutral/weakly tinted neighbours need a measured chroma or brightness step.
wire outside_contrast=inner_valid && (lighter_outside || darker_outside ||
 ((inner_mask[13:10]>=4 || mask_q[13:10]==0) &&
  {1'b0,mask_q[13:10]}+5'd2<={1'b0,inner_mask[13:10]}) ||
 (outside_other && original_color(mask_q[16:14])!=0 && mask_q[13:10]>=4));
wire material_evidence=material_pixels>=(pixels>>2);

reg [20:0] div_value,div_rem;
reg [14:0] div_den;
reg [5:0] div_bit;
reg div_ring;
wire yg=DEMO_PROFILE && (comp_color==2 || comp_color==4);
wire dim_green_component=DEMO_PROFILE && comp_color==2 && anchor_luma<24;
wire dim_green_dense=dim_green_component && area>=80 &&
 pixels>=(area>>1)+(area>>3) && material_evidence && seeds>=(pixels>>1);
wire bright_weak_green=comp_color==2 && body_strength<6 &&
 dark_pixels<(pixels>>1) && (body_mean>=46 ||
 (body_mean>=40 && balanced_pixels>=(pixels>>1)));
wire warm_unclaimed=mask_q[2:0]==1 && mask_q[16:14]==4 && mask_q[17] && !mask_q[3];
wire [2:0] work_color=(DEMO_PROFILE && scan_pass!=0 && warm_unclaimed)?3'd4:mask_q[2:0];
wire work_seed=mask_q[3] || (scan_pass!=0 && warm_unclaimed);
wire start_allowed=!DEMO_PROFILE ||
 (scan_pass==0 ? (mask_q[2:0]==1 || mask_q[2:0]==3) && mask_q[3] :
 (work_color==2 || work_color==4) && work_seed &&
 mask_q[13:11]==8-scan_pass);
wire [7:0] luma_ceiling={2'b0,anchor_luma}+{3'b0,anchor_luma[5:1]}+
 {4'b0,anchor_luma[5:2]}+8'd2;
wire [7:0] face_ceiling=({2'b0,anchor_luma}<<1)+{2'b0,anchor_luma}+8'd2;
wire same_material_face=comp_color==2 && chroma_floor<=3 && mask_q[17] && mask_q[13:10]>=2 &&
 {2'b0,mask_q[9:4]}<=face_ceiling;
wire dim_green_luma_ok=!dim_green_component ||
 ({1'b0,mask_q[9:4]}+7'd4>={1'b0,anchor_luma} &&
  {1'b0,mask_q[9:4]}<={1'b0,anchor_luma}+7'd4) ||
 // A genuine darker face has material strength; a much brighter top face
 // may be low-chroma. Neither case accepts the adjacent dim desk.
 (chroma_floor>=3 && same_material_face && mask_q[16:14]==5 &&
  ((mask_q[13:10]>=3 &&
    {1'b0,mask_q[9:4]}+7'd12>={1'b0,anchor_luma} &&
    {1'b0,mask_q[9:4]}<={1'b0,anchor_luma}+7'd12) ||
   ({1'b0,mask_q[9:4]}>={1'b0,anchor_luma}+7'd12 &&
    {1'b0,mask_q[9:4]}<={1'b0,anchor_luma}+7'd20)));
wire red_grow_allowed=!DEMO_PROFILE || comp_color!=1 ||
 (mask_q[17] && mask_q[16:14]==1);
wire grow_allowed=red_grow_allowed && (!yg || (dim_green_luma_ok && mask_q[9:4]>=(anchor_luma>>1) &&
 (({2'b0,mask_q[9:4]}<=luma_ceiling && mask_q[13:10]>=chroma_floor) || same_material_face)));
wire [21:0] div_trial={div_rem,div_value[20]};
function [27:0] bcd_shift;
 input [27:0] val;reg [27:0] v;integer k;
 begin v=val;for(k=12;k<28;k=k+4) if(v[k+:4]>=5) v[k+:4]=v[k+:4]+3;bcd_shift=v<<1;end
endfunction
always @(posedge clk or negedge rst_n) begin
 if(!rst_n) begin
  capture_bank<=0;work_bank<=1;state<=IDLE;read_addr<=0;
  count<=0;overflow<=0;result_valid<=0;colors<=0;shapes<=0;
  xmin<=0;xmax<=0;ymin<=0;ymax<=0;cx<=0;cy<=0;cx_bcd<=0;cy_bcd<=0;
  head<=0;tail<=0;scan_x<=0;scan_y<=0;scan_addr<=0;
  nx<=0;ny<=0;px<=0;py<=0;paddr<=0;neighbor<=0;
  comp_color<=0;left<=0;right<=0;top<=0;bottom<=0;width<=0;height<=0;
   area<=0;pixels<=0;seeds<=0;pixel_seed<=0;comp_shape<=0;
   shape_line<=0;shape_pos<=0;shape_hits<=0;
  contour_rows<=0;contour_row<=0;contour_right<=0;
  contour_valid<=0;contour_good<=0;contour_left_good<=0;contour_right_good<=0;
  found<=0;slot<=0;smallest<=0;smallest_area<=0;pack_slot<=0;work_overflow<=0;
  next_colors<=0;next_shapes<=0;next_xmin<=0;next_xmax<=0;
  next_ymin<=0;next_ymax<=0;next_cx<=0;next_cy<=0;next_bcdx<=0;next_bcdy<=0;
  decx<=0;decy<=0;bcd_step<=0;
  scan_pass<=0;anchor_luma<=0;chroma_floor<=0;body_luma<=0;body_chroma<=0;
  dark_pixels<=0;balanced_pixels<=0;material_pixels<=0;
  ring_side<=0;ring_pos<=0;
  side_count<=0;side_contrast<=0;side_luma<=0;good_sides<=0;available_sides<=0;luma_sides<=0;body_strength<=0;
  probe_l<=0;probe_r<=0;probe_t<=0;probe_b<=0;inner_mask<=0;
  div_value<=0;div_rem<=0;div_den<=1;div_bit<=0;div_ring<=0;body_mean<=0;
 end else begin
  result_valid<=0;
  if(!enable) begin state<=IDLE;count<=0;overflow<=0;end
  else if(frame_end) begin
   if(state==DONE) begin
    count<=found;overflow<=work_overflow;result_valid<=1;
    colors<=next_colors;shapes<=next_shapes;
    xmin<=next_xmin;xmax<=next_xmax;ymin<=next_ymin;ymax<=next_ymax;
    cx<=next_cx;cy<=next_cy;cx_bcd<=next_bcdx;cy_bcd<=next_bcdy;
   end else if(state!=IDLE) begin
    // A missed processing deadline publishes an explicit fault, never partial data.
    count<=0;overflow<=1;result_valid<=1;
   end
   state<=IDLE;
   if(captured) begin
    work_bank<=capture_bank;capture_bank<=!capture_bank;
    scan_addr<=0;scan_x<=0;scan_y<=0;scan_pass<=0;found<=0;work_overflow<=0;state<=SCAN_REQ;
   end
  end else case(state)
  IDLE,DONE: begin end
  SCAN_REQ: begin read_addr<=scan_addr;state<=SCAN_WAIT;end
  SCAN_WAIT: state<=SCAN_TEST;
  SCAN_TEST: begin
   if(mask_q[2:0]==0 || !start_allowed) state<=NEXT_SCAN;
   else begin
    comp_color<=work_color;pixel_seed<=work_seed;head<=0;tail<=0;
    left<=scan_x;right<=scan_x;top<=scan_y;bottom<=scan_y;
    pixels<=1;seeds<=work_seed;state<=SEED_ADD;
    anchor_luma<=mask_q[9:4];
    chroma_floor<=work_color==2 && mask_q[9:4]<28 && mask_q[13:10]<=2 ? 1 :
      mask_q[13:10]>=4 ? mask_q[13:10]-(mask_q[13:10]>>2) : mask_q[13:10]>=2 ? 2 : 1;
    body_luma<=mask_q[9:4];body_chroma<=mask_q[13:10];
    dark_pixels<=mask_q[9:4]<40;balanced_pixels<=mask_q[17];
    material_pixels<=mask_q[16:14]==5 || mask_q[16:14]==6;
   end
  end
  SEED_ADD: begin tail<=1;state<=POP_REQ;end
  POP_REQ: if(head==tail) state<=COMP_SIZE;else state<=POP_WAIT;
  POP_WAIT: state<=POP_LOAD;
  POP_LOAD: begin
   px<=queue_q[7:0];py<=queue_q[14:8];paddr<=queue_q[14:8]*SW+queue_q[7:0];
   head<=head+1'b1;neighbor<=0;state<=NEIGHBOR;
  end
  NEIGHBOR: begin
   state<=NEIGH_WAIT;
   if(neighbor==4 && !dim_green_component) state<=POP_REQ;
   else case(neighbor)
   0: if(px!=0) begin nx<=px-1'b1;ny<=py;read_addr<=paddr-1'b1;end
      else begin neighbor<=1;state<=NEIGHBOR;end
   1: if(px<SW-1) begin nx<=px+1'b1;ny<=py;read_addr<=paddr+1'b1;end
      else begin neighbor<=2;state<=NEIGHBOR;end
   2: if(py!=0) begin nx<=px;ny<=py-1'b1;read_addr<=paddr-SW;end
      else begin neighbor<=3;state<=NEIGHBOR;end
   3: if(py<SH-1) begin nx<=px;ny<=py+1'b1;read_addr<=paddr+SW;end
      else begin neighbor<=4;state<=NEIGHBOR;end
   4: if(px!=0 && py!=0) begin nx<=px-1'b1;ny<=py-1'b1;read_addr<=paddr-SW-1'b1;end
      else begin neighbor<=5;state<=NEIGHBOR;end
   5: if(px<SW-1 && py!=0) begin nx<=px+1'b1;ny<=py-1'b1;read_addr<=paddr-SW+1'b1;end
      else begin neighbor<=6;state<=NEIGHBOR;end
   6: if(px!=0 && py<SH-1) begin nx<=px-1'b1;ny<=py+1'b1;read_addr<=paddr+SW-1'b1;end
      else begin neighbor<=7;state<=NEIGHBOR;end
   7: if(px<SW-1 && py<SH-1) begin nx<=px+1'b1;ny<=py+1'b1;read_addr<=paddr+SW+1'b1;end
      else begin neighbor<=8;state<=NEIGHBOR;end
   default: state<=POP_REQ;
   endcase
  end
  NEIGH_WAIT: state<=NEIGH_TEST;
  NEIGH_TEST: begin
   if((mask_q[2:0]==comp_color || (yg && comp_color==4 && warm_unclaimed)) && grow_allowed) begin pixel_seed<=mask_q[3] || (yg && comp_color==4 && warm_unclaimed);state<=NEIGH_ADD;end
   else begin neighbor<=neighbor+1'b1;state<=NEIGHBOR;end
  end
  NEIGH_ADD: begin
   tail<=tail+1'b1;pixels<=pixels+1'b1;seeds<=seeds+pixel_seed;
   body_luma<=body_luma+mask_q[9:4];body_chroma<=body_chroma+mask_q[13:10];
   dark_pixels<=dark_pixels+(mask_q[9:4]<40);balanced_pixels<=balanced_pixels+mask_q[17];
   material_pixels<=material_pixels+(mask_q[16:14]==5 || mask_q[16:14]==6);
   if(nx<left) left<=nx;if(nx>right) right<=nx;
   if(ny<top) top<=ny;if(ny>bottom) bottom<=ny;
   neighbor<=neighbor+1'b1;state<=NEIGHBOR;
  end
  COMP_SIZE: begin width<=right-left+1'b1;height<=bottom-top+1'b1;state<=COMP_AREA;end
  COMP_AREA: begin area<=width*height;state<=COMP_TEST;end
  COMP_TEST: begin
   if(pixels<MIN_PIXELS || (yg && pixels<64) || width<MIN_SIDE || height<MIN_SIDE ||
    width>MAX_SIDE || height>MAX_SIDE || seeds<2 || seeds<(pixels>>3) ||
    (DEMO_PROFILE && comp_color==1 && seeds<(pixels>>2)) ||
    pixels<(area>>2)+(area>>3) ||
    (DEMO_PROFILE && (area>CELLS/3 ||
     width>height*4 || height>width*4))) state<=NEXT_SCAN;
   else if(yg) state<=DIV_INIT;
   else state<=CLASSIFY;
  end
   CLASSIFY: begin
     if(DEMO_PROFILE) state<=SHAPE_INIT;
     else begin
      if(pixels>=area-(area>>3)) comp_shape<=3;
      else if(near_square && pixels>=(area>>1)+(area>>3)+(area>>4)) comp_shape<=1;
      else if(width<=height*2 && height<=width*2 && pixels<=(area>>1)+(area>>3)) comp_shape<=2;
      else comp_shape<=0;
      state<=SELECT_INIT;
     end
   end
   SHAPE_INIT: begin shape_line<=0;shape_pos<=left;shape_hits<=0;contour_rows<=0;state<=SHAPE_REQ;end
   SHAPE_REQ: begin read_addr<=shape_y*SW+shape_x;state<=SHAPE_WAIT;end
   SHAPE_WAIT: state<=SHAPE_ADD;
   SHAPE_ADD: begin
    shape_hits<=shape_hits+shape_cell;
    if(shape_line<3 && shape_cell) begin
     if(shape_hits==0) contour_first[shape_line]<=shape_pos;
     contour_last[shape_line]<=shape_pos;contour_rows[shape_line]<=1'b1;
    end
    state<=SHAPE_NEXT;
   end
   SHAPE_NEXT: begin
    if(shape_pos==(shape_line<3?right:{1'b0,bottom})) begin
     shape_profile[shape_line]<=shape_hits;
     if(shape_line==5) state<=SHAPE_DECIDE;
     else begin
      shape_line<=shape_line+1'b1;
      shape_pos<=shape_line>=2?{1'b0,top}:left;
      shape_hits<=0;state<=SHAPE_REQ;
     end
    end else begin shape_pos<=shape_pos+1'b1;state<=SHAPE_REQ;end
   end
   SHAPE_DECIDE: begin
    // Taper in one direction: triangle. Symmetric taper in both directions:
    // circle. Nearly constant cross sections: rectangle (also a cylinder
    // viewed from the side). Ambiguous silhouettes retain OBJECT.
    if(shape_triangle_h || shape_triangle_v) comp_shape<=2;
    else if(near_square && shape_round_h && shape_round_v &&
      pixels<area-(area>>3)) comp_shape<=1;
   else if((shape_full_h && shape_full_v) ||
      pixels>=area-(area>>2)) comp_shape<=3;
   else comp_shape<=0;
    // Sparse objects may enter the silhouette scanner, but only an actual
    // triangle can bypass the original solid-object occupancy threshold.
    if((shape_triangle_h || shape_triangle_v) &&
       (width<10 || height<10 || width>height*3 || height>width*3)) state<=NEXT_SCAN;
    else if(pixels<(yg?((area>>1)+(area>>3)+(area>>4)):((area>>1)+(area>>3))) &&
       !(shape_triangle_h || shape_triangle_v) &&
       !(dim_green_dense && shape_full_h && shape_full_v)) state<=NEXT_SCAN;
    else if(yg && pixels<(area>>1)+(area>>3)+(area>>4) &&
       (shape_triangle_h || shape_triangle_v)) state<=CONTOUR_INIT;
    else state<=SELECT_INIT;
   end
  // Six actual left/right contour pairs, each inside the target and two cells
  // outside it. Four independently contrasting pairs, with two per side,
  // reject a cast patch whose only evidence is one neighbouring obstacle.
  // Use the existing paired contrast rule and the same 18-bit image RAM.
  CONTOUR_INIT: begin
   contour_row<=0;contour_right<=0;contour_valid<=0;contour_good<=0;
   contour_left_good<=0;contour_right_good<=0;state<=CONTOUR_REQ;
  end
  CONTOUR_REQ: begin
   if(contour_pair_available) begin
    read_addr<=contour_y*SW+contour_inner_x;state<=CONTOUR_WAIT;
   end else state<=CONTOUR_NEXT;
  end
  CONTOUR_WAIT: state<=CONTOUR_INNER;
  CONTOUR_INNER: begin inner_mask<=mask_q;state<=CONTOUR_OUT_REQ;end
  CONTOUR_OUT_REQ: begin
   read_addr<=contour_y*SW+contour_outer_x;state<=CONTOUR_OUT_WAIT;
  end
  CONTOUR_OUT_WAIT: state<=CONTOUR_ADD;
  CONTOUR_ADD: begin
   contour_valid<=contour_valid+inner_valid;
   if(outside_contrast) begin
    contour_good<=contour_good+1'b1;
    if(contour_right) contour_right_good<=contour_right_good+1'b1;
    else contour_left_good<=contour_left_good+1'b1;
   end
   state<=CONTOUR_NEXT;
  end
  CONTOUR_NEXT: begin
   if(!contour_right) begin contour_right<=1;state<=CONTOUR_REQ;end
   else if(contour_row==2) state<=CONTOUR_TEST;
   else begin contour_row<=contour_row+1'b1;contour_right<=0;state<=CONTOUR_REQ;end
  end
  CONTOUR_TEST: begin
   if(contour_valid<4 || contour_good<4 ||
      contour_left_good<2 || contour_right_good<2) state<=NEXT_SCAN;
   else state<=SELECT_INIT;
  end
  // Body statistics are finished before testing individual surrounding sides.
  DIV_INIT: begin div_ring<=0;div_value<=body_luma;div_rem<=0;div_den<=pixels;div_bit<=0;state<=DIV_STEP;end
  DIV_STEP: begin
   if(div_trial>={7'd0,div_den}) begin div_rem<=div_trial-div_den;div_value<={div_value[19:0],1'b1};end
   else begin div_rem<=div_trial[20:0];div_value<={div_value[19:0],1'b0};end
   if(div_bit==20) state<=DIV_SAVE;else div_bit<=div_bit+1'b1;
  end
  DIV_SAVE: begin
   if(!div_ring) begin
    body_mean<=div_value[5:0];div_ring<=1;div_value<=body_chroma;
    div_rem<=0;div_bit<=0;state<=DIV_STEP;
   end else begin body_strength<=div_value[3:0];state<=CTX_INIT;end
  end
  CTX_INIT: begin
   // Central half of each side supports both rectangles and round silhouettes.
   // Probe one eighth inward, avoiding central highlights while remaining
   // inside circular silhouettes; the outside sample is two cells away.
   probe_l<=left+(width>>2);probe_r<=right-(width>>2);
   probe_t<=top+(height>>2);probe_b<=bottom-(height>>2);
   ring_side<=0;ring_pos<=left+(width>>2);side_count<=0;side_contrast<=0;side_luma<=0;
   good_sides<=0;available_sides<=0;luma_sides<=0;state<=CTX_REQ;
  end
  CTX_REQ: begin
   state<=CTX_WAIT;
   case(ring_side)
   0: if(top>=2) read_addr<=(top+(height>>3))*SW+ring_pos;else state<=CTX_NEXT;
   1: if(bottom<SH-2) read_addr<=(bottom-(height>>3))*SW+ring_pos;else state<=CTX_NEXT;
   2: if(left>=2) read_addr<=ring_pos*SW+left+(width>>3);else state<=CTX_NEXT;
   3: if(right<SW-2) read_addr<=ring_pos*SW+right-(width>>3);else state<=CTX_NEXT;
   default: state<=CTX_TEST;
   endcase
  end
  CTX_WAIT: state<=CTX_INNER;
  CTX_INNER: begin inner_mask<=mask_q;state<=CTX_OUT_REQ;end
  CTX_OUT_REQ: begin
   case(ring_side)
   0: read_addr<=(top-2)*SW+ring_pos;
   1: read_addr<=(bottom+2)*SW+ring_pos;
   2: read_addr<=ring_pos*SW+left-2;
   3: read_addr<=ring_pos*SW+right+2;
   endcase
   state<=CTX_OUT_WAIT;
  end
  CTX_OUT_WAIT: state<=CTX_ADD;
  CTX_ADD: begin
   side_count<=side_count+1'b1;side_contrast<=side_contrast+outside_contrast;
   side_luma<=side_luma+luma_boundary;state<=CTX_NEXT;
  end
  CTX_NEXT: begin
   state<=CTX_REQ;
   if((ring_side<2 && ring_pos==probe_r) || (ring_side>=2 && ring_pos==probe_b)) begin
    if(side_count!=0) begin
     available_sides<=available_sides+1'b1;
     if({side_contrast,2'b0}>=side_count*3) good_sides<=good_sides+1'b1;
     if({side_luma,2'b0}>=side_count*3) luma_sides<=luma_sides+1'b1;
    end
    side_count<=0;side_contrast<=0;side_luma<=0;ring_side<=ring_side+1'b1;
    ring_pos<=ring_side==0?probe_l:{1'b0,probe_t};
   end else ring_pos<=ring_pos+1'b1;
  end
  CTX_TEST: begin
   // Every visible side needs a boundary; a red neighbour alone is insufficient.
   // White panels with a green cast have low chroma and high brightness.
   if(pixels<(area>>1)+(area>>3)+(area>>4)) begin
    // A triangular colour component only touches part of the four box sides;
    // require material colour and an observed boundary, then verify its taper.
    if(dim_green_dense) state<=CLASSIFY;
    else if(available_sides<3 || good_sides<1 || !material_evidence ||
       bright_weak_green) state<=NEXT_SCAN;
    else state<=CLASSIFY;
   end else if(available_sides<3 || good_sides<available_sides ||
      (!material_evidence && luma_sides<available_sides) ||
      bright_weak_green) state<=NEXT_SCAN;
   else state<=CLASSIFY;
  end
  SELECT_INIT: begin
   if(found<6) begin smallest<=found[2:0];state<=STORE;end
   else begin work_overflow<=1;slot<=0;smallest<=0;smallest_area<=32767;state<=SELECT_SLOT;end
  end
  SELECT_SLOT: begin
   if(slot==6) state<=(pixels>smallest_area)?STORE:NEXT_SCAN;
   else begin
    if(best_area[slot]<smallest_area) begin smallest_area<=best_area[slot];smallest<=slot;end
    slot<=slot+1'b1;
   end
  end
  STORE: begin
   best_area[smallest]<=pixels;best_l[smallest]<=left;best_r[smallest]<=right;
   best_t[smallest]<=top;best_b[smallest]<=bottom;best_c[smallest]<=comp_color;best_s[smallest]<=comp_shape;
   if(found<6) found<=found+1'b1;state<=NEXT_SCAN;
  end
  NEXT_SCAN: begin
   if(scan_addr==CELLS-1) begin
    if(DEMO_PROFILE && scan_pass<8) begin scan_pass<=scan_pass+1'b1;scan_addr<=0;scan_x<=0;scan_y<=0;state<=SCAN_REQ;end
    else state<=PACK_INIT;
   end
   else begin
    scan_addr<=scan_addr+1'b1;
    if(scan_x==SW-1) begin scan_x<=0;scan_y<=scan_y+1'b1;end else scan_x<=scan_x+1'b1;
    state<=SCAN_REQ;
   end
  end
  PACK_INIT: begin
   pack_slot<=0;next_colors<=0;next_shapes<=0;next_xmin<=0;next_xmax<=0;
   next_ymin<=0;next_ymax<=0;next_cx<=0;next_cy<=0;next_bcdx<=0;next_bcdy<=0;state<=PACK_SLOT;
  end
  PACK_SLOT: begin
   if(pack_slot>=found) state<=DONE;
   else begin decx<={16'd0,1'b0,center_x};decy<={16'd0,2'b0,center_y};bcd_step<=0;state<=BCD;end
  end
  BCD: begin decx<=bcd_shift(decx);decy<=bcd_shift(decy);if(bcd_step==11) state<=PACK_SAVE;else bcd_step<=bcd_step+1'b1;end
  PACK_SAVE: begin
   next_colors[pack_slot*3+:3]<=best_c[pack_slot];next_shapes[pack_slot*2+:2]<=best_s[pack_slot];
   next_xmin[pack_slot*11+:11]<={best_l[pack_slot],3'b000};next_xmax[pack_slot*11+:11]<={best_r[pack_slot],3'b111};
   next_ymin[pack_slot*10+:10]<={best_t[pack_slot],3'b000};next_ymax[pack_slot*10+:10]<={best_b[pack_slot],3'b111};
   next_cx[pack_slot*11+:11]<=center_x;next_cy[pack_slot*10+:10]<=center_y;
   next_bcdx[pack_slot*16+:16]<=decx[27:12];next_bcdy[pack_slot*16+:16]<=decy[27:12];
   pack_slot<=pack_slot+1'b1;state<=PACK_SLOT;
  end
  default:state<=IDLE;
  endcase
 end
end
endmodule
