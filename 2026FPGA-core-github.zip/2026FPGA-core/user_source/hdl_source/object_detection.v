module object_detection #(
    // Three independent classes: RED, GREEN, YELLOW. Keep the accepted V3
    // physical-object filters/tracker. Blue remains excluded from the lab demo.
    parameter [3:0] TARGET_COLORS = 4'b1011,
    parameter PHYSICAL_OBJECTS = (TARGET_COLORS==4'b1011 || TARGET_COLORS==4'b1001),
    parameter IMG_WIDTH=1280, IMG_HEIGHT=720,
    parameter TEACH_ENABLE=0,
    parameter GAME_TAP_ENABLE=0,
    parameter KEY_DEBOUNCE_CYCLES=750000,KEY_HOLD_CYCLES=75000000,
    parameter INSPECT_STABLE_FRAMES=8,INSPECT_STALE_FRAMES=12
)(
    input wire clk, rst_n,teach_key_n,game_enable,
    output wire game_update,
    output reg game_valid,
    output reg [10:0] game_x,
    output reg [9:0] game_y,
    output reg [7:0] game_id,
    input wire [1:0] frame_mode_async,
    input wire [48:0] frame_tag_async,
    input wire vs, hs, de,
    input wire [23:0] scene_rgb, display_rgb,
    output wire out_vs, out_hs, out_de,
    output wire [23:0] out_rgb
);
// V21.2: use the metadata of the displayed DDR frame, not the current switch
// position. video_out holds this payload from its read-address selection in
// vertical blanking until the next frame. Synchronize, then sample at first DE.
// Compare both the 16-bit capture ID and its 32-bit timestamp, allowing skipped
// IDs and ID wrap without mistaking a new capture for a repeated display.
localparam FRAME_PIXELS=IMG_WIDTH*IMG_HEIGHT;
localparam PIXEL_COUNT_WIDTH=$clog2(FRAME_PIXELS+1);
reg [1:0] mode_meta,mode_sync;
reg [48:0] tag_meta,tag_sync;
reg first_pending,frame_enabled,frame_visible,capture_frame,frame_is_detection;
reg last_tag_valid;
reg [47:0] last_tag,working_tag;
reg [PIXEL_COUNT_WIDTH-1:0] captured_pixels;
wire first_pixel=first_pending && de && !vs;
wire detection_mode=mode_sync==2'd3;
wire inspection_enable=first_pixel?detection_mode:frame_is_detection;
wire game_session=GAME_TAP_ENABLE && game_enable && mode_sync==0;
reg game_session_d,session_wait;
wire session_reset=game_session!=game_session_d;
always @(posedge clk or negedge rst_n)begin
    if(!rst_n)begin game_session_d<=0;session_wait<=0;end
    else begin
        game_session_d<=game_session;
        if(session_reset)session_wait<=1;
        else if(first_pixel)session_wait<=0;
    end
end
// Keep the old CCL capture from restarting at the next VS. Release only
// when the new session begins its first image, after vertical blanking.
wire processing_mode=detection_mode || game_session;
wire eligible=processing_mode && tag_sync[48];
wire detection_visible=detection_mode && tag_sync[48];
wire fresh=eligible && (!last_tag_valid || tag_sync[47:0]!=last_tag);
// The first pixel must use the new decision on this same clock edge.
wire enabled=first_pixel ? processing_mode:frame_enabled;
wire processor_enable=enabled && !session_reset && !session_wait;
wire overlay_enabled=first_pixel ? detection_visible:frame_visible;
wire capture_now=first_pending ? fresh:capture_frame;
wire detector_de=de && !vs && capture_now &&
                 (first_pending || captured_pixels<FRAME_PIXELS);
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        mode_meta<=0;mode_sync<=0;tag_meta<=0;tag_sync<=0;
        first_pending<=1;frame_is_detection<=0;frame_enabled<=0;frame_visible<=0;capture_frame<=0;
        last_tag_valid<=0;last_tag<=0;working_tag<=0;captured_pixels<=0;
    end
    else begin
        mode_meta<=frame_mode_async;mode_sync<=mode_meta;
        tag_meta<=frame_tag_async;tag_sync<=tag_meta;
        if(vs) begin first_pending<=1;captured_pixels<=0;end
        else if(first_pixel) begin
            first_pending<=0;frame_is_detection<=detection_mode;frame_enabled<=processing_mode;
            frame_visible<=detection_visible;capture_frame<=fresh;
            working_tag<=tag_sync[47:0];
            captured_pixels<=fresh ? 1:0;
            // Invalid metadata suspends observations and hides the overlay,
            // without destroying tracks or the preceding worker's result.
            // Leaving detection mode starts a new tracking session.
            if(!processing_mode) last_tag_valid<=0;
        end else if(detector_de) begin
            captured_pixels<=captured_pixels+1'b1;
            // Commit only after the complete image was accepted. A truncated
            // capture can then be retried with the same tag on the next VS.
            if(captured_pixels==FRAME_PIXELS-1) begin
                last_tag<=working_tag;last_tag_valid<=1;
            end
        end
        if(session_reset)last_tag_valid<=0;
    end
end
wire [3:0] count, raw_count;
wire overflow, raw_overflow, result_valid;
wire [17:0] colors, raw_colors;
wire [11:0] shapes, raw_shapes;
wire [65:0] xmin, xmax, cx, raw_xmin, raw_xmax;
wire [59:0] ymin, ymax, cy, raw_ymin, raw_ymax;
wire [95:0] cx_bcd, cy_bcd;
wire [47:0] ids_bcd;
wire [5:0] held;
object_ccl #(.IMG_WIDTH(IMG_WIDTH),.IMG_HEIGHT(IMG_HEIGHT),
    .COLOR_ENABLE(TARGET_COLORS),
    .DEMO_PROFILE(PHYSICAL_OBJECTS),
    .MIN_PIXELS(PHYSICAL_OBJECTS ? 32:12),
    .MIN_SIDE(PHYSICAL_OBJECTS ? 4:3),
    .MAX_SIDE(PHYSICAL_OBJECTS ? 80:160)) detector (
    // Suppress capture only. VS and enable must keep the previous CCL worker
    // running and publishing while an identical frame is displayed again.
    .clk(clk), .rst_n(rst_n), .vs(vs), .de(detector_de), .enable(processor_enable), .rgb(scene_rgb),
    .count(raw_count), .overflow(raw_overflow), .colors(raw_colors), .shapes(raw_shapes),
    .xmin(raw_xmin), .xmax(raw_xmax), .ymin(raw_ymin), .ymax(raw_ymax),
    .cx(), .cy(), .cx_bcd(), .cy_bcd(), .result_valid(result_valid)
);
wire tracked_update;
object_tracker tracker (
    .clk(clk), .rst_n(rst_n), .enable(processor_enable), .result_valid(result_valid),
    .raw_count(raw_count), .raw_overflow(raw_overflow), .raw_colors(raw_colors), .raw_shapes(raw_shapes),
    .raw_xmin(raw_xmin), .raw_xmax(raw_xmax), .raw_ymin(raw_ymin), .raw_ymax(raw_ymax),
    .count(count), .overflow(overflow), .colors(colors), .shapes(shapes),
    .ids_bcd(ids_bcd), .held(held),
    .xmin(xmin), .xmax(xmax), .ymin(ymin), .ymax(ymax), .cx(cx), .cy(cy),
    .cx_bcd(cx_bcd), .cy_bcd(cy_bcd), .update_valid(tracked_update)
);

assign game_update=GAME_TAP_ENABLE && game_enable && tracked_update;
reg [2:0] green_count;
integer gi;
always @*begin
    game_valid=0;game_x=0;game_y=0;game_id=0;green_count=0;
    for(gi=0;gi<6;gi=gi+1)begin
        if(gi<count && colors[gi*3+:3]==3'd2 && !held[gi])begin
            green_count=green_count+1'b1;game_x=cx[gi*11+:11];game_y=cy[gi*10+:10];game_id=ids_bcd[gi*8+:8];
        end
    end
    game_valid=GAME_TAP_ENABLE && game_enable && !overflow && green_count==1;
end

wire overlay_vs,overlay_hs,overlay_de;wire [23:0] overlay_rgb;
object_overlay #(.IMG_WIDTH(IMG_WIDTH)) overlay (
    .clk(clk), .rst_n(rst_n), .vs(vs), .hs(hs), .de(de), .enable(overlay_enabled), .rgb(display_rgb),
    .count(count), .overflow(overflow), .colors(colors), .shapes(shapes),
    .ids_bcd(ids_bcd), .held(held),
    .xmin(xmin), .xmax(xmax), .ymin(ymin), .ymax(ymax), .cx(cx), .cy(cy),
    .cx_bcd(cx_bcd), .cy_bcd(cy_bcd),
    .out_vs(overlay_vs), .out_hs(overlay_hs), .out_de(overlay_de), .out_rgb(overlay_rgb)
);
generate if(TEACH_ENABLE) begin: inspection
    wire teach_pulse;
    inspection_key_control #(.DEBOUNCE_CYCLES(KEY_DEBOUNCE_CYCLES),.HOLD_CYCLES(KEY_HOLD_CYCLES)) key_control(
        .clk(clk),.rst_n(rst_n),.enable(inspection_enable && eligible),.key_n(teach_key_n),.teach_pulse(teach_pulse));
    reg [3:0] accepted_raw_count;
    reg [2:0] visible_delay;
    reg vs_old;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin accepted_raw_count<=0;visible_delay<=0;vs_old<=0;end
        else begin
            if(result_valid) accepted_raw_count<=raw_count;
            visible_delay<={visible_delay[1:0],overlay_enabled};vs_old<=vs;
        end
    end
    wire observation_bad=(result_valid && raw_overflow) ||
        (tracked_update && (overflow || held!=0 || count!=accepted_raw_count)) ||
        (first_pixel && !eligible);
    wire model_valid,teaching,cycle_armed;
    wire [1:0] ref_count;wire [8:0] ref_colors;wire [32:0] ref_x;wire [29:0] ref_y;
    wire [5:0] ref_errors;wire [3:0] status,live_count;wire [15:0] pass_bcd;
    visual_inspection #(.STABLE_FRAMES(INSPECT_STABLE_FRAMES),.STALE_FRAMES(INSPECT_STALE_FRAMES)) controller(
        .clk(clk),.rst_n(rst_n),.enable(inspection_enable),.frame_tick(vs && !vs_old),.teach_pulse(teach_pulse),
        .observation_valid(tracked_update),.observation_bad(observation_bad),
        .count(count),.colors(colors),.cx(cx),.cy(cy),
        .template_valid(model_valid),.teaching(teaching),.cycle_armed(cycle_armed),
        .reference_count(ref_count),.reference_colors(ref_colors),.reference_x(ref_x),.reference_y(ref_y),
        .reference_errors(ref_errors),.status(status),.live_count(live_count),.pass_bcd(pass_bcd));
    inspection_overlay #(.IMG_WIDTH(IMG_WIDTH)) display(
        .clk(clk),.rst_n(rst_n),.vs(overlay_vs),.hs(overlay_hs),.de(overlay_de),.enable(visible_delay[2]),.rgb(overlay_rgb),
        .template_valid(model_valid),.teaching(teaching),.cycle_armed(cycle_armed),
        .reference_count(ref_count),.reference_colors(ref_colors),.reference_x(ref_x),.reference_y(ref_y),
        .reference_errors(ref_errors),.status(status),.live_count(live_count),.pass_bcd(pass_bcd),
        .out_vs(out_vs),.out_hs(out_hs),.out_de(out_de),.out_rgb(out_rgb));
end else begin: legacy_display
    assign out_vs=overlay_vs;assign out_hs=overlay_hs;assign out_de=overlay_de;assign out_rgb=overlay_rgb;
end endgenerate
endmodule
