// Snapshot each CCL batch. Global nearest pairs, confirmed tracks first.
// Six tracks, bounded velocity prediction, adaptive box smoothing and three
// missed-capture hold. Display payload commits atomically. No RAM or DSP.
// V21.27: register prediction before pair scoring; decisions stay bit exact.
module object_tracker(
 input wire clk,rst_n,enable,result_valid,
 input wire [3:0] raw_count,input wire raw_overflow,
 input wire [17:0] raw_colors,input wire [11:0] raw_shapes,
 input wire [65:0] raw_xmin,raw_xmax,input wire [59:0] raw_ymin,raw_ymax,
 output reg [3:0] count,output reg overflow,
 output reg [17:0] colors,output reg [11:0] shapes,
 output reg [65:0] xmin,xmax,cx,output reg [59:0] ymin,ymax,cy,
 output reg [47:0] ids_bcd,output reg [5:0] held,
 output reg [95:0] cx_bcd,cy_bcd,
 output reg update_valid
);
reg [7:0] track_id[0:5],next_id;
reg active[0:5],confirmed[0:5];
reg [1:0] missed[0:5],hits[0:5];
reg [2:0] color[0:5];reg [1:0] shape[0:5],pending_shape[0:5];
reg shape_vote[0:5];
reg [10:0] left[0:5],right[0:5],measured_x[0:5];
reg [9:0] top[0:5],bottom[0:5],measured_y[0:5];
reg signed [6:0] velocity_x[0:5],velocity_y[0:5];
reg [2:0] match_index[0:5];
reg [2:0] obs_count;
reg [17:0] obs_colors;reg [11:0] obs_shapes;
reg [65:0] obs_xmin,obs_xmax;reg [59:0] obs_ymin,obs_ymax;
reg [3:0] state;
// Pulse with the atomically committed payload; legacy outputs are unchanged.
always @(posedge clk or negedge rst_n) begin
 if(!rst_n) update_valid<=0;
 else update_valid<=enable && state==9;
end

reg [2:0] slot,candidate,best,outn,best_slot,best_candidate;
reg [5:0] used,assigned;
reg tentative_phase,pair_allowed;
reg [10:0] pair_predicted_x,pair_predicted_y;
reg [12:0] best_cost,pair_cost;
reg [27:0] decx,decy;reg [3:0] step;
reg [47:0] next_ids;reg [5:0] next_held;
reg [17:0] next_colors;reg [11:0] next_shapes;
reg [65:0] next_xmin,next_xmax,next_cx;
reg [59:0] next_ymin,next_ymax,next_cy;
reg [95:0] next_bcdx,next_bcdy;
reg ov,id_busy;integer id_scan,k;
always @* begin
 id_busy=0;
 for(id_scan=0;id_scan<6;id_scan=id_scan+1)
  if(active[id_scan] && track_id[id_scan]==next_id)id_busy=1;
end
function [7:0] increment_id;
 input [7:0] value;
 begin
  if(value==8'h99)increment_id=8'h01;
  else if(value[3:0]==9)increment_id={value[7:4]+4'd1,4'd0};
  else increment_id=value+8'd1;
 end
endfunction
function [10:0] predict;
 input [10:0] position,limit;
 input signed [6:0] velocity;
 input [1:0] missing;
 reg signed [13:0] v,offset,p;
 begin
  v={{7{velocity[6]}},velocity};
  // Exact 1..4-frame displacement without a chain of position additions.
  case(missing)
   0:offset=v;
   1:offset=v<<<1;
   2:offset=(v<<<1)+v;
   default:offset=v<<<2;
  endcase
  p=$signed({3'b0,position})+offset;
  if(p<0)predict=0;
  else if(p>$signed({3'b0,limit}))predict=limit;
  else predict=p[10:0];
 end
endfunction
function signed [6:0] limit_velocity;
 input signed [12:0] delta;
 begin
  if(delta>32)limit_velocity=7'sd32;
  else if(delta< -32)limit_velocity=-7'sd32;
  else limit_velocity=delta[6:0];
 end
endfunction
function [10:0] follow_edge;
 input [10:0] a,b;input fast_filter;reg [11:0] d;reg [12:0] v;
 begin
  d=a>b?a-b:b-a;
  if(d<=3)follow_edge=a;
  else if(d>=16)follow_edge=b;
  else if(fast_filter)begin v={2'b0,a}+{2'b0,b}+1;follow_edge=v[11:1];end
  else begin v={2'b0,a}+({2'b0,a}<<1)+{2'b0,b}+2;follow_edge=v[12:2];end
 end
endfunction
function [27:0] shift_bcd;
 input [27:0] value;reg [27:0] v;integer j;
 begin v=value;for(j=12;j<28;j=j+4)if(v[j+:4]>=5)v[j+:4]=v[j+:4]+3;shift_bcd=v<<1;end
endfunction
wire [10:0] rl=obs_xmin[candidate*11+:11],rr=obs_xmax[candidate*11+:11];
wire [9:0] rt=obs_ymin[candidate*10+:10],rb=obs_ymax[candidate*10+:10];
wire [11:0] rx_sum={1'b0,rl}+rr,sx={1'b0,left[slot]}+right[slot];
wire [10:0] ry_sum={1'b0,rt}+rb,sy={1'b0,top[slot]}+bottom[slot];
wire [10:0] raw_cx=rx_sum[11:1];wire [9:0] raw_cy=ry_sum[10:1];
wire [10:0] predicted_x=predict(measured_x[slot],11'd2047,velocity_x[slot],missed[slot]);
wire [10:0] predicted_y=predict({1'b0,measured_y[slot]},11'd1023,velocity_y[slot],missed[slot]);
wire [11:0] dx=pair_predicted_x>raw_cx?pair_predicted_x-raw_cx:raw_cx-pair_predicted_x;
wire [11:0] dy=pair_predicted_y>{1'b0,raw_cy}?pair_predicted_y-{1'b0,raw_cy}:{1'b0,raw_cy}-pair_predicted_y;
wire [12:0] distance={1'b0,dx}+{1'b0,dy};
wire guarded_color=color[slot]==2 || color[slot]==4;
wire [11:0] track_w={1'b0,right[slot]}-{1'b0,left[slot]}+12'd1;
wire [11:0] raw_w={1'b0,rr}-{1'b0,rl}+12'd1;
wire [10:0] track_h={1'b0,bottom[slot]}-{1'b0,top[slot]}+11'd1;
wire [10:0] raw_h={1'b0,rb}-{1'b0,rt}+11'd1;
wire small_guarded_track=guarded_color && (track_w<128 || track_h<128);
wire valid_raw=rr>=rl && rb>=rt && obs_colors[candidate*3+:3]>=1 && obs_colors[candidate*3+:3]<=4;
// Keep green/yellow's accepted size guard; red also rejects a sudden region
// more than twice the target dimensions instead of inheriting its identity.
wire size_compatible=guarded_color ?
 (raw_w>=track_w-(track_w>>2) && track_w>=raw_w-(raw_w>>2) &&
  raw_h>=track_h-(track_h>>2) && track_h>=raw_h-(raw_h>>2)) :
 (raw_w>=(track_w>>1) && track_w>=(raw_w>>1) && raw_h>=(track_h>>1) && track_h>=(raw_h>>1));
wire [12:0] size_difference=(track_w>raw_w?track_w-raw_w:raw_w-track_w)+
                           (track_h>raw_h?track_h-raw_h:raw_h-track_h);
wire [12:0] gate=13'd32+(track_w<192?(track_w>>1):12'd96)+{7'b0,missed[slot],4'b0};
wire compatible=valid_raw && obs_colors[candidate*3+:3]==color[slot] && size_compatible;
wire [12:0] score=distance+(size_difference>>2)+
 ((shape[slot]!=0 && obs_shapes[candidate*2+:2]!=0 && shape[slot]!=obs_shapes[candidate*2+:2])?13'd8:13'd0);
wire [11:0] matched_x_sum={1'b0,obs_xmin[best*11+:11]}+obs_xmax[best*11+:11];
wire [10:0] matched_y_sum={1'b0,obs_ymin[best*10+:10]}+obs_ymax[best*10+:10];
wire [10:0] matched_x=matched_x_sum[11:1];wire [9:0] matched_y=matched_y_sum[10:1];
wire signed [12:0] measured_dx=$signed({2'b0,matched_x})-$signed({2'b0,measured_x[slot]});
wire signed [12:0] measured_dy=$signed({3'b0,matched_y})-$signed({3'b0,measured_y[slot]});
always @(posedge clk or negedge rst_n) begin
 if(!rst_n)begin
  state<=0;slot<=0;candidate<=0;best<=6;outn<=0;used<=0;assigned<=0;
  best_slot<=6;best_candidate<=6;best_cost<=8191;pair_cost<=0;pair_allowed<=0;tentative_phase<=0;
  pair_predicted_x<=0;pair_predicted_y<=0;
  obs_count<=0;obs_colors<=0;obs_shapes<=0;obs_xmin<=0;obs_xmax<=0;obs_ymin<=0;obs_ymax<=0;
  decx<=0;decy<=0;step<=0;ov<=0;next_id<=8'h01;
  count<=0;overflow<=0;colors<=0;shapes<=0;xmin<=0;xmax<=0;ymin<=0;ymax<=0;cx<=0;cy<=0;cx_bcd<=0;cy_bcd<=0;ids_bcd<=0;held<=0;
  next_ids<=0;next_held<=0;next_colors<=0;next_shapes<=0;next_xmin<=0;next_xmax<=0;next_ymin<=0;next_ymax<=0;next_cx<=0;next_cy<=0;next_bcdx<=0;next_bcdy<=0;
  for(k=0;k<6;k=k+1)begin
   track_id[k]<=0;active[k]<=0;confirmed[k]<=0;missed[k]<=0;hits[k]<=0;
   color[k]<=0;shape[k]<=0;pending_shape[k]<=0;shape_vote[k]<=0;
   left[k]<=0;right[k]<=0;top[k]<=0;bottom[k]<=0;measured_x[k]<=0;measured_y[k]<=0;
   velocity_x[k]<=0;velocity_y[k]<=0;match_index[k]<=6;
  end
 end else if(!enable)begin
  state<=0;count<=0;overflow<=0;ids_bcd<=0;held<=0;next_id<=8'h01;
  for(k=0;k<6;k=k+1)begin active[k]<=0;confirmed[k]<=0;missed[k]<=0;hits[k]<=0;end
 end else case(state)
 0:if(result_valid)begin
    // A CCL processing fault is an unknown observation, not an empty scene.
    if(raw_overflow && raw_count==0)begin overflow<=1;held<=6'b111111;end
    else begin
     obs_count<=raw_count>6?3'd6:raw_count[2:0];ov<=raw_overflow || raw_count>6;
     obs_colors<=raw_colors;obs_shapes<=raw_shapes;obs_xmin<=raw_xmin;obs_xmax<=raw_xmax;obs_ymin<=raw_ymin;obs_ymax<=raw_ymax;
     slot<=0;candidate<=0;used<=0;assigned<=0;tentative_phase<=0;
     best_slot<=6;best_candidate<=6;best_cost<=8191;
     for(k=0;k<6;k=k+1)match_index[k]<=6;
     state<=11;
    end
   end
 // Three stages: prediction/eligibility, score, then minimum selection.
 // Slot/candidate remain fixed across all three stages. No input is resampled.
 11:if(slot==6)state<=13;
    else if(candidate>=obs_count || candidate==6)begin slot<=slot+1'b1;candidate<=0;end
    else begin
     pair_allowed<=active[slot] && !assigned[slot] && !used[candidate] &&
        (tentative_phase?!confirmed[slot]:confirmed[slot]) && compatible;
     pair_predicted_x<=predicted_x;pair_predicted_y<=predicted_y;state<=14;
    end
 14:begin pair_allowed<=pair_allowed && distance<=gate;pair_cost<=score;state<=12;end
 12:begin
     if(pair_allowed && pair_cost<best_cost)begin best_cost<=pair_cost;best_slot<=slot;best_candidate<=candidate;end
     candidate<=candidate+1'b1;state<=11;
    end
 13:if(best_slot!=6)begin
     match_index[best_slot]<=best_candidate;assigned[best_slot]<=1;used[best_candidate]<=1;
     best_slot<=6;best_candidate<=6;best_cost<=8191;slot<=0;candidate<=0;state<=11;
    end else if(!tentative_phase)begin tentative_phase<=1;slot<=0;candidate<=0;state<=11;end
    else begin slot<=0;state<=1;end
 1:if(slot==6)begin candidate<=0;state<=4;end
   else if(!active[slot])slot<=slot+1'b1;
   else begin best<=match_index[slot];state<=3;end
 3:begin
    if(best!=6)begin
     if(hits[slot]<3)hits[slot]<=hits[slot]+1'b1;
     if(!small_guarded_track || hits[slot]>=2)confirmed[slot]<=1;
     if(missed[slot]==0)begin velocity_x[slot]<=limit_velocity(measured_dx);velocity_y[slot]<=limit_velocity(measured_dy);end
     measured_x[slot]<=matched_x;measured_y[slot]<=matched_y;missed[slot]<=0;
     left[slot]<=follow_edge(left[slot],obs_xmin[best*11+:11],guarded_color);right[slot]<=follow_edge(right[slot],obs_xmax[best*11+:11],guarded_color);
     top[slot]<=follow_edge({1'b0,top[slot]},{1'b0,obs_ymin[best*10+:10]},guarded_color);bottom[slot]<=follow_edge({1'b0,bottom[slot]},{1'b0,obs_ymax[best*10+:10]},guarded_color);
     if(obs_shapes[best*2+:2]==0 || obs_shapes[best*2+:2]==shape[slot])shape_vote[slot]<=0;
     else if(shape[slot]==0 || (shape_vote[slot] && pending_shape[slot]==obs_shapes[best*2+:2]))begin shape[slot]<=obs_shapes[best*2+:2];shape_vote[slot]<=0;end
     else begin pending_shape[slot]<=obs_shapes[best*2+:2];shape_vote[slot]<=1;end
    end else begin
     shape_vote[slot]<=0;
     if(!confirmed[slot] || missed[slot]==3)begin active[slot]<=0;confirmed[slot]<=0;end
     else missed[slot]<=missed[slot]+1'b1;
    end
    slot<=slot+1'b1;state<=1;
   end
 4:if(candidate>=obs_count || candidate==6)begin
    slot<=0;outn<=0;next_ids<=0;next_held<=0;next_colors<=0;next_shapes<=0;
    next_xmin<=0;next_xmax<=0;next_ymin<=0;next_ymax<=0;next_cx<=0;next_cy<=0;next_bcdx<=0;next_bcdy<=0;state<=6;
   end else if(used[candidate] || !valid_raw)candidate<=candidate+1'b1;
   else begin slot<=0;state<=5;end
 5:if(slot==6)begin ov<=1;candidate<=candidate+1'b1;state<=4;end
   else if(active[slot])slot<=slot+1'b1;
   else state<=10;
 10:if(id_busy)next_id<=increment_id(next_id);
    else begin
     track_id[slot]<=next_id;next_id<=increment_id(next_id);
     active[slot]<=1;confirmed[slot]<=0;missed[slot]<=0;hits[slot]<=1;
     color[slot]<=obs_colors[candidate*3+:3];shape[slot]<=obs_shapes[candidate*2+:2];shape_vote[slot]<=0;pending_shape[slot]<=0;
     left[slot]<=rl;right[slot]<=rr;top[slot]<=rt;bottom[slot]<=rb;
     measured_x[slot]<=raw_cx;measured_y[slot]<=raw_cy;velocity_x[slot]<=0;velocity_y[slot]<=0;
     candidate<=candidate+1'b1;state<=4;
    end
 6:if(slot==6)state<=9;
   else if(active[slot] && confirmed[slot])begin decx<={16'd0,1'b0,sx[11:1]};decy<={16'd0,2'b0,sy[10:1]};step<=0;state<=7;end
   else slot<=slot+1'b1;
 7:begin decx<=shift_bcd(decx);decy<=shift_bcd(decy);if(step==11)state<=8;else step<=step+1'b1;end
 8:begin
    next_ids[outn*8+:8]<=track_id[slot];next_held[outn]<=missed[slot]!=0;
    next_colors[outn*3+:3]<=color[slot];next_shapes[outn*2+:2]<=shape[slot];
    next_xmin[outn*11+:11]<=left[slot];next_xmax[outn*11+:11]<=right[slot];next_ymin[outn*10+:10]<=top[slot];next_ymax[outn*10+:10]<=bottom[slot];
    next_cx[outn*11+:11]<=sx[11:1];next_cy[outn*10+:10]<=sy[10:1];
    next_bcdx[outn*16+:16]<=decx[27:12];next_bcdy[outn*16+:16]<=decy[27:12];
    outn<=outn+1'b1;slot<=slot+1'b1;state<=6;
   end
 9:begin
    ids_bcd<=next_ids;held<=next_held;count<=outn;overflow<=ov;colors<=next_colors;shapes<=next_shapes;
    xmin<=next_xmin;xmax<=next_xmax;ymin<=next_ymin;ymax<=next_ymax;cx<=next_cx;cy<=next_cy;cx_bcd<=next_bcdx;cy_bcd<=next_bcdy;state<=0;
   end
 default:state<=0;
 endcase
end
endmodule
