// Linear, pre-AWB luma metering. Exactly 32x32 samples in the central 1024x512
// region of the 1280x720 frame, so the mean needs no divider. This tap is before
// display effects, OSD and DDR. A toggle/ack mailbox keeps the payload stable.
module sensor_ae_stats(
    input wire clk, rst_n, frame_start, valid,
    input wire [95:0] rgb,
    input wire ack,
    output reg [7:0] mean,
    output reg clipped, toggle
);
reg [8:0] xgroup;
reg [9:0] y;
reg [17:0] sum;
reg [10:0] samples, highlights;
reg ack_meta, ack_sync;
wire [9:0] luma_sum = {2'b0,rgb[23:16]}+{1'b0,rgb[15:8],1'b0}+{2'b0,rgb[7:0]};
wire selected = xgroup>=32 && xgroup<288 && xgroup[2:0]==0 &&
                y>=104 && y<616 && y[3:0]==0;
wire hot = rgb[23:16]>=240 || rgb[15:8]>=240 || rgb[7:0]>=240;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        xgroup<=0; y<=0; sum<=0; samples<=0; highlights<=0;
        mean<=0; clipped<=0; toggle<=0; ack_meta<=0; ack_sync<=0;
    end else begin
        ack_meta<=ack; ack_sync<=ack_meta;
        if(frame_start) begin
            if(samples==1024 && ack_sync==toggle) begin
                mean<=sum[17:10]; clipped<=highlights>=128; toggle<=!toggle;
            end
            xgroup<=valid ? 1:0; y<=0; sum<=0; samples<=0; highlights<=0;
        end else if(valid) begin
            if(xgroup==319) begin xgroup<=0; y<=y+1'b1; end
            else xgroup<=xgroup+1'b1;
            if(selected) begin
                sum<=sum+luma_sum[9:2]; samples<=samples+1'b1;
                highlights<=highlights+hot;
            end
        end
    end
end
endmodule
