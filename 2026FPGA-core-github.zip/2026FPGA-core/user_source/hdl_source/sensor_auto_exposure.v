// SC500CS datasheet V1.8 pp22-25: sensor has no built-in AE. Exposure is in
// half-lines, at most 2*VTS-10 = 1990 for the retained VTS=1000, 720p60 mode.
// Gain index maps to the vendor analog table (1..12x here; no digital gain).
// Wait four measured frames between writes; sensor changes take N+2 frames.
module sensor_auto_exposure(
    input wire clk, rst_n, cfg_done, ae_done,
    input wire stats_toggle,
    input wire [7:0] stats_mean,
    input wire stats_clipped,
    input wire [1:0] buttons,
    output reg stats_ack,
    output reg request,
    output reg [15:0] exposure, gain
);
reg toggle_meta, toggle_sync;
reg [7:0] mean_meta, mean_sync;
reg clip_meta, clip_sync;
reg [1:0] button_meta, button_sync, button_old;
reg [2:0] settle;
reg initialized;
reg [7:0] target;
wire [15:0] exposure_step = (exposure>>3)<4 ? 16'd4 : (exposure>>3);
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        toggle_meta<=0; toggle_sync<=0; mean_meta<=0; mean_sync<=0;
        clip_meta<=0; clip_sync<=0; stats_ack<=0; request<=0;
        button_meta<=3; button_sync<=3; button_old<=3;
        exposure<=1990; gain<=96; settle<=0; initialized<=0; target<=80;
    end else begin
        toggle_meta<=stats_toggle; toggle_sync<=toggle_meta;
        mean_meta<=stats_mean; mean_sync<=mean_meta;
        clip_meta<=stats_clipped; clip_sync<=clip_meta;
        button_meta<=buttons; button_sync<=button_meta; button_old<=button_sync;
        // Existing buttons now trim the automatic brightness target, 48..112.
        if(button_old[0] && !button_sync[0] && target>48) target<=target-8;
        if(button_old[1] && !button_sync[1] && target<112) target<=target+8;
        request<=0;
        if(toggle_sync!=stats_ack) begin
            stats_ack<=toggle_sync;
            if(settle!=0) settle<=settle-1'b1;
            else if(cfg_done && ae_done && !request) begin
                if(!initialized) begin initialized<=1; request<=1; settle<=4; end
                else if(clip_sync || mean_sync>target+12) begin
                    if(gain>16) begin gain<=gain>=20 ? gain-4 : 16; request<=1; settle<=4; end
                    else if(exposure>16) begin
                        exposure<=exposure>16+exposure_step ? exposure-exposure_step:16;
                        request<=1; settle<=4;
                    end
                end else if(mean_sync<target-12) begin
                    if(exposure<1990) begin
                        exposure<=exposure+exposure_step<1990 ? exposure+exposure_step:1990;
                        request<=1; settle<=4;
                    end else if(gain<128) begin gain<=gain+4; request<=1; settle<=4; end
                end
            end
        end
    end
end
endmodule
