/*****************************************************************
Company : MiLianKe Electronic Technology Co., Ltd.
WebSite:https://www.milianke.com
TechWeb:https://www.uisrc.com
tmall-shop:https://milianke.tmall.com
jd-shop:https://milianke.jd.com
taobao-shop: https://milianke.taobao.com
Description: 
The reference demo provided by Milianke is only used for learning. 
We cannot ensure that the demo itself is free of bugs, so users 
should be responsible for the technical problems and consequences
caused by the use of their own products.
@Author      :   XiaoQingquan 
@Time        :   2025/01 
version:     :   
@Description :   
*****************************************************************/
module signal_delay #(
    parameter IMG_HEIGHT = 1080,
    parameter IMG_WIDTH  = 1920,
    parameter DATA_WIDTH = 96,
    parameter DELAY_CYCLE = 50,
    // 0 sizes RAM to one line; 11 restores the original 2048-word allocation
    // for the V20 same-function resource comparison, without changing timing.
    parameter RAM_ADDR_WIDTH = 0
) (
    input                        I_clk,
    input                        I_rst_n,
    input                        I_tuser,  //synthesis keep 
    input  wire                  I_valid,  //synthesis keep 
    input  wire [DATA_WIDTH-1:0] I_data,   //synthesis keep 
    output wire                  O_valid,  //synthesis keep 
    output wire [DATA_WIDTH-1:0] O_data ,  //synthesis keep 
    output wire                  O_tuser   //synthesis keep 
);

    wire        rd_en;  //synthesis keep 

    // One line of four-pixel words is sufficient: 320 words at 1280 pixels.
    // Round up to a power of two for the native RAM, preserving all addresses.
    localparam IMG_WIDTH_4x = (IMG_WIDTH >> 2);
    localparam LINE_ADDR_WIDTH = RAM_ADDR_WIDTH ? RAM_ADDR_WIDTH :
                                ((IMG_WIDTH_4x <= 1) ? 1 : $clog2(IMG_WIDTH_4x));
    localparam LINE_RAM_DEPTH = (1 << LINE_ADDR_WIDTH);
    reg [LINE_ADDR_WIDTH-1:0] addra;  //synthesis keep
    reg [LINE_ADDR_WIDTH-1:0] addrb;  //synthesis keep


    reg  [13:0] h_cnt;
    reg  [13:0] v_cnt;
    reg  [13:0] rd_cnt;
    
    reg  [DATA_WIDTH-1:0] I_data_r;
    reg         rd_valid,I_valid_r;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n ) begin
            I_valid_r <= 0;
            I_data_r  <= 0;
        end
        else begin
            I_valid_r <= I_valid;
            I_data_r  <= I_data;
        end
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n || I_tuser) begin
            h_cnt <= 0;
            v_cnt <= 0;
        end
        else begin
            h_cnt <= I_valid_r ? ((h_cnt == IMG_WIDTH_4x-1) ? 0 : h_cnt + 1) : h_cnt;
            v_cnt <= I_valid_r &&(h_cnt == IMG_WIDTH_4x-1) ? ((v_cnt == IMG_HEIGHT - 1) ? 0 : v_cnt + 1) : v_cnt;
        end
    end
    
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n || I_tuser) begin
            rd_valid <= 0;
        end
        else if(h_cnt == DELAY_CYCLE - 3)begin
            rd_valid <= 1;
        end
        else if(rd_cnt == IMG_WIDTH_4x - 1) 
            rd_valid <= 0;
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n || I_tuser) begin
            rd_cnt <= 0;
        end
        else if(rd_cnt == IMG_WIDTH_4x )
            rd_cnt <= 0;
        else if(rd_valid)begin
            rd_cnt <= rd_cnt + 1;
        end
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n || I_tuser) begin
            addra <= 0;
        end else if (I_valid_r) begin
            addra <= (addra == IMG_WIDTH_4x - 1) ? 'b0 : addra + 1'b1;
        end
    end

  
    always @(posedge I_clk or negedge I_rst_n) begin
      if (!I_rst_n || I_tuser) begin
        addrb <= 0;
      end else begin
        addrb <= rd_valid ? (addrb == IMG_WIDTH_4x - 1) ? 'b0 : addrb + 1'b1 : addrb;
      end
    end
    
    reg rd_valid_d;
    always @(posedge I_clk or negedge I_rst_n) begin
      if (!I_rst_n) begin
        rd_valid_d <= 0;
      end else begin
        rd_valid_d <= rd_valid;
      end
    end
    assign O_valid = rd_valid_d;
    assign O_tuser = (v_cnt == 0) && (rd_cnt == 1);

    // Reuse the supplied parameterized TD RAM wrapper. Read latency,
    // read-before-write behavior and both clocks match the V13 instance.
    ram_f84573da5ab5 #(
      .DATA_WIDTH_A(DATA_WIDTH), .ADDR_WIDTH_A(LINE_ADDR_WIDTH),
      .DATA_DEPTH_A(LINE_RAM_DEPTH),
      .DATA_WIDTH_B(DATA_WIDTH), .ADDR_WIDTH_B(LINE_ADDR_WIDTH),
      .DATA_DEPTH_B(LINE_RAM_DEPTH),
      .REGMODE_A("NOREG"), .REGMODE_B("NOREG"),
      .WRITEMODE_A("NORMAL"), .WRITEMODE_B("READBEFOREWRITE"),
      .RESETMODE_A("ASYNC"), .RESETMODE_B("ASYNC"),
      .INIT_FILE("NONE"), .FILL_ALL("NONE")
    ) blk_mem_gen_awb_delay_signal_d (
      .clka (I_clk   ),  // input wire clka
      .wea  (I_valid_r),  // input wire [0 : 0] wea
      .addra(addra   ),  // input wire [10 : 0] addra
      .dia  (I_data_r ),  // input wire [95 : 0] dina
      .clkb (I_clk   ),  // input wire clkb
      .addrb(addrb   ),  // input wire [10 : 0] addrb
      .dob  (O_data  ),
      .doa(), .dib({DATA_WIDTH{1'b0}}), .web(1'b0)
    );


endmodule
