// SC500CS V1.8, Table 2-4 (pp24-25). Complete analog range, 1x..15.75x.
// Controller restricts operation to <=12x; no undocumented register values.
module SC500GainTbl(input wire I_clk,I_rstn, input wire [6:0] I, output reg [15:0] O);
always @(posedge I_clk) begin
    if(!I_rstn) O<=16'h0320;
    else begin
        O[7:0]<={3'b001,I[4:0]};
        case(I[6:5])
        0: O[15:8]<=8'h03; 1: O[15:8]<=8'h07;
        2: O[15:8]<=8'h0f; 3: O[15:8]<=8'h1f;
        endcase
    end
end
endmodule
