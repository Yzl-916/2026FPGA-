// SC500CS datasheet V1.8 pp23,28: manual analog gain and grouped writes.
module uics500regAE(input wire [8:0] REG_INDEX, output reg [23:0] REG_DATA,
 output wire [8:0] REG_SIZE, input wire [15:0] I_AE,I_AG);
assign REG_SIZE=9'd9;
always @* case(REG_INDEX)
 0: REG_DATA={16'h3e03,8'h0b};
 1: REG_DATA={16'h3800,8'h00};
 2: REG_DATA={16'h3e00,4'h0,I_AE[15:12]};
 3: REG_DATA={16'h3e01,I_AE[11:4]};
 4: REG_DATA={16'h3e02,I_AE[3:0],4'h0};
 5: REG_DATA={16'h3e08,I_AG[15:8]};
 6: REG_DATA={16'h3e09,I_AG[7:0]};
 7: REG_DATA={16'h3800,8'h10};
 8: REG_DATA={16'h3800,8'h60};
 default: REG_DATA=24'd0;
endcase
endmodule
