// V21.28: teach 1..3 spatially separated colour targets, then inspect batches.
// Only complete, newly captured and fully confirmed observations may advance
// settling or counting. No image memory, multipliers or tracking-ID dependency.
module visual_inspection #(
    parameter integer STABLE_FRAMES=8,
    parameter integer POSITION_TOL=48,
    parameter integer STILL_TOL=8,
    parameter integer STALE_FRAMES=12
)(
    input wire clk,rst_n,enable,frame_tick,teach_pulse,
    input wire observation_valid,observation_bad,
    input wire [3:0] count,
    input wire [17:0] colors,
    input wire [65:0] cx,
    input wire [59:0] cy,
    output reg template_valid,teaching,cycle_armed,
    output reg [1:0] reference_count,
    output reg [8:0] reference_colors,
    output reg [32:0] reference_x,
    output reg [29:0] reference_y,
    output reg [5:0] reference_errors,
    output reg [3:0] status,live_count,
    output reg [15:0] pass_bcd
);
    localparam READY=0,TEACH=1,WAITING=2,PASS=3,MISSING=4,
        EXTRA=5,COLOR=6,POSITION=7,EMPTY=8,LIMIT=9,SPREAD=10;
    localparam CW=STABLE_FRAMES<2?1:$clog2(STABLE_FRAMES+1);
    localparam TW=STALE_FRAMES<2?1:$clog2(STALE_FRAMES+1);
    reg [CW-1:0] streak;
    reg [TW-1:0] age;
    reg [3:0] previous_status;
    reg [5:0] previous_errors;
    reg [3:0] previous_count;
    reg [3:0] state;
    reg [1:0] row;
    reg [2:0] col;
    reg [3:0] observed_count;
    reg [17:0] observed_colors;
    reg [65:0] observed_x;
    reg [59:0] observed_y;
    reg [5:0] work_errors;
    reg nearby,same_nearby,same_anywhere;
    reg [32:0] work_x,settle_x;
    reg [29:0] work_y,settle_y;
    reg moving;
    reg [10:0] pair_x,target_x,anchor_x;
    reg [9:0] pair_y,target_y,anchor_y;
    reg [2:0] pair_color,target_color;
    reg pair_exists;
    reg [10:0] dx,dy,move_x,move_y;
    function [10:0] distance;
        input [10:0] a,b;
        begin distance=a>=b?a-b:b-a;end
    endfunction
    function [15:0] increment_bcd;
        input [15:0] n;
        begin
            if(n==16'h9999) increment_bcd=n;
            else if(n[3:0]!=9) increment_bcd=n+1'b1;
            else if(n[7:4]!=9) increment_bcd={n[15:4]+12'd1,4'd0};
            else if(n[11:8]!=9) increment_bcd={n[15:8]+8'd1,8'd0};
            else increment_bcd={n[15:12]+4'd1,12'd0};
        end
    endfunction
    wire [10:0] x0=cx[10:0],x1=cx[21:11],x2=cx[32:22];
    wire [10:0] y0={1'b0,cy[9:0]},y1={1'b0,cy[19:10]},y2={1'b0,cy[29:20]};
    wire too_close=(count>=2 && distance(x0,x1)<=2*POSITION_TOL && distance(y0,y1)<=2*POSITION_TOL) ||
                   (count>=3 && ((distance(x0,x2)<=2*POSITION_TOL && distance(y0,y2)<=2*POSITION_TOL) ||
                                (distance(x1,x2)<=2*POSITION_TOL && distance(y1,y2)<=2*POSITION_TOL)));
    wire [10:0] match_tolerance=teaching?STILL_TOL:POSITION_TOL;
    wire [1:0] row_error=same_nearby?2'd0:nearby?2'd2:same_anywhere?2'd3:2'd1;
    wire has_missing=(work_errors[1:0]==1)||(reference_count>=2 && work_errors[3:2]==1)||(reference_count>=3 && work_errors[5:4]==1);
    wire has_color=(work_errors[1:0]==2)||(reference_count>=2 && work_errors[3:2]==2)||(reference_count>=3 && work_errors[5:4]==2);
    wire has_position=(work_errors[1:0]==3)||(reference_count>=2 && work_errors[3:2]==3)||(reference_count>=3 && work_errors[5:4]==3);
    wire [3:0] verdict=observed_count==0?EMPTY:observed_count>reference_count?EXTRA:
        has_missing?MISSING:has_color?COLOR:has_position?POSITION:
        observed_count<reference_count?MISSING:PASS;
    wire signature_same=verdict==previous_status && work_errors==previous_errors && observed_count==previous_count && !(verdict==PASS && moving);
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            template_valid<=0;teaching<=0;cycle_armed<=0;reference_count<=0;
            reference_colors<=0;reference_x<=0;reference_y<=0;reference_errors<=0;
            status<=READY;live_count<=0;pass_bcd<=0;streak<=0;age<=0;
            previous_status<=WAITING;previous_errors<=0;previous_count<=0;
            state<=0;row<=0;col<=0;observed_count<=0;observed_colors<=0;
            observed_x<=0;observed_y<=0;work_errors<=0;nearby<=0;same_nearby<=0;same_anywhere<=0;
            work_x<=0;work_y<=0;settle_x<=0;settle_y<=0;moving<=0;
            pair_x<=0;pair_y<=0;target_x<=0;target_y<=0;anchor_x<=0;anchor_y<=0;
            pair_color<=0;target_color<=0;pair_exists<=0;dx<=0;dy<=0;move_x<=0;move_y<=0;
        end else if(!enable) begin
            // Completed templates and batch counts survive mode changes.
            state<=0;streak<=0;age<=0;teaching<=0;status<=template_valid?WAITING:READY;
            previous_status<=WAITING;reference_errors<=0;
            if(!template_valid) reference_count<=0;
        end else if(teach_pulse) begin
            template_valid<=0;teaching<=1;cycle_armed<=0;reference_count<=0;
            reference_errors<=0;pass_bcd<=0;streak<=0;age<=0;state<=0;status<=TEACH;
            previous_status<=WAITING;
        end else if(observation_bad) begin
            state<=0;streak<=0;age<=0;status<=teaching?TEACH:template_valid?WAITING:READY;
            previous_status<=WAITING;reference_errors<=0;
            if(teaching) reference_count<=0;
        end else if(frame_tick && age==STALE_FRAMES-1 && !observation_valid) begin
            state<=0;streak<=0;status<=teaching?TEACH:template_valid?WAITING:READY;
            previous_status<=WAITING;reference_errors<=0;
            if(teaching) reference_count<=0;
        end else begin
            if(observation_valid) age<=0;
            else if(frame_tick && age<STALE_FRAMES-1) age<=age+1'b1;
            case(state)
            0:if(observation_valid) begin
                live_count<=count;
                if(teaching && reference_count==0) begin
                    if(count==0 || count>3) begin status<=LIMIT;streak<=0;end
                    else if(too_close) begin status<=SPREAD;streak<=0;end
                    else begin
                        reference_count<=count[1:0];reference_colors<=colors[8:0];
                        reference_x<=cx[32:0];reference_y<=cy[29:0];
                        streak<=1;status<=TEACH;
                    end
                end else if(template_valid || teaching) begin
                    observed_count<=count;observed_colors<=colors;observed_x<=cx;observed_y<=cy;
                    row<=0;col<=0;nearby<=0;same_nearby<=0;same_anywhere<=0;work_errors<=0;
                    work_x<=0;work_y<=0;moving<=0;state<=1;
                end
            end
            // Register mux outputs before subtract/compare, preserving timing.
            1:begin
                pair_x<=observed_x[col*11+:11];pair_y<=observed_y[col*10+:10];
                pair_color<=observed_colors[col*3+:3];pair_exists<=col<observed_count;
                target_x<=reference_x[row*11+:11];target_y<=reference_y[row*10+:10];
                target_color<=reference_colors[row*3+:3];
                anchor_x<=settle_x[row*11+:11];anchor_y<=settle_y[row*10+:10];state<=2;
            end
            2:begin
                dx<=distance(pair_x,target_x);dy<=distance({1'b0,pair_y},{1'b0,target_y});
                move_x<=distance(pair_x,anchor_x);move_y<=distance({1'b0,pair_y},{1'b0,anchor_y});state<=3;
            end
            3:begin
                if(pair_exists) begin
                    if(pair_color==target_color) same_anywhere<=1;
                    if(dx<=match_tolerance && dy<=match_tolerance) begin
                        nearby<=1;
                        if(pair_color==target_color) begin
                            same_nearby<=1;work_x[row*11+:11]<=pair_x;work_y[row*10+:10]<=pair_y;
                            if(move_x>STILL_TOL || move_y>STILL_TOL) moving<=1;
                        end
                    end
                end
                if(col==5)state<=4;
                else begin col<=col+1'b1;state<=1;end
            end
            4:begin
                work_errors[row*2+:2]<=row_error;
                if(row+1>=reference_count) state<=5;
                else begin row<=row+1'b1;col<=0;nearby<=0;same_nearby<=0;same_anywhere<=0;state<=1;end
            end
            5:begin
                state<=0;
                if(teaching) begin
                    if(verdict!=PASS) begin reference_count<=0;streak<=0;status<=TEACH;end
                    else if(streak>=STABLE_FRAMES-1) begin
                        template_valid<=1;teaching<=0;status<=WAITING;streak<=0;
                        previous_status<=WAITING;reference_errors<=0;settle_x<=work_x;settle_y<=work_y;
                    end else streak<=streak+1'b1;
                end else begin
                    previous_status<=verdict;previous_errors<=work_errors;previous_count<=observed_count;
                    if(!signature_same || streak==0) begin
                        streak<=1;status<=WAITING;reference_errors<=0;settle_x<=work_x;settle_y<=work_y;
                    end else if(streak>=STABLE_FRAMES-1) begin
                        streak<=STABLE_FRAMES;status<=verdict;reference_errors<=work_errors;
                        if(verdict==EMPTY) cycle_armed<=1;
                        else if(verdict==PASS && cycle_armed) begin pass_bcd<=increment_bcd(pass_bcd);cycle_armed<=0;end
                    end else begin streak<=streak+1'b1;status<=WAITING;end
                end
            end
            default:state<=0;
            endcase
        end
    end
endmodule
